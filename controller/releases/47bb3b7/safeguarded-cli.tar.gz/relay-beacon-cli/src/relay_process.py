"""Shared process-control helpers for the Bot relay control surfaces.

Both `server.ts` (Express API) and `relay_supervisor.py` (CLI) start and stop
relay processes, and both previously duplicated the same broken stop sequence:

    SIGTERM to the recorded PID, then SIGKILL 500ms later

That is unreliable for this relay for two measured reasons:

  1. The relay blocks in `subprocess.run` while `opencode run` waits for the
     agent, so SIGTERM cannot take effect until the child finishes. A 500ms
     window is shorter than almost any real turn, so the SIGKILL branch fires
     routinely and kills the relay mid-flight.
  2. The relay's `opencode run` child lives in the relay's process group. Killing
     only the parent orphans that child, which then keeps writing to the session.

These helpers make stopping ownership-verified, group-aware, and verified. They
are shared rather than duplicated so the Express API and the CLI cannot drift.

Ownership is verified before any signal is sent: a recorded PID may be stale, or
the PID may have been reused by an unrelated process. We never signal a process
whose identity does not match what we recorded for the pair.
"""

import os
import signal
import subprocess
import time

# Marker substrings that must appear in a relay process's command line for us to
# believe the recorded PID is still that pair's relay.
#
# Both control surfaces launch the relay as
#   python3 -c "import relay_chatgpt_opencode as r; ... r.run_loop(...)"
# so the module name appears WITHOUT a .py suffix. Matching only the dotted form
# would refuse to stop every relay we actually start.
_RELAY_MARKERS = ("relay_chatgpt_opencode",)

# A relay process must also be running this interpreter. This rejects a
# different program that merely mentions the module name in its arguments.
_PYTHON_MARKERS = ("python",)


def _ps_output(pid):
    """Return (argv string, pgid) for pid, or (None, None) if it is gone.

    `ps -o args=` truncates the command line (observed at 64 characters on this
    platform), which silently dropped the relay marker and made every ownership
    check fail against a real relay. We therefore ask for each field on its own
    line and use the widest form available.
    """
    try:
        out = subprocess.run(
            ["ps", "-p", str(pid), "-o", "args=", "-ww"],
            capture_output=True, text=True, timeout=5,
        )
        if out.returncode != 0 or not (out.stdout or "").strip():
            return None, None
        argv = out.stdout.strip().splitlines()[-1].strip()
        pg_out = subprocess.run(
            ["ps", "-p", str(pid), "-o", "pgid="],
            capture_output=True, text=True, timeout=5,
        )
    except (subprocess.SubprocessError, OSError):
        return None, None
    if pg_out.returncode != 0:
        return None, None
    pgid_text = (pg_out.stdout or "").strip()
    if not pgid_text.isdigit():
        return None, None
    return argv, int(pgid_text)


def process_identity(pid):
    """Return dict describing pid, or None when it is not running.

    {'pid', 'pgid', 'argv'} - argv is the raw command line string.
    """
    argv, pgid = _ps_output(pid)
    if argv is None:
        return None
    return {"pid": pid, "pgid": pgid, "argv": argv}


def is_pid_running(pid):
    """True when a non-zombie process exists at pid.

    macOS can retain a detached Python relay as a zombie briefly after the
    process group has received SIGTERM.  ``kill(pid, 0)`` still succeeds for
    that PID, so using it alone falsely reports shutdown failure.
    """
    if not pid or int(pid) <= 0:
        return False
    try:
        os.kill(int(pid), 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        pass
    except OSError:
        return False
    try:
        result = subprocess.run(
            ["ps", "-p", str(int(pid)), "-o", "stat="],
            capture_output=True, text=True, timeout=5,
        )
        state = (result.stdout or "").strip()
        return result.returncode == 0 and bool(state) and not state.startswith("Z")
    except (subprocess.SubprocessError, OSError):
        return True


def verify_relay_ownership(pid, expected_session_id=None):
    """Confirm pid is a Bot relay, optionally the one for expected_session_id.

    Returns (ok, reason, identity). `ok` is False whenever identity cannot be
    established, so callers must not fall back to signalling the PID blindly.
    """
    ident = process_identity(pid)
    if ident is None:
        return False, "process %s is not running" % pid, None

    argv = ident["argv"]
    if not any(marker in argv for marker in _RELAY_MARKERS):
        return False, ("pid %s is not a Bot relay (argv: %s); refusing to signal"
                       % (pid, argv[:120])), ident
    if not any(marker in argv.lower() for marker in _PYTHON_MARKERS):
        return False, ("pid %s mentions the relay module but is not a Python "
                       "process (argv: %s); refusing to signal"
                       % (pid, argv[:120])), ident

    if expected_session_id and expected_session_id not in argv:
        return False, ("pid %s is a relay but not for session %s (argv: %s); "
                       "refusing to signal" % (pid, expected_session_id, argv[:120])), ident

    return True, "verified relay for session %s" % (expected_session_id or "any"), ident


def _group_members(pgid):
    """PIDs in process group pgid (excluding nothing). Empty if ps fails."""
    try:
        out = subprocess.run(
            ["ps", "-o", "pid=", "-g", str(pgid)],
            capture_output=True, text=True, timeout=5,
        )
    except (subprocess.SubprocessError, OSError):
        return []
    if out.returncode != 0:
        return []
    pids = []
    for token in (out.stdout or "").split():
        if token.isdigit():
            pids.append(int(token))
    return pids


def stop_relay(pid, expected_session_id=None, wait_seconds=10.0,
               poll_interval=0.25, log=None):
    """Stop a relay and its `opencode run` child, verifying ownership first.

    Sequence:
      1. Verify pid is a Bot relay for this pair. If not, stop and report.
      2. SIGTERM the process *group* so the relay and its child receive the same
         signal and neither is orphaned. `detached: true` / `start_new_session`
         makes the relay a group leader; when it is not, fall back to signalling
         the parent alone and report that the child may need separate handling.
      3. Poll until the group is gone or `wait_seconds` elapses.
      4. Report what actually happened. Never claim success we did not observe,
         and never escalate to SIGKILL automatically.

    Returns a dict:
      {'stopped', 'verified', 'reason', 'signal', 'group', 'remaining',
       'children_reaped'}
    """
    result = {
        "stopped": False,
        "verified": False,
        "reason": "",
        "signal": None,
        "group": None,
        "remaining": [],
        "children_reaped": False,
    }

    if not pid or int(pid) <= 0:
        result["reason"] = "no recorded pid for this pair"
        return result

    ok, reason, ident = verify_relay_ownership(pid, expected_session_id)
    result["reason"] = reason
    if not ok:
        # Deliberately no blind fallback: signalling an unverified pid could hit
        # an unrelated process that happens to have reused the number.
        return result
    result["verified"] = True

    pgid = ident["pgid"]
    is_leader = (pgid == pid)
    result["group"] = pgid

    if is_leader:
        members_before = _group_members(pgid)
        children = [p for p in members_before if p != pid]
        try:
            os.killpg(pgid, signal.SIGTERM)
            result["signal"] = "SIGTERM to group %s" % pgid
        except OSError as exc:
            result["reason"] = "killpg failed: %s" % exc
            return result

        deadline = time.time() + wait_seconds
        while time.time() < deadline:
            if not is_pid_running(pid):
                break
            time.sleep(poll_interval)

        if is_pid_running(pid):
            result["reason"] = ("relay %s still running after %ss; left running "
                                "for manual recovery (no automatic SIGKILL)"
                                % (pid, wait_seconds))
            result["remaining"] = _group_members(pgid)
            return result

        # Give the child a brief moment to exit on the same SIGTERM.
        child_deadline = time.time() + 3.0
        while time.time() < child_deadline:
            alive = [p for p in _group_members(pgid) if p != pid]
            if not alive:
                break
            time.sleep(poll_interval)
        result["children_reaped"] = not [p for p in _group_members(pgid) if p != pid]
        result["stopped"] = True
        result["reason"] = ("stopped relay %s and %d child process(es) via group %s"
                            % (pid, len(children), pgid))
        if log:
            log(result["reason"])
        return result

    # Not a group leader: signal the parent alone and say so plainly.
    try:
        os.kill(pid, signal.SIGTERM)
        result["signal"] = "SIGTERM to pid %s (not a group leader)" % pid
    except OSError as exc:
        result["reason"] = "kill failed: %s" % exc
        return result

    deadline = time.time() + wait_seconds
    while time.time() < deadline:
        if not is_pid_running(pid):
            break
        time.sleep(poll_interval)

    if is_pid_running(pid):
        result["reason"] = ("relay %s still running after %ss; left running for "
                            "manual recovery" % (pid, wait_seconds))
        result["remaining"] = _group_members(pgid)
        return result

    result["stopped"] = True
    result["reason"] = ("stopped relay %s; process was not a group leader so any "
                        "opencode child may still need separate handling" % pid)
    if log:
        log(result["reason"])
    return result
