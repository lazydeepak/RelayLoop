#!/usr/bin/env python3
"""Runtime model health, kept strictly separate from the user registry.

`models.json` is the user's configuration: the approved list, its order, and
each entry's `enabled` flag. This module never writes it. It persists only its
own runtime verdicts in `model-health.json`, so:

  * a model excluded here keeps its registry entry, its rank, and its
    `enabled: true` setting, and returns to routing automatically once healthy;
  * a model the user disabled stays disabled forever - user intent is never
    overridden, and only `models.json` can restore it.

Failure classification is evidence-based. A model missing from a provider's
catalog has been permanently removed and must not be probed again; rate limits,
quota exhaustion and capacity errors are transient; authentication failures are
a provider credential problem that no amount of model rotation can repair and
which therefore disables the whole provider rather than individual models.

Nothing here executes a model. Discovery and health checking are read-only.
"""
import json
import os
import re
import tempfile
import time
from opencode_model_catalog import read_catalog

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
HEALTH_FILE = os.environ.get("BOT_MODEL_HEALTH_FILE") or os.path.join(BASE_DIR, "model-health.json")
CATALOG_FILE = os.environ.get("BOT_MODEL_CATALOG_FILE") or os.path.join(BASE_DIR, "model-catalog.json")
OPENCODE_BIN = os.environ.get("BOT_OPENCODE_BIN") or os.path.expanduser(
    "~/.opencode/bin/opencode")

HEALTH_VERSION = 1

# Verdicts, most to least severe.
PERMANENTLY_REMOVED = "permanently_removed"   # absent from the provider catalog
RATE_LIMITED = "rate_limited"                 # transient: back off and retry later
QUOTA_EXHAUSTED = "quota_exhausted"           # transient: retry after the window
CAPACITY = "capacity"                         # transient: retry after backoff
AUTH_FAILURE = "auth_failure"                 # provider credential problem
TRANSPORT_FAILURE = "transport_failure"       # our side: never blames the model
UNKNOWN_FAILURE = "unknown_failure"           # unclassified: stay conservative

# Permanent removals are never re-probed; the catalog is the only authority.
# Transient states use provider-aware, bounded recovery windows.
RECOVERY_WINDOWS = {
    RATE_LIMITED: (60, 300, 900),       # 1m, 5m, 15m then stop
    QUOTA_EXHAUSTED: (3600, 21600, 86400),  # 1h, 6h, 24h then stop
    CAPACITY: (60, 300, 900),
    UNKNOWN_FAILURE: (3600, 21600, 86400),
    TRANSPORT_FAILURE: (60, 300, 900),
}
PROVIDER_AUTH_BACKOFF = 3600

ANSI_RE = re.compile(r"\x1b(?:\[[0-9;?]*[ -/]*[@-~]|\][^\x07\x1b]*(?:\x07|\x1b\\)|[@-Z\\-_])")

_ABSENCE_PATTERNS = (
    re.compile(r"model unavailable", re.IGNORECASE),
    re.compile(r"\bno such model\b", re.IGNORECASE),
    re.compile(r"\bmodel not found\b", re.IGNORECASE),
    re.compile(r"\bunknown model\b", re.IGNORECASE),
    re.compile(r"\bdoes not exist\b", re.IGNORECASE),
    re.compile(r"\bnot available (?:for|on) your account\b", re.IGNORECASE),
    re.compile(r"\bmodel[_ ]deprecat", re.IGNORECASE),
)
_QUOTA_PATTERNS = (
    re.compile(r"\b(?:usage|quota|credit)\s+limit(?:\s+has\s+been)?\s+(?:reached|exceeded)\b",
               re.IGNORECASE),
    re.compile(r"\binsufficient\s+(?:quota|credit|balance)\b", re.IGNORECASE),
    re.compile(r"\bbilling\b", re.IGNORECASE),
)
_RATE_PATTERNS = (
    re.compile(r"\brate[ _-]?limit", re.IGNORECASE),
    re.compile(r"\btoo many requests\b", re.IGNORECASE),
    re.compile(r"\b(?:http\s*)?429\b", re.IGNORECASE),
)
_CAPACITY_PATTERNS = (
    re.compile(r"\bcapacity\b", re.IGNORECASE),
    re.compile(r"\boverloaded\b", re.IGNORECASE),
    re.compile(r"\b(?:temporarily )?unavailable\b", re.IGNORECASE),
    re.compile(r"\b5\d\d\b", re.IGNORECASE),
    re.compile(r"\b(?:service (?:is )?(?:down|unavailable)|try again later)\b",
               re.IGNORECASE),
)
_AUTH_PATTERNS = (
    re.compile(r"\b(?:invalid|missing|expired|revoked)\s+(?:api[\s_-]?key|token|credential)\b",
               re.IGNORECASE),
    re.compile(r"\bunauthori[sz]ed\b", re.IGNORECASE),
    re.compile(r"\bforbidden\b", re.IGNORECASE),
    re.compile(r"\b(?:401|403)\b", re.IGNORECASE),
    re.compile(r"\bauthentication\b", re.IGNORECASE),
    re.compile(r"\bpermission[ _-]?denied\b", re.IGNORECASE),
)
# Failures on our side: never treated as evidence against a model.
_TRANSPORT_PATTERNS = (
    re.compile(r"\b(?:connection|econnrefused|econnreset|enotfound|etimedout)\b",
               re.IGNORECASE),
    re.compile(r"\b(?:network|dns|tls|socket)\b", re.IGNORECASE),
    re.compile(r"\btimed? ?out\b", re.IGNORECASE),
)


def _clean(text):
    return ANSI_RE.sub("", text or "")


def provider_of(model_ref):
    return (model_ref or "").partition("/")[0] or "unknown"


def classify_failure(text, returncode=None):
    """Return a verdict plus a short human reason for one failed CLI attempt.

    Order matters: an authentication error must win over the capacity language
    that some providers return alongside it, and our own transport problems must
    never be charged against a model.
    """
    output = _clean(text).strip()
    if not output:
        return (TRANSPORT_FAILURE if returncode else UNKNOWN_FAILURE,
                "no diagnostic output")

    for pattern in _TRANSPORT_PATTERNS:
        if pattern.search(output):
            return TRANSPORT_FAILURE, "transport failure: " + output[:160]
    for pattern in _AUTH_PATTERNS:
        if pattern.search(output):
            return AUTH_FAILURE, "provider credential rejected: " + output[:160]
    for pattern in _ABSENCE_PATTERNS:
        if pattern.search(output):
            return PERMANENTLY_REMOVED, "provider does not offer this model: " + output[:160]
    for pattern in _QUOTA_PATTERNS:
        if pattern.search(output):
            return QUOTA_EXHAUSTED, "quota or credit exhausted: " + output[:160]
    for pattern in _RATE_PATTERNS:
        if pattern.search(output):
            return RATE_LIMITED, "provider rate limit: " + output[:160]
    for pattern in _CAPACITY_PATTERNS:
        if pattern.search(output):
            return CAPACITY, "provider capacity error: " + output[:160]
    return UNKNOWN_FAILURE, "unclassified failure: " + output[:160]


def _now():
    return time.time()


def _iso(ts=None):
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(ts if ts is not None else _now()))


# ------------------------------------------------------------------
# PERSISTED RUNTIME HEALTH
# ------------------------------------------------------------------
def load_health(path=None):
    path = path or HEALTH_FILE
    try:
        with open(path, encoding="utf-8") as handle:
            data = json.load(handle)
        if isinstance(data, dict) and data.get("version") == HEALTH_VERSION:
            data.setdefault("models", {})
            data.setdefault("providers", {})
            return data
    except (OSError, ValueError, TypeError):
        pass
    return {"version": HEALTH_VERSION, "models": {}, "providers": {}}


def save_health(health, path=None):
    path = path or HEALTH_FILE
    directory = os.path.dirname(os.path.abspath(path))
    try:
        os.makedirs(directory, exist_ok=True)
    except OSError:
        pass
    fd, tmp = tempfile.mkstemp(prefix=".health-", suffix=".tmp", dir=directory or ".")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(health, handle, indent=2)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
    except OSError:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        return False
    return True


def model_health(health, model_ref):
    return (health.get("models") or {}).get(model_ref) or {}


def provider_health(health, provider):
    return (health.get("providers") or {}).get(provider) or {}


def record_failure(health, model_ref, verdict, reason, now=None, path=None):
    """Persist one failure verdict and return the stored entry."""
    now = now if now is not None else _now()
    provider = provider_of(model_ref)
    entry = {
        "verdict": verdict,
        "reason": reason[:300],
        "observed_at": _iso(now),
        "failures": int(model_health(health, model_ref).get("failures", 0)) + 1,
    }
    if verdict == PERMANENTLY_REMOVED:
        entry["suspended"] = True
        entry["recheck_after"] = None
    elif verdict == AUTH_FAILURE:
        entry["suspended"] = True
        entry["recheck_after"] = _iso(now + PROVIDER_AUTH_BACKOFF)
    else:
        windows = RECOVERY_WINDOWS.get(verdict, RECOVERY_WINDOWS[UNKNOWN_FAILURE])
        attempt = entry["failures"] - 1
        entry["suspended"] = True
        entry["recheck_after"] = _iso(now + windows[attempt]) if attempt < len(windows) else None
    health.setdefault("models", {})[model_ref] = entry

    if verdict == AUTH_FAILURE:
        # One bad credential is a provider-wide problem: every model on that
        # provider is equally unusable, so suspend them all rather than burning
        # a failover attempt on each.
        for ref in list(health.get("models", {})):
            if provider_of(ref) != provider:
                continue
            other = health["models"][ref]
            other["suspended"] = True
            other["verdict"] = AUTH_FAILURE
            other["reason"] = "provider credential rejected: %s" % reason[:200]
            other.setdefault("observed_at", entry["observed_at"])
            other.setdefault("failures", 1)
            other["recheck_after"] = _iso(now + PROVIDER_AUTH_BACKOFF)
    health.setdefault("providers", {})[provider] = {
        "verdict": verdict,
        "reason": entry["reason"],
        "observed_at": entry["observed_at"],
    }
    save_health(health, path)
    return entry


def record_success(health, model_ref, now=None, path=None):
    """Clear the runtime verdict so the model returns to routing."""
    health.setdefault("models", {}).pop(model_ref, None)
    save_health(health, path)
    return {"model_ref": model_ref, "status": "healthy", "observed_at": _iso(now)}


# ------------------------------------------------------------------
# ROUTING ELIGIBILITY
# ------------------------------------------------------------------
def is_eligible(entry, registry_enabled, now=None):
    """True when a registry entry may be routed to.

    `registry_enabled` is the user's own setting and always wins: a model the
    user disabled is never routed to, whatever the health system believes.
    """
    if not registry_enabled:
        return False, "disabled by user"
    if not entry:
        return True, None
    if entry.get("recheck_after") is None and entry.get("verdict") in (
            PERMANENTLY_REMOVED, AUTH_FAILURE, UNKNOWN_FAILURE):
        # Recovery exhausted: stay excluded until the catalog or the operator says
        # otherwise. Permanent removal is never re-probed.
        return False, entry.get("reason") or entry.get("verdict")
    if not entry.get("suspended"):
        return True, None
    recheck = entry.get("recheck_after")
    if recheck is None:
        return False, entry.get("reason") or entry.get("verdict")
    if _parse_iso(recheck) <= (now if now is not None else _now()):
        return True, "eligible again for a recovery recheck"
    return False, entry.get("reason") or entry.get("verdict")


def _parse_iso(text):
    try:
        return time.mktime(time.strptime(text, "%Y-%m-%dT%H:%M:%SZ")) - time.timezone
    except (TypeError, ValueError):
        return 0.0


def eligible_models(registry, health, now=None):
    """Approved models that are also routable, plus everything held back.

    Both exclusion kinds are reported so the caller can tell them apart: the
    operator's own `enabled: false` (which health never overrides) and a
    health-system suspension (which recovers on its own).
    """
    out, excluded = [], []
    for model in registry.get("models", []):
        if not model.get("enabled", True):
            excluded.append({"model_ref": model["model_ref"],
                             "name": model.get("name"),
                             "reason": "disabled by user",
                             "suspended_by": "user"})
            continue
        ok, reason = is_eligible(model_health(health, model["model_ref"]),
                                 True, now)
        if ok:
            out.append(model)
        else:
            excluded.append({"model_ref": model["model_ref"], "name": model.get("name"),
                             "reason": reason, "suspended_by": "health"})
    return out, excluded


# ------------------------------------------------------------------
# CATALOG REFRESH (read-only; never executes a model)
# ------------------------------------------------------------------
def read_local_catalog(opencode_bin=None, timeout=20):
    """Model refs from the shared OpenCode executable discovery path."""
    return {row["model_ref"] for row in read_catalog(opencode_bin, timeout=timeout)}


def compare_with_catalog(registry, catalog_refs, health, now=None, path=None):
    """Exclude approved models the catalog no longer offers.

    The catalog is authoritative for *permanent removal* only. A model that is
    merely unhealthy at runtime stays in the catalog and is handled by the
    failover loop, not by exclusion.
    """
    now = now if now is not None else _now()
    removed = []
    for model in registry.get("models", []):
        if not model.get("enabled", True):
            continue
        ref = model["model_ref"]
        if ref in catalog_refs:
            continue
        removed.append(ref)
        record_failure(health, ref, PERMANENTLY_REMOVED,
                       "absent from the OpenCode model catalog", now=now, path=path)
    return removed


def refresh_catalog(opencode_bin=None, path=None, save=True):
    """Refresh the catalog snapshot on disk. Returns (refs, error)."""
    try:
        refs = sorted(read_local_catalog(opencode_bin))
    except Exception as exc:  # noqa: BLE001 - discovery must never break the relay
        return [], str(exc)[:200]
    if save and path is None:
        try:
            with open(CATALOG_FILE, "w", encoding="utf-8") as handle:
                json.dump({"version": HEALTH_VERSION, "observed_at": _iso(),
                           "model_refs": refs}, handle, indent=2)
                handle.write("\n")
        except OSError:
            pass
    return refs, None


def load_catalog(path=None):
    try:
        with open(path or CATALOG_FILE, encoding="utf-8") as handle:
            data = json.load(handle)
        return set(data.get("model_refs") or []), data.get("observed_at")
    except (OSError, ValueError, TypeError):
        return set(), None


def health_report(registry, health, now=None):
    """Model-health view for the UI: excluded models, reasons, last check."""
    _routing, excluded = eligible_models(registry, health, now)
    rows = []
    for item in excluded:
        if item.get("suspended_by") == "user":
            rows.append({
                "model_ref": item["model_ref"], "name": item.get("name"),
                "reason": item["reason"], "verdict": "user_disabled",
                "last_verified": None, "recheck_after": None,
                "failures": 0, "suspended_by": "user",
            })
            continue
        entry = model_health(health, item["model_ref"])
        rows.append({
            "model_ref": item["model_ref"],
            "name": item.get("name"),
            "reason": item.get("reason"),
            "verdict": entry.get("verdict"),
            "last_verified": entry.get("observed_at"),
            "recheck_after": entry.get("recheck_after"),
            "failures": entry.get("failures", 0),
            "suspended_by": "health",
        })
    return {"excluded": rows, "providers": health.get("providers", {})}
