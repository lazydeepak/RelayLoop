"""Local OS-backed registry ownership shared by Node and supervisor commands.

Locks are never unlinked: process death releases ownership without stale-PID
reclamation. These are local filesystem locks, not cross-host fencing.
"""
from contextlib import contextmanager
from functools import wraps
import json
import os
import sys
import threading
import hashlib

from relay_pair_lock import acquire_pair_lock

_mutex = threading.RLock()
_held = {}


class RegistrySnapshot(dict):
    """An in-memory revision token; never added to the persisted JSON schema."""
    def __init__(self, data, raw):
        super().__init__(data)
        self.digest = hashlib.sha256(raw).digest()


def verify_snapshot(resource, snapshot):
    if isinstance(snapshot, RegistrySnapshot):
        with open(resource, 'rb') as stream:
            current = hashlib.sha256(stream.read()).digest()
        if current != snapshot.digest:
            raise RuntimeError('Registry changed since it was read; reload before updating')


@contextmanager
def own_registries(resources):
    resources = sorted(set(os.path.realpath(resource) for resource in resources))
    acquired = []
    with _mutex:
        try:
            for resource in resources:
                if resource not in _held:
                    lock = acquire_pair_lock(os.path.basename(resource) + '.registry', os.path.dirname(resource))
                    if lock is None:
                        raise RuntimeError('Registry already has a writer: ' + resource)
                    _held[resource] = [lock, 0]
                _held[resource][1] += 1
                acquired.append(resource)
            yield
        finally:
            for resource in reversed(acquired):
                _held[resource][1] -= 1
                if not _held[resource][1]:
                    _held.pop(resource)[0].release()


def registry_writer(operation):
    """Serialize the entire standalone read/modify/write command, not just save."""
    @wraps(operation)
    def guarded(*args, **kwargs):
        module = sys.modules[operation.__module__]
        if os.environ.get('BOT_REGISTRY_OWNER') == 'node':
            # Only the stop helper is registry-free; its body validates identity.
            if operation.__name__ == 'stop_pair':
                return operation(*args, **kwargs)
            if operation.__name__ == 'start_pair':
                return False
            raise RuntimeError('Node owns the registry; standalone mutation is forbidden')
        if os.environ.get('BOT_STORAGE', 'sqlite').lower() == 'sqlite':
            raise RuntimeError('Standalone supervisor cannot substitute JSON for authoritative SQLite; use Node controls')
        resources = [module.PAIRS_FILE if hasattr(module, 'PAIRS_FILE') else module._get_pairs_file()]
        if os.environ.get('BOT_DB_FILE'):
            resources.append(os.environ['BOT_DB_FILE'])
        with own_registries(resources):
            return operation(*args, **kwargs)
    return guarded


@contextmanager
def standalone_pair_execution(relay):
    """Explicit one-shot CLI work cannot compete with a Node/relay owner."""
    if os.environ.get('BOT_REGISTRY_OWNER') == 'node' or os.environ.get('BOT_STORAGE', 'sqlite').lower() == 'sqlite':
        raise RuntimeError('Standalone execution cannot bypass Node lifecycle admission; use the pair API')
    with own_registries([relay._get_pairs_file()]):
        pair_id = os.environ.get('BOT_PAIR_ID') or relay._current_pair_id() or relay.PAIR_ID
        relay._activate_pair(pair_id)
        relay._validate_pair_binding(pair_id)
        with relay.authorize(pair_id, 'standalone_execution', chatgpt_url=relay.CHATGPT_URL, session_id=relay.SESSION_ID):
            lock = acquire_pair_lock(pair_id)
            if lock is None:
                raise RuntimeError('Pair has a relay owner; standalone execution is forbidden')
            try:
                yield
            finally:
                lock.release()


if __name__ == '__main__':
    # A private startup handshake; stdin EOF releases all locks after Node dies.
    ready, resources = sys.argv[1], json.loads(sys.argv[2])
    try:
        with own_registries(resources):
            with open(ready, 'w') as stream:
                json.dump({'ok': True, 'pid': os.getpid()}, stream)
            sys.stdin.buffer.read()
    except Exception as error:
        with open(ready, 'w') as stream:
            json.dump({'ok': False, 'error': str(error)}, stream)
        sys.exit(1)
