#!/usr/bin/env python3
"""
Additive Multi-Pair Supervisor for Bot.
Manages session pairs in pairs.json and controls concurrent relay instances
without modifying the tested relay core (relay_chatgpt_opencode.py).
"""
import os
import sys
import json
import signal
import subprocess
import time
import tempfile
import stat
from registry_ownership import RegistrySnapshot, registry_writer, verify_snapshot

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.environ.get("BOT_DATA_DIR", BASE_DIR)
PAIRS_FILE = os.environ.get("BOT_PAIRS_FILE", os.path.join(DATA_DIR, "pairs.json"))
RUN_DIR = os.environ.get("BOT_RUN_DIR", os.path.join(DATA_DIR, ".relay_runs"))

sys.path.insert(0, os.path.join(BASE_DIR, "src"))
from relay_process import is_pid_running, stop_relay, verify_relay_ownership  # noqa: E402
from pair_execution import PairExecutionError, authorize  # noqa: E402


def ensure_dirs():
    if not os.path.exists(RUN_DIR):
        os.makedirs(RUN_DIR, exist_ok=True)


def load_pairs():
    if not os.path.exists(PAIRS_FILE):
        return {"default_pair_id": "relayx-default", "pairs": []}
    try:
        with open(PAIRS_FILE, "rb") as f:
            raw = f.read()
            return RegistrySnapshot(json.loads(raw), raw)
    except Exception:
        return {"default_pair_id": "relayx-default", "pairs": []}


@registry_writer
def save_pairs(data):
    """Publish a complete registry snapshot without truncating the old one.

    This protects readers from partial writes, not concurrent lost updates;
    lifecycle authority and cross-backend reconciliation remain separate work.
    """
    if os.environ.get("BOT_REGISTRY_OWNER") == "node":
        raise RuntimeError("Node owns the pair registry; supervisor writes are forbidden")
    destination = os.path.abspath(PAIRS_FILE)
    verify_snapshot(destination, data)
    mode = stat.S_IMODE(os.stat(destination).st_mode) if os.path.exists(destination) else 0o600
    fd, temporary = tempfile.mkstemp(prefix=".pairs-", suffix=".tmp", dir=os.path.dirname(destination))
    try:
        with os.fdopen(fd, "w") as f:
            os.chmod(temporary, mode)
            json.dump(data, f, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temporary, destination)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def get_pair(pair_id):
    data = load_pairs()
    for p in data["pairs"]:
        if p["id"] == pair_id:
            return p
    return None


@registry_writer
def list_pairs():
    data = load_pairs()
    changed = False
    for p in data["pairs"]:
        if p.get("status") == "archived":
            # Archived records are historical inventory, never reconcile them
            # back into a live/stopped execution state.
            continue
        pid = p.get("pid")
        if pid:
            if is_pid_running(pid):
                p["status"] = "running"
            else:
                p["status"] = "stopped"
                p["pid"] = None
                changed = True
        else:
            p["status"] = p.get("status", "stopped")
    if changed:
        save_pairs(data)
    print(json.dumps(data, indent=2))
    return data


@registry_writer
def add_pair(pair_id, name, chatgpt_url, session_id, opencode_bin=None):
    try:
        # Validate the exact supplied Planner/Worker pair binding.
        with authorize(pair_id, "registry_reintroduction", chatgpt_url, session_id):
            pass
    except PairExecutionError as exc:
        print(f"Error: {exc}")
        return False
    if not opencode_bin:
        opencode_bin = os.environ.get("BOT_OPENCODE_BIN") or "opencode"
    data = load_pairs()
    for p in data["pairs"]:
        if p["id"] == pair_id:
            print(f"Error: Pair ID '{pair_id}' already exists.")
            return False
        if p.get("session_id") == session_id:
            print("Error: Worker session is already registered to another pair.")
            return False
        if p.get("chatgpt_url") == chatgpt_url:
            print("Error: Planner conversation is already registered to another pair.")
            return False

    new_pair = {
        "id": pair_id,
        "name": name,
        "chatgpt_url": chatgpt_url,
        "session_id": session_id,
        "opencode_bin": opencode_bin,
        "status": "stopped",
        "pid": None,
    }
    data["pairs"].append(new_pair)
    save_pairs(data)
    print(f"Successfully added pair: {name} ({pair_id})")
    return True


@registry_writer
def delete_pair(pair_id):
    data = load_pairs()
    target = None
    for p in data["pairs"]:
        if p["id"] == pair_id:
            target = p
            break
    if not target:
        print(f"Error: Pair ID '{pair_id}' not found.")
        return False

    if target.get("pid") and is_pid_running(target["pid"]):
        # Keep the registry entry and PID when ownership-verified shutdown did
        # not complete. Removing it would orphan a live relay and discard the
        # only durable handle for a later safe stop.
        if not stop_pair(pair_id):
            print(f"Error: Could not safely stop running pair '{pair_id}'; pair was not deleted.")
            return False
        # The nested stop committed a newer registry revision.
        data = load_pairs()

    data["pairs"] = [p for p in data["pairs"] if p["id"] != pair_id]
    save_pairs(data)
    print(f"Successfully deleted pair: {pair_id}")
    return True


@registry_writer
def archive_pair(pair_id):
    data = load_pairs()
    target = next((p for p in data["pairs"] if p["id"] == pair_id), None)
    if not target:
        print(f"Error: Pair ID '{pair_id}' not found.")
        return False
    if target.get("pid") or target.get("status") == "running":
        print("Error: Stop the pair and verify ownership before archiving it.")
        return False
    if target.get("status") != "archived":
        target["pre_archive_status"] = target.get("status", "stopped")
        target["status"] = "archived"
        target["archived_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        target["pid"] = None
        save_pairs(data)
    print(f"Archived pair '{pair_id}' without deleting its session references or history.")
    return True


@registry_writer
def restore_pair(pair_id):
    data = load_pairs()
    target = next((p for p in data["pairs"] if p["id"] == pair_id), None)
    if not target:
        print(f"Error: Pair ID '{pair_id}' not found.")
        return False
    if target.get("status") != "archived":
        print(f"Error: Pair '{pair_id}' is not archived.")
        return False
    target.pop("archived_at", None)
    target.pop("pre_archive_status", None)
    target["status"] = "stopped"
    target["pid"] = None
    save_pairs(data)
    print(f"Restored pair '{pair_id}' to STOPPED; no execution was started.")
    return True


@registry_writer
def start_pair(pair_id):
    if os.environ.get("BOT_REGISTRY_OWNER") == "node":
        print("[BLOCKED] Node owns relay lifecycle; supervisor cannot start a relay.")
        return False
    ensure_dirs()
    data = load_pairs()
    target = None
    for p in data["pairs"]:
        if p["id"] == pair_id:
            target = p
            break
    if not target:
        print(f"Error: Pair ID '{pair_id}' not found.")
        return False

    if target.get("status") == "archived":
        print(f"Error: Pair '{pair_id}' is archived. Restore it to STOPPED before starting.")
        return False

    try:
        # Check before stale/live-PID reconciliation so archived pairs cannot
        # be reported as running or automatically resumed.
        with authorize(pair_id, "supervisor_start_preflight", target.get("chatgpt_url"), target.get("session_id")):
            pass
    except PairExecutionError as exc:
        print(f"Error: {exc}")
        return False

    if target.get("pid") and is_pid_running(target["pid"]):
        verified, reason, _identity = verify_relay_ownership(
            target["pid"], expected_session_id=target.get("session_id"))
        if verified:
            print(f"Pair '{pair_id}' is already running (PID: {target['pid']}).")
            return True
        print(f"[BLOCKED] Pair '{pair_id}' has an active but unverifiable PID; refusing a second owner: {reason}")
        return False

    log_file_path = os.path.join(RUN_DIR, f"{pair_id}.log")

    # Command to run isolated relay instance using exact core logic
    opencode_bin = target.get("opencode_bin") or os.environ.get("BOT_OPENCODE_BIN") or "opencode"
    runner_code = (
        f"import relay_chatgpt_opencode as r; r.PAIR_ID = {json.dumps(pair_id)}; "
        f"r.CHATGPT_URL = {json.dumps(target['chatgpt_url'])}; "
        f"r.SESSION_ID = {json.dumps(target['session_id'])}; "
        f"r.OPENCODE_BIN = {json.dumps(opencode_bin)}; "
        f"import managed_relay; managed_relay.run(r, managed=False)"
    )

    try:
        # Hold the shared policy lock through the final spawn. This prevents a
        # concurrent pair execution writer from racing this launch.
        with authorize(pair_id, "supervisor_start", target.get("chatgpt_url"), target.get("session_id")):
            with open(log_file_path, "a") as log_file:
                proc = subprocess.Popen(
                    [sys.executable, "-c", runner_code],
                    cwd=BASE_DIR,
                    stdout=log_file,
                    stderr=subprocess.STDOUT,
                    start_new_session=True,
                    env={**os.environ, "BOT_RUN_DIR": RUN_DIR},
                )
    except PairExecutionError as exc:
        print(f"Error: {exc}")
        return False

    # The child acquires the OS-level pair lock before entering the loop. Do not
    # publish a dead child as running if another owner already holds that lock.
    time.sleep(0.05)
    if proc.poll() is not None:
        print(f"[BLOCKED] Relay child exited before ownership was established (status={proc.returncode}).")
        return False
    target["pid"] = proc.pid
    target["status"] = "running"
    save_pairs(data)
    print(f"Started pair '{pair_id}' (PID: {proc.pid}). Logs: {log_file_path}")
    return True


@registry_writer
def stop_pair(pair_id, as_json=False, pid_override=None, session_override=None):
    """Stop a relay and its `opencode run` child.

    Ownership is verified before any signal is sent: a recorded pid can be
    stale or reused, and signalling an unrelated process would be far worse
    than reporting that we could not confirm what this pid is.

    The stop itself is delegated to relay_process.stop_relay(), which signals
    the relay's process group so the `opencode run` child receives the same
    SIGTERM instead of being orphaned. There is no automatic SIGKILL
    escalation; if the relay outlives the wait window it is left running for
    manual recovery and that fact is reported.

    The pair record is only updated once termination is actually observed.
    """
    def emit(payload):
        if as_json:
            print(json.dumps(payload))
        else:
            for key, value in payload.items():
                if value is not None and value != [] and value != "":
                    print(f"{key}: {value}")

    managed = os.environ.get("BOT_REGISTRY_OWNER") == "node"
    if managed and (not pid_override or pid_override <= 0 or not session_override):
        emit({"stopped": False, "verified": False,
              "error": "Node-owned stop requires an explicit positive PID and session identity."})
        return False
    # Managed mode is an OS-operation helper only. Never consult or mutate a
    # compatibility registry, even when it contains a matching pair ID.
    data = {"pairs": []} if managed else load_pairs()
    target = None
    for p in data["pairs"]:
        if p["id"] == pair_id:
            target = p
            break
    # The packaged server may use SQLite for its authoritative pair registry,
    # while this compatibility supervisor historically reads pairs.json.  The
    # server therefore passes an ownership-verified PID and session explicitly
    # for stop operations; never require a second, stale registry lookup.
    registry_target = target
    if target is None and pid_override:
        target = {"id": pair_id, "pid": pid_override, "session_id": session_override}
    if not target:
        payload = {"stopped": False, "verified": False,
                   "error": f"Pair ID '{pair_id}' not found."}
        emit(payload)
        return False

    pid = pid_override or target.get("pid")
    if not pid or not is_pid_running(pid):
        target["status"] = "stopped"
        target["pid"] = None
        if registry_target is not None:
            save_pairs(data)
        payload = {"stopped": True, "verified": True, "reason": "already stopped",
                   "pid": pid}
        emit(payload)
        return True

    result = stop_relay(pid, expected_session_id=session_override or target.get("session_id"))
    result["pid"] = pid

    if result.get("stopped") and registry_target is not None:
        target["status"] = "stopped"
        target["pid"] = None
        save_pairs(data)
    # Otherwise leave the record untouched: the relay is still running and the
    # pid must stay recorded so a later stop can target it.

    emit(result)
    return bool(result.get("stopped"))


def get_logs(pair_id, lines=50):
    log_file_path = os.path.join(RUN_DIR, f"{pair_id}.log")
    if not os.path.exists(log_file_path):
        print(f"No log file found for pair '{pair_id}'.")
        return ""
    with open(log_file_path, "r") as f:
        content = f.readlines()
        tail = "".join(content[-lines:])
        print(tail)
        return tail


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 relay_supervisor.py [list|add|start|stop|delete|logs]")
        sys.exit(1)

    cmd = sys.argv[1]
    if os.environ.get("BOT_REGISTRY_OWNER") == "node" and cmd not in ("stop", "logs"):
        print("Node owns relay lifecycle and registry; only stop/logs helpers are permitted.")
        sys.exit(1)
    if cmd == "list":
        list_pairs()
    elif cmd == "add" and len(sys.argv) >= 6:
        bin_path = sys.argv[6] if len(sys.argv) > 6 else (os.environ.get("BOT_OPENCODE_BIN") or "opencode")
        add_pair(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], bin_path)
    elif cmd == "start" and len(sys.argv) >= 3:
        start_pair(sys.argv[2])
    elif cmd == "stop" and len(sys.argv) >= 3:
        pid = None
        session_id = None
        if "--pid" in sys.argv:
            try:
                pid = int(sys.argv[sys.argv.index("--pid") + 1])
            except (ValueError, IndexError):
                pid = None
        if "--session-id" in sys.argv:
            try:
                session_id = sys.argv[sys.argv.index("--session-id") + 1]
            except IndexError:
                session_id = None
        stop_pair(sys.argv[2], as_json="--json" in sys.argv, pid_override=pid, session_override=session_id)
    elif cmd == "delete" and len(sys.argv) >= 3:
        delete_pair(sys.argv[2])
    elif cmd == "logs" and len(sys.argv) >= 3:
        get_logs(sys.argv[2])
    else:
        print("Invalid command or missing arguments.")
        sys.exit(1)
