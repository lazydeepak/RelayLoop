import Database from 'better-sqlite3';
import { createHash } from 'node:crypto';
import crypto from 'node:crypto';
export function payloadFingerprint(payload) {
    return { sha256: createHash('sha256').update(payload, 'utf8').digest('hex'), length: Buffer.byteLength(payload, 'utf8') };
}
function isoNow() { return new Date().toISOString(); }
function asRecord(row) {
    return {
        pairId: row.pair_id,
        sourceId: row.source_id,
        direction: row.direction,
        destination: row.destination,
        payloadSha256: row.payload_sha256,
        payloadLength: Number(row.payload_length),
        sourceRole: row.source_role,
        sourcePolicy: row.source_policy,
        sourceConversationId: row.source_conversation_id,
        sourceObservedAt: row.source_observed_at,
        observationBoundary: row.observation_boundary,
        status: row.status,
        attemptCount: Number(row.attempt_count),
        executionEpoch: Number(row.execution_epoch),
        ownerHostId: row.owner_host_id,
        submissionStartedAt: row.submission_started_at,
        acknowledgedAt: row.acknowledged_at,
        evidence: row.evidence,
        createdAt: row.created_at || row.updated_at || isoNow(),
        updatedAt: row.updated_at,
    };
}
function asTurnState(row) {
    return {
        pairId: row.pair_id,
        expectedSpeaker: row.expected_speaker,
        plannerWatermark: row.planner_watermark,
        workerWatermark: row.worker_watermark,
        revision: Number(row.revision),
        updatedAt: row.updated_at,
    };
}
export class DeliveryJournal {
    db;
    constructor(dbPath) {
        this.db = new Database(dbPath);
        this.db.pragma('journal_mode = WAL');
        this.db.pragma('synchronous = FULL');
        this.db.pragma('busy_timeout = 5000');
        this.db.exec(`
      CREATE TABLE IF NOT EXISTS delivery_records (
        pair_id TEXT NOT NULL,
        source_id TEXT NOT NULL,
        direction TEXT NOT NULL,
        destination TEXT NOT NULL,
        payload_sha256 TEXT NOT NULL,
        payload_length INTEGER NOT NULL,
        source_role TEXT NOT NULL DEFAULT 'legacy_untyped',
        source_policy TEXT NOT NULL DEFAULT 'legacy_untyped',
        source_conversation_id TEXT NOT NULL DEFAULT '',
        source_observed_at TEXT NOT NULL DEFAULT '',
        observation_boundary TEXT NOT NULL DEFAULT '{}',
        status TEXT NOT NULL,
        attempt_count INTEGER NOT NULL DEFAULT 0,
        execution_epoch INTEGER NOT NULL,
        owner_host_id TEXT NOT NULL,
         submission_started_at TEXT,
         acknowledged_at TEXT,
         evidence TEXT,
         created_at TEXT NOT NULL DEFAULT '',
         updated_at TEXT NOT NULL,
        PRIMARY KEY (pair_id, source_id)
      );
      CREATE INDEX IF NOT EXISTS delivery_records_status
      ON delivery_records(pair_id, status);
      CREATE TABLE IF NOT EXISTS consumed_turns (
        pair_id TEXT NOT NULL,
        direction TEXT NOT NULL,
        source_id TEXT NOT NULL,
        acknowledged_at TEXT NOT NULL,
        PRIMARY KEY (pair_id, direction, source_id)
      );
      CREATE TABLE IF NOT EXISTS pair_turn_state (
        pair_id TEXT PRIMARY KEY,
        expected_speaker TEXT NOT NULL CHECK (expected_speaker IN ('planner', 'worker')),
        planner_watermark TEXT,
        worker_watermark TEXT,
        revision INTEGER NOT NULL DEFAULT 0,
        updated_at TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS pair_enrollments (
        pair_id TEXT PRIMARY KEY,
        enrollment_mode TEXT NOT NULL CHECK (enrollment_mode IN ('fresh', 'migrated')),
        history_verified INTEGER NOT NULL CHECK (history_verified IN (0, 1)),
        enrollment_evidence TEXT NOT NULL,
        chatgpt_conversation_id TEXT,
        opencode_session_id TEXT,
        enrolled_at TEXT NOT NULL,
        enrolled_by TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS migration_barriers (
        barrier_id TEXT PRIMARY KEY,
        pair_id TEXT NOT NULL,
        source_id TEXT NOT NULL,
        direction TEXT NOT NULL,
        destination TEXT NOT NULL,
        evidence_type TEXT NOT NULL CHECK (evidence_type IN ('complete_fingerprint', 'historical_identity_only')),
        payload_sha256 TEXT,
        payload_length INTEGER,
        source_conversation_id TEXT NOT NULL DEFAULT '',
        uncertainty_reason TEXT NOT NULL,
        original_evidence TEXT NOT NULL,
        status TEXT NOT NULL CHECK (status IN ('open', 'quarantined', 'reconciled')),
        created_at TEXT NOT NULL,
        decided_at TEXT,
        decision TEXT,
        decision_actor TEXT,
        decision_context TEXT,
        decision_evidence TEXT,
        UNIQUE(pair_id, source_id)
      );
      CREATE TABLE IF NOT EXISTS migration_barrier_decisions (
        audit_id TEXT PRIMARY KEY,
        barrier_id TEXT NOT NULL,
        pair_id TEXT NOT NULL,
        from_status TEXT NOT NULL,
        to_status TEXT NOT NULL,
        decision TEXT NOT NULL,
        actor TEXT NOT NULL,
        authorization_context TEXT NOT NULL,
        evidence TEXT NOT NULL,
        created_at TEXT NOT NULL
      );
    `);
        const columns = this.db.prepare('PRAGMA table_info(delivery_records)').all();
        if (!columns.some((column) => column.name === 'created_at')) {
            this.db.exec("ALTER TABLE delivery_records ADD COLUMN created_at TEXT NOT NULL DEFAULT ''");
        }
        this.db.prepare("UPDATE delivery_records SET created_at = updated_at WHERE created_at = '' OR created_at IS NULL").run();
    }
    close() { this.db.close(); }
    get(key) {
        const row = this.db.prepare('SELECT * FROM delivery_records WHERE pair_id = ? AND source_id = ?').get(key.pairId, key.sourceId);
        return row ? asRecord(row) : null;
    }
    list(pairId) {
        return this.db.prepare('SELECT * FROM delivery_records WHERE pair_id = ? ORDER BY updated_at, source_id').all(pairId).map(asRecord);
    }
    getTurnState(pairId) {
        const row = this.db.prepare('SELECT * FROM pair_turn_state WHERE pair_id = ?').get(pairId);
        return row ? asTurnState(row) : null;
    }
    getEnrollment(pairId) {
        return this.db.prepare('SELECT * FROM pair_enrollments WHERE pair_id = ?').get(pairId) || null;
    }
    enrollPair(pairId, mode, historyVerified, evidence, chatgptConversationId, opencodeSessionId, actor, fence) {
        if (pairId !== fence.pairId || !fence.validate())
            throw new Error('stale or invalid execution fence');
        const existing = this.getEnrollment(pairId);
        if (existing) {
            if (existing.enrollment_mode !== mode || Number(existing.history_verified) !== (historyVerified ? 1 : 0) || existing.enrollment_evidence !== evidence || existing.chatgpt_conversation_id !== chatgptConversationId || existing.opencode_session_id !== opencodeSessionId)
                throw new Error('pair enrollment conflicts with existing record');
            return existing;
        }
        this.db.prepare('INSERT INTO pair_enrollments (pair_id, enrollment_mode, history_verified, enrollment_evidence, chatgpt_conversation_id, opencode_session_id, enrolled_at, enrolled_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)').run(pairId, mode, historyVerified ? 1 : 0, evidence.slice(0, 2000), chatgptConversationId, opencodeSessionId, isoNow(), actor);
        return this.getEnrollment(pairId);
    }
    listBarriers(pairId) {
        return this.db.prepare('SELECT * FROM migration_barriers WHERE pair_id = ? ORDER BY created_at, barrier_id').all(pairId).map((r) => ({
            barrierId: r.barrier_id, pairId: r.pair_id, sourceId: r.source_id, direction: r.direction, destination: r.destination,
            evidenceType: r.evidence_type, payloadSha256: r.payload_sha256 === null ? null : r.payload_sha256, payloadLength: r.payload_length === null ? null : Number(r.payload_length), sourceConversationId: r.source_conversation_id,
            uncertaintyReason: r.uncertainty_reason, originalEvidence: r.original_evidence, status: r.status,
            createdAt: r.created_at, decidedAt: r.decided_at, decision: r.decision, decisionActor: r.decision_actor,
            decisionContext: r.decision_context, decisionEvidence: r.decision_evidence,
        }));
    }
    createBarrier(input, fence) {
        if (input.pairId !== fence.pairId || !fence.validate())
            throw new Error('stale or invalid execution fence');
        if (input.originalEvidence.length > 2000 || input.uncertaintyReason.length > 1000)
            throw new Error('barrier evidence is too large');
        const existing = this.db.prepare('SELECT * FROM migration_barriers WHERE pair_id = ? AND source_id = ?').get(input.pairId, input.sourceId);
        if (existing) {
            if (existing.evidence_type !== input.evidenceType || existing.payload_sha256 !== input.payloadSha256 || (existing.payload_length === null ? null : Number(existing.payload_length)) !== input.payloadLength || existing.destination !== input.destination || existing.direction !== input.direction)
                throw new Error('migration barrier conflicts with existing identity');
            return this.listBarriers(input.pairId).find((b) => b.sourceId === input.sourceId);
        }
        this.db.prepare(`INSERT INTO migration_barriers (barrier_id, pair_id, source_id, direction, destination, evidence_type, payload_sha256, payload_length, source_conversation_id, uncertainty_reason, original_evidence, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'open', ?)`).run(input.barrierId, input.pairId, input.sourceId, input.direction, input.destination, input.evidenceType, input.payloadSha256, input.payloadLength, input.sourceConversationId || '', input.uncertaintyReason, input.originalEvidence, isoNow());
        return this.listBarriers(input.pairId).find((b) => b.barrierId === input.barrierId);
    }
    decideBarrier(barrierId, pairId, decision, actor, context, evidence, fence) {
        if (pairId !== fence.pairId || !fence.validate())
            throw new Error('stale or invalid execution fence');
        const row = this.db.prepare('SELECT * FROM migration_barriers WHERE barrier_id = ? AND pair_id = ?').get(barrierId, pairId);
        if (!row)
            throw new Error('migration barrier is missing');
        const target = decision === 'quarantine_and_continue' ? 'quarantined' : decision === 'reconcile_confirmed' || decision === 'reconcile_failed' ? 'reconciled' : '';
        if (!target)
            throw new Error('unsupported recovery decision');
        if (row.status !== 'open')
            throw new Error(`migration barrier is already ${row.status}`);
        if (decision === 'reconcile_confirmed' && row.evidence_type === 'historical_identity_only')
            throw new Error('identity-only historical barrier cannot be confirmed');
        const tx = this.db.transaction(() => {
            const now = isoNow();
            this.db.prepare('UPDATE migration_barriers SET status = ?, decided_at = ?, decision = ?, decision_actor = ?, decision_context = ?, decision_evidence = ? WHERE barrier_id = ? AND status = ?').run(target, now, decision, actor, context, evidence.slice(0, 2000), barrierId, 'open');
            this.db.prepare('INSERT INTO migration_barrier_decisions (audit_id, barrier_id, pair_id, from_status, to_status, decision, actor, authorization_context, evidence, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').run(crypto.randomUUID(), barrierId, pairId, 'open', target, decision, actor, context, evidence.slice(0, 2000), now);
        });
        tx();
        return this.listBarriers(pairId).find((b) => b.barrierId === barrierId);
    }
    listBarrierAudit(pairId) { return this.db.prepare('SELECT * FROM migration_barrier_decisions WHERE pair_id = ? ORDER BY created_at, audit_id').all(pairId); }
    startupGate(pairId) {
        return { enrolled: this.getEnrollment(pairId), barriers: this.listBarriers(pairId) };
    }
    initializeTurnState(pairId, expectedSpeaker, watermarks, fence) {
        if (pairId !== fence.pairId || !fence.validate())
            throw new Error('stale or invalid execution fence');
        const existing = this.getTurnState(pairId);
        if (existing)
            return existing;
        this.db.prepare(`INSERT INTO pair_turn_state
      (pair_id, expected_speaker, planner_watermark, worker_watermark, revision, updated_at)
      VALUES (?, ?, ?, ?, 0, ?)`)
            .run(pairId, expectedSpeaker, watermarks.planner, watermarks.worker, isoNow());
        return this.getTurnState(pairId);
    }
    /** Persist intent before any provider/browser action. */
    create(claim, fence) {
        if (claim.pairId !== fence.pairId || claim.executionEpoch !== fence.executionEpoch || claim.ownerHostId !== fence.ownerHostId || !fence.validate()) {
            throw new Error('stale or invalid execution fence');
        }
        const fp = payloadFingerprint(claim.payload);
        const timestamp = isoNow();
        this.db.prepare(`
      INSERT INTO delivery_records
        (pair_id, source_id, direction, destination, payload_sha256,
         payload_length, source_role, source_policy, source_conversation_id,
         source_observed_at, observation_boundary, status, execution_epoch,
          owner_host_id, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'created', ?, ?, ?, ?)
    `).run(claim.pairId, claim.sourceId, claim.direction, claim.destination, fp.sha256, fp.length, claim.sourceRole || 'legacy_untyped', claim.sourcePolicy || 'legacy_untyped', claim.sourceConversationId || '', claim.sourceObservedAt || '', claim.observationBoundary || '{}', claim.executionEpoch, claim.ownerHostId, timestamp, timestamp);
        return this.get(claim);
    }
    /** Atomically claim a source ID for one owner immediately before submission. */
    beginSubmission(claim, fence) {
        if (claim.pairId !== fence.pairId || claim.executionEpoch !== fence.executionEpoch || claim.ownerHostId !== fence.ownerHostId || !fence.validate()) {
            return { ok: false, reason: 'stale or invalid execution fence' };
        }
        const fp = payloadFingerprint(claim.payload);
        const tx = this.db.transaction(() => {
            const current = this.get(claim);
            if (!current)
                return { ok: false, reason: 'delivery intent is missing' };
            if (current.payloadSha256 !== fp.sha256 || current.payloadLength !== fp.length) {
                return { ok: false, reason: 'source payload fingerprint changed', record: current };
            }
            if (current.status === 'submitting' || current.status === 'uncertain' || current.status === 'confirmed' || current.status === 'reconciled') {
                return { ok: false, reason: `delivery is already ${current.status}`, record: current };
            }
            const timestamp = isoNow();
            const changed = this.db.prepare(`
        UPDATE delivery_records
        SET status = 'submitting', attempt_count = attempt_count + 1,
            submission_started_at = ?, execution_epoch = ?, owner_host_id = ?, updated_at = ?
        WHERE pair_id = ? AND source_id = ?
          AND status IN ('created', 'failed-before-submit')
          AND payload_sha256 = ? AND payload_length = ?
      `).run(timestamp, claim.executionEpoch, claim.ownerHostId, timestamp, claim.pairId, claim.sourceId, fp.sha256, fp.length);
            if (changed.changes !== 1)
                return { ok: false, reason: 'delivery claim lost to another owner', record: this.get(claim) };
            return { ok: true, reason: 'submission durably claimed', record: this.get(claim) };
        });
        return tx();
    }
    markUncertain(key, evidence, fence) {
        if (!this.acceptsFence(key, fence))
            throw new Error('stale or invalid execution fence');
        const changed = this.db.prepare(`
      UPDATE delivery_records SET status = 'uncertain', evidence = ?, updated_at = ?
      WHERE pair_id = ? AND source_id = ? AND status = 'submitting'
    `).run(evidence.slice(0, 2000), isoNow(), key.pairId, key.sourceId);
        if (changed.changes !== 1)
            throw new Error('delivery is not submitting');
        return this.get(key);
    }
    markFailedBeforeSubmit(key, evidence, fence) {
        if (!this.acceptsFence(key, fence))
            throw new Error('stale or invalid execution fence');
        const changed = this.db.prepare(`
      UPDATE delivery_records SET status = 'failed-before-submit', evidence = ?, updated_at = ?
      WHERE pair_id = ? AND source_id = ? AND status = 'created'
    `).run(evidence.slice(0, 2000), isoNow(), key.pairId, key.sourceId);
        if (changed.changes !== 1)
            throw new Error('delivery cannot be classified as pre-submit failure');
        return this.get(key);
    }
    confirmObserved(key, evidence, fence) {
        if (!this.acceptsFence(key, fence))
            throw new Error('stale or invalid execution fence');
        const changed = this.db.prepare(`
      UPDATE delivery_records
      SET status = 'confirmed', evidence = ?, acknowledged_at = ?, updated_at = ?
      WHERE pair_id = ? AND source_id = ? AND status IN ('submitting', 'uncertain')
    `).run(evidence.slice(0, 2000), isoNow(), isoNow(), key.pairId, key.sourceId);
        if (changed.changes !== 1)
            throw new Error('delivery is not awaiting acknowledgment');
        return this.get(key);
    }
    /** Acknowledgment-only recovery. This method has no transport argument by design. */
    reconcile(key, evidence, fence) {
        if (!this.acceptsPairFence(key, fence))
            throw new Error('stale or invalid execution fence');
        const current = this.get(key);
        if (!current)
            throw new Error('delivery record is missing');
        if (current.status === 'reconciled')
            return current;
        if (current.status !== 'uncertain' && current.status !== 'confirmed') {
            throw new Error(`delivery cannot be reconciled from ${current.status}`);
        }
        this.db.prepare(`
      UPDATE delivery_records SET status = 'reconciled', evidence = ?, acknowledged_at = COALESCE(acknowledged_at, ?), updated_at = ?
      WHERE pair_id = ? AND source_id = ? AND status IN ('uncertain', 'confirmed')
    `).run(evidence.slice(0, 2000), isoNow(), isoNow(), key.pairId, key.sourceId);
        return this.get(key);
    }
    /**
     * Record turn advancement separately from delivery acknowledgment.  The
     * primary key makes duplicate ChatGPT copies idempotent; this table is not a
     * replacement for the relay's directional watermark.
     */
    consumeOnce(key, fence) {
        if (!this.acceptsPairFence(key, fence))
            throw new Error('stale or invalid execution fence');
        const record = this.get(key);
        if (!record || record.status !== 'reconciled')
            throw new Error('delivery is not reconciled');
        const result = this.db.prepare(`
      INSERT OR IGNORE INTO consumed_turns (pair_id, direction, source_id, acknowledged_at)
      VALUES (?, ?, ?, ?)
    `).run(record.pairId, record.direction, record.sourceId, isoNow());
        return result.changes === 1;
    }
    /** Atomically consume a reconciled delivery and advance the durable turn. */
    consumeAndAdvance(key, direction, evidenceId, expectedPreviousTurn, nextExpectedSpeaker, updatedWatermark, fence) {
        if (!this.acceptsPairFence(key, fence))
            throw new Error('stale or invalid execution fence');
        if (!evidenceId || evidenceId.length > 256)
            throw new Error('evidence ID is required');
        const tx = this.db.transaction(() => {
            const state = this.getTurnState(key.pairId);
            if (!state)
                throw new Error('pair turn state is missing');
            const alreadyConsumed = this.db.prepare('SELECT 1 FROM consumed_turns WHERE pair_id = ? AND direction = ? AND source_id = ?').get(key.pairId, direction, key.sourceId);
            if (alreadyConsumed)
                return { consumed: false, state };
            const record = this.get(key);
            if (!record || record.status !== 'reconciled')
                throw new Error('delivery is not reconciled');
            if (state.expectedSpeaker !== expectedPreviousTurn)
                throw new Error('expected turn does not match durable state');
            if (direction === 'chatgpt_to_opencode' && key.sourceId !== updatedWatermark.planner)
                throw new Error('planner watermark must consume the source ID');
            if (direction === 'opencode_to_chatgpt' && key.sourceId !== updatedWatermark.worker)
                throw new Error('worker watermark must consume the source ID');
            this.db.prepare(`INSERT INTO consumed_turns (pair_id, direction, source_id, acknowledged_at) VALUES (?, ?, ?, ?)`)
                .run(key.pairId, direction, key.sourceId, isoNow());
            const turnUpdate = this.db.prepare(`UPDATE pair_turn_state SET expected_speaker = ?, planner_watermark = ?, worker_watermark = ?, revision = revision + 1, updated_at = ? WHERE pair_id = ? AND expected_speaker = ?`)
                .run(nextExpectedSpeaker, updatedWatermark.planner, updatedWatermark.worker, isoNow(), key.pairId, expectedPreviousTurn);
            if (turnUpdate.changes !== 1)
                throw new Error('concurrent turn state mutation prevented advancement');
            return { consumed: true, state: this.getTurnState(key.pairId) };
        });
        return tx();
    }
    /** Crash recovery is conservative: submitting may have crossed the provider boundary. */
    recoverAfterRestart(pairId, fence) {
        if (fence.pairId !== pairId || !fence.validate())
            throw new Error('stale or invalid execution fence');
        const result = this.db.prepare(`
      UPDATE delivery_records SET status = 'uncertain', evidence = COALESCE(evidence || '; ', '') || 'recovered after restart', updated_at = ?
      WHERE pair_id = ? AND status = 'submitting'
    `).run(isoNow(), pairId);
        return result.changes;
    }
    /** Authority startup recovery: no submitting row is treated as safe to retry. */
    recoverAllSubmitting(evidence = 'recovered after authority restart') {
        const result = this.db.prepare(`
      UPDATE delivery_records
      SET status = 'uncertain',
          evidence = COALESCE(evidence || '; ', '') || ?,
          updated_at = ?
      WHERE status = 'submitting'
    `).run(evidence.slice(0, 2000), isoNow());
        return result.changes;
    }
    acceptsFence(key, fence) {
        const current = this.get(key);
        return Boolean(current)
            && current.pairId === fence.pairId
            && current.executionEpoch === fence.executionEpoch
            && current.ownerHostId === fence.ownerHostId
            && fence.validate();
    }
    acceptsPairFence(key, fence) {
        return key.pairId === fence.pairId && fence.validate();
    }
}
