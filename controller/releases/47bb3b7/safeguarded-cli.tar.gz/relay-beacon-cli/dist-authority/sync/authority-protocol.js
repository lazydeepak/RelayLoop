/** Versioned wire contract for the standalone local delivery authority. */
export const AUTHORITY_PROTOCOL_VERSION = 1;
export const AUTHORITY_SCHEMA_VERSION = 6;
export const AUTHORITY_MAX_FRAME_BYTES = 64 * 1024;
export function isSupportedVersion(request) {
    return request.protocol_version === AUTHORITY_PROTOCOL_VERSION
        && request.schema_version === AUTHORITY_SCHEMA_VERSION;
}
export function encodeFrame(value) {
    const raw = Buffer.from(`${JSON.stringify(value)}\n`, 'utf8');
    if (raw.byteLength > AUTHORITY_MAX_FRAME_BYTES)
        throw new Error('authority frame is too large');
    return raw;
}
export function parseFrame(raw) {
    const bytes = Buffer.isBuffer(raw) ? raw : Buffer.from(raw, 'utf8');
    if (bytes.byteLength > AUTHORITY_MAX_FRAME_BYTES)
        throw new Error('authority frame is too large');
    const value = JSON.parse(bytes.toString('utf8'));
    if (!value || typeof value !== 'object' || typeof value.id !== 'string' || !value.id || value.id.length > 128
        || typeof value.operation !== 'string' || !value.operation
        || typeof value.auth_token !== 'string') {
        throw new Error('malformed authority request');
    }
    return value;
}
export function response(id, ok, result, error) {
    return { id, ok, protocol_version: AUTHORITY_PROTOCOL_VERSION, schema_version: AUTHORITY_SCHEMA_VERSION, ...(result ? { result } : {}), ...(error ? { error } : {}) };
}
