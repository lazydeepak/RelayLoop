/**
 * Standalone local delivery authority.
 *
 * This process owns the SQLite journal, pair lease, and Planner browser
 * boundary. Clients submit durable intent and consume authority observations;
 * OpenCode remains outside this adapter on its native server/desktop path.
 * The authority never infers success from disconnects or retries uncertainty.
 */
import Database from 'better-sqlite3';
import crypto from 'node:crypto';
import fs from 'node:fs';
import net from 'node:net';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { DeliveryJournal, payloadFingerprint } from './delivery-journal.js';
import { AUTHORITY_MAX_FRAME_BYTES, AUTHORITY_PROTOCOL_VERSION, AUTHORITY_SCHEMA_VERSION, encodeFrame, isSupportedVersion, parseFrame, response, } from './authority-protocol.js';
function processStartTime(pid) {
    const result = spawnSync('ps', ['-p', String(pid), '-o', 'lstart='], { encoding: 'utf8', timeout: 2000 });
    if (result.error || result.status !== 0)
        return null;
    const value = String(result.stdout || '').trim();
    return value || null;
}
function validText(value, max = 4096) {
    return typeof value === 'string' && value.length > 0 && value.length <= max;
}
class AuthorityInstanceLock {
    path;
    held = false;
    constructor(dbPath) { this.path = `${dbPath}.authority.lock`; }
    acquire() {
        fs.mkdirSync(path.dirname(this.path), { recursive: true, mode: 0o700 });
        for (;;) {
            try {
                fs.mkdirSync(this.path, { mode: 0o700 });
                fs.writeFileSync(path.join(this.path, 'owner'), JSON.stringify({ pid: process.pid, start_time: processStartTime(process.pid), instance_id: crypto.randomUUID() }), { mode: 0o600 });
                this.held = true;
                return;
            }
            catch (error) {
                if (error.code !== 'EEXIST')
                    throw error;
                let owner;
                try {
                    owner = JSON.parse(fs.readFileSync(path.join(this.path, 'owner'), 'utf8'));
                }
                catch {
                    throw new Error('authority lock exists but its owner identity is unreadable');
                }
                if (!owner.pid || !owner.start_time)
                    throw new Error('authority lock owner identity is incomplete');
                const currentStart = processStartTime(owner.pid);
                if (!currentStart) {
                    try {
                        process.kill(owner.pid, 0);
                        throw new Error('authority lock owner process identity is unavailable');
                    }
                    catch (error) {
                        if (error.code !== 'ESRCH')
                            throw error;
                    }
                }
                else if (currentStart !== owner.start_time) {
                    fs.rmSync(this.path, { recursive: true, force: true });
                    continue;
                }
                throw new Error(`authority database is already owned by pid ${owner.pid}`);
            }
        }
    }
    release() {
        if (!this.held)
            return;
        this.held = false;
        fs.rmSync(this.path, { recursive: true, force: true });
    }
}
export function endpointFor(dataDir, platform = process.platform) {
    if (platform === 'win32')
        return `\\\\.\\pipe\\relay-beacon-${crypto.createHash('sha256').update(path.resolve(dataDir)).digest('hex').slice(0, 24)}`;
    return path.join(dataDir, 'delivery-authority.sock');
}
export class DeliveryAuthority {
    options;
    lock;
    journal;
    db;
    server;
    clients = new Set();
    identity;
    started = false;
    endpointOwned = false;
    constructor(options) {
        this.options = options;
        if (!validText(options.authToken, 4096))
            throw new Error('authority auth token is required');
        this.lock = new AuthorityInstanceLock(options.dbPath);
        this.identity = options.processIdentity || ((pid) => {
            const start = processStartTime(pid);
            return start ? { pid, start_time: start } : null;
        });
        this.server = net.createServer((socket) => this.handleConnection(socket));
        this.lock.acquire();
        let openedDb = null;
        try {
            openedDb = new Database(options.dbPath);
            this.db = openedDb;
            // Check an existing journal before changing SQLite pragmas or creating
            // tables.  Incompatible clients must be rejected without mutating the
            // older database, so schema compatibility is an admission gate rather
            // than a post-initialization check.
            const existingMetadata = this.db.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'authority_metadata'").get();
            if (existingMetadata?.name) {
                const existingSchema = this.db.prepare("SELECT value FROM authority_metadata WHERE key = 'schema_version'").get();
                if (existingSchema?.value && existingSchema.value !== String(AUTHORITY_SCHEMA_VERSION) && existingSchema.value !== '4' && existingSchema.value !== '5') {
                    throw new Error(`unsupported authority journal schema version: ${existingSchema.value}`);
                }
                if (existingSchema?.value === '4') {
                    const barrierTable = this.db.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'migration_barriers'").get();
                    if (barrierTable?.name) {
                        const columns = this.db.prepare('PRAGMA table_info(migration_barriers)').all();
                        if (!columns.some((column) => column.name === 'evidence_type')) {
                            const migrate = this.db.transaction(() => {
                                this.db.exec('ALTER TABLE migration_barriers RENAME TO migration_barriers_v4');
                                this.db.exec(`CREATE TABLE migration_barriers (
                  barrier_id TEXT PRIMARY KEY, pair_id TEXT NOT NULL, source_id TEXT NOT NULL,
                  direction TEXT NOT NULL, destination TEXT NOT NULL,
                  evidence_type TEXT NOT NULL CHECK (evidence_type IN ('complete_fingerprint', 'historical_identity_only')),
                  payload_sha256 TEXT, payload_length INTEGER,
                  source_conversation_id TEXT NOT NULL DEFAULT '', uncertainty_reason TEXT NOT NULL,
                  original_evidence TEXT NOT NULL, status TEXT NOT NULL CHECK (status IN ('open', 'quarantined', 'reconciled')),
                  created_at TEXT NOT NULL, decided_at TEXT, decision TEXT, decision_actor TEXT,
                  decision_context TEXT, decision_evidence TEXT, UNIQUE(pair_id, source_id)
                )`);
                                this.db.exec(`INSERT INTO migration_barriers
                  (barrier_id, pair_id, source_id, direction, destination, evidence_type, payload_sha256, payload_length,
                   source_conversation_id, uncertainty_reason, original_evidence, status, created_at, decided_at, decision,
                   decision_actor, decision_context, decision_evidence)
                  SELECT barrier_id, pair_id, source_id, direction, destination, 'complete_fingerprint', payload_sha256, payload_length,
                   source_conversation_id, uncertainty_reason, original_evidence, status, created_at, decided_at, decision,
                   decision_actor, decision_context, decision_evidence FROM migration_barriers_v4`);
                                this.db.exec('DROP TABLE migration_barriers_v4');
                                this.db.prepare("UPDATE authority_metadata SET value = '5' WHERE key = 'schema_version'").run();
                            });
                            migrate();
                        }
                    }
                    else {
                        this.db.prepare("UPDATE authority_metadata SET value = '5' WHERE key = 'schema_version'").run();
                    }
                }
                const currentSchema = this.db.prepare("SELECT value FROM authority_metadata WHERE key = 'schema_version'").get();
                if (currentSchema?.value === '5') {
                    const enrollmentTable = this.db.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'pair_enrollments'").get();
                    if (enrollmentTable?.name) {
                        const columns = this.db.prepare('PRAGMA table_info(pair_enrollments)').all();
                        const migrate = this.db.transaction(() => {
                            if (!columns.some((column) => column.name === 'chatgpt_conversation_id'))
                                this.db.exec('ALTER TABLE pair_enrollments ADD COLUMN chatgpt_conversation_id TEXT');
                            if (!columns.some((column) => column.name === 'opencode_session_id'))
                                this.db.exec('ALTER TABLE pair_enrollments ADD COLUMN opencode_session_id TEXT');
                            this.db.prepare("UPDATE authority_metadata SET value = '6' WHERE key = 'schema_version'").run();
                        });
                        migrate();
                    }
                    else {
                        this.db.prepare("UPDATE authority_metadata SET value = '6' WHERE key = 'schema_version'").run();
                    }
                }
            }
            this.db.pragma('journal_mode = WAL');
            this.db.pragma('synchronous = FULL');
            this.db.pragma('busy_timeout = 5000');
            this.db.exec(`
        CREATE TABLE IF NOT EXISTS authority_leases (
          pair_id TEXT PRIMARY KEY,
          host_id TEXT NOT NULL,
          epoch INTEGER NOT NULL,
          owner_token TEXT NOT NULL UNIQUE,
          pid INTEGER NOT NULL,
          process_start_time TEXT NOT NULL,
          status TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS submission_permits (
          permit_id TEXT PRIMARY KEY,
          pair_id TEXT NOT NULL,
          source_id TEXT NOT NULL,
          direction TEXT NOT NULL,
          destination TEXT NOT NULL,
          payload_sha256 TEXT NOT NULL,
          payload_length INTEGER NOT NULL,
          source_role TEXT NOT NULL DEFAULT 'legacy_untyped',
          source_policy TEXT NOT NULL DEFAULT 'legacy_untyped',
          source_conversation_id TEXT NOT NULL DEFAULT '',
          source_observed_at TEXT NOT NULL DEFAULT '',
          observation_boundary TEXT NOT NULL DEFAULT '{}',
          execution_epoch INTEGER NOT NULL,
          owner_token TEXT NOT NULL,
          created_at TEXT NOT NULL,
          UNIQUE(pair_id, source_id, destination, execution_epoch)
        );
        CREATE INDEX IF NOT EXISTS submission_permits_delivery
          ON submission_permits(pair_id, source_id);
        CREATE TABLE IF NOT EXISTS authority_request_receipts (
          request_id TEXT PRIMARY KEY,
          auth_digest TEXT NOT NULL,
          response_json TEXT NOT NULL,
          created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS authority_metadata (
          key TEXT PRIMARY KEY,
          value TEXT NOT NULL
        );
      `);
            this.db.prepare("INSERT OR IGNORE INTO authority_metadata (key, value) VALUES ('schema_version', ?)").run(String(AUTHORITY_SCHEMA_VERSION));
            const schema = this.db.prepare("SELECT value FROM authority_metadata WHERE key = 'schema_version'").get();
            if (schema?.value !== String(AUTHORITY_SCHEMA_VERSION))
                throw new Error(`unsupported authority journal schema version: ${schema?.value || 'missing'}`);
            this.journal = new DeliveryJournal(options.dbPath);
            // The instance lock was acquired before opening the database. This is a
            // verified authority-instance transition, not a client reconnect, so
            // unresolved submissions are conservatively fenced as uncertain.
            this.journal.recoverAllSubmitting('recovered after verified authority instance transition');
        }
        catch (error) {
            try {
                openedDb?.close();
            }
            catch { /* initialization may not have opened it */ }
            this.lock.release();
            throw error;
        }
    }
    async start() {
        if (this.started)
            return;
        await this.prepareEndpoint();
        await new Promise((resolve, reject) => {
            this.server.once('error', reject);
            this.server.listen(this.options.endpoint, () => resolve());
        });
        if (typeof this.options.endpoint === 'string' && process.platform !== 'win32') {
            try {
                fs.chmodSync(this.options.endpoint, 0o600);
            }
            catch (error) {
                await this.close();
                throw error;
            }
        }
        this.endpointOwned = true;
        this.started = true;
    }
    async close() {
        for (const client of this.clients)
            client.destroy();
        this.clients.clear();
        // Node's server.close() waits for keep-alive connections even after the
        // protocol clients have been destroyed. The authority is already quiesced
        // at this boundary, so close those owned sockets before awaiting drain;
        // otherwise synthetic and controlled shutdowns can hang indefinitely.
        this.server.closeAllConnections?.();
        if (this.started)
            await new Promise((resolve) => this.server.close(() => resolve()));
        this.started = false;
        this.journal.close();
        this.db.close();
        this.lock.release();
        if (this.endpointOwned && process.platform !== 'win32' && typeof this.options.endpoint === 'string') {
            try {
                fs.unlinkSync(this.options.endpoint);
            }
            catch { /* already absent */ }
        }
        this.endpointOwned = false;
    }
    async prepareEndpoint() {
        if (process.platform === 'win32' || !fs.existsSync(this.options.endpoint))
            return;
        const active = await new Promise((resolve) => {
            const probe = net.createConnection(this.options.endpoint);
            const done = (result) => { probe.destroy(); resolve(result); };
            probe.once('connect', () => done('active'));
            probe.once('error', (error) => done(error.code === 'ECONNREFUSED' || error.code === 'ENOENT' ? 'stale' : 'unknown'));
            setTimeout(() => done('unknown'), 500);
        });
        if (active === 'active')
            throw new Error('authority endpoint is already active; refusing to replace an unfamiliar process');
        if (active === 'unknown')
            throw new Error('authority endpoint ownership could not be verified');
        // A refused connection proves only that nobody answered. It does not
        // identify who created the socket, so never remove it automatically.
        throw new Error('authority endpoint exists but its ownership could not be verified; refusing to remove it');
    }
    handleConnection(socket) {
        this.clients.add(socket);
        socket.once('close', () => this.clients.delete(socket));
        let buffer = Buffer.alloc(0);
        let authenticated = false;
        socket.on('data', (chunk) => {
            buffer = Buffer.concat([buffer, Buffer.from(chunk)]);
            if (buffer.byteLength > (this.options.maxFrameBytes || AUTHORITY_MAX_FRAME_BYTES) * 2) {
                socket.destroy();
                return;
            }
            for (;;) {
                const newline = buffer.indexOf(0x0a);
                if (newline < 0)
                    return;
                const line = buffer.subarray(0, newline);
                buffer = buffer.subarray(newline + 1);
                if (line.byteLength > (this.options.maxFrameBytes || AUTHORITY_MAX_FRAME_BYTES)) {
                    socket.destroy();
                    return;
                }
                let request;
                try {
                    request = parseFrame(line);
                }
                catch (error) {
                    this.writeError(socket, '', 'malformed_request', error instanceof Error ? error.message : String(error));
                    return;
                }
                if (!isSupportedVersion(request)) {
                    this.writeError(socket, request.id, 'version_mismatch', 'unsupported authority protocol or schema version');
                    return;
                }
                if (!this.equalSecret(request.auth_token, this.options.authToken)) {
                    this.writeError(socket, request.id, 'unauthorized', 'authority credential rejected');
                    socket.end();
                    return;
                }
                authenticated = true;
                try {
                    const replay = this.replayedResponse(request);
                    if (replay) {
                        this.write(socket, replay);
                        continue;
                    }
                    const result = response(request.id, true, this.dispatch(request, authenticated));
                    this.rememberResponse(request, result);
                    this.write(socket, result);
                }
                catch (error) {
                    this.writeError(socket, request.id, 'request_rejected', error instanceof Error ? error.message : String(error));
                }
            }
        });
    }
    dispatch(request, _authenticated) {
        switch (request.operation) {
            case 'status': return { protocol_version: AUTHORITY_PROTOCOL_VERSION, schema_version: AUTHORITY_SCHEMA_VERSION, pid: process.pid };
            case 'acquire_pair': return this.acquirePair(request);
            case 'resume_pair': return this.resumePair(request);
            case 'release_pair': return this.releasePair(request);
            case 'claim_submission': return this.claimSubmission(request);
            case 'record_outcome': return this.recordOutcome(request);
            case 'reconcile': return this.reconcile(request);
            case 'consume_once': return this.consumeOnce(request);
            case 'initialize_turn_state': return this.initializeTurnState(request);
            case 'get_turn_state': return this.getTurnState(request);
            case 'consume_and_advance': return this.consumeAndAdvance(request);
            case 'diagnostics': return this.diagnostics(request);
            case 'startup_gate': return this.startupGate(request);
            case 'enroll_pair': return this.enrollPair(request);
            case 'planner_observe': return this.plannerObserve(request);
            case 'planner_watermark': return this.plannerWatermark(request);
            case 'planner_send': return this.plannerSend(request);
            case 'planner_verify': return this.plannerVerify(request);
            case 'create_migration_barrier': return this.createMigrationBarrier(request);
            case 'decide_migration_barrier': return this.decideMigrationBarrier(request);
            default: throw new Error('unknown authority operation');
        }
    }
    acquirePair(request) {
        if (!validText(request.pair_id) || !validText(request.host_id) || !request.credentials?.process)
            throw new Error('pair, host, and process identity are required');
        if (request.credentials.pair_id !== request.pair_id || request.credentials.host_id !== request.host_id)
            throw new Error('acquisition credentials do not match the requested pair');
        this.verifyProcess(request.credentials.process);
        const timestamp = new Date().toISOString();
        const ownerToken = crypto.randomBytes(32).toString('hex');
        const row = this.db.prepare('SELECT * FROM authority_leases WHERE pair_id = ?').get(request.pair_id);
        if (row?.status === 'active') {
            const current = this.identity(row.pid);
            if (current && current.start_time === row.process_start_time)
                throw new Error('pair is already owned');
            if (current) {
                // The PID was reused. That is a verified stale owner and may be
                // fenced by the next monotonically increasing execution epoch.
                this.db.prepare("UPDATE authority_leases SET status = 'released', updated_at = ? WHERE pair_id = ? AND epoch = ? AND owner_token = ?")
                    .run(new Date().toISOString(), row.pair_id, row.epoch, row.owner_token);
            }
            else {
                // A missing identity is not enough to take ownership: distinguish a
                // dead PID from an OS-level identity lookup failure.
                try {
                    process.kill(row.pid, 0);
                    throw new Error('pair owner identity is unverifiable; refusing takeover');
                }
                catch (error) {
                    if (error.code !== 'ESRCH')
                        throw error;
                    this.db.prepare("UPDATE authority_leases SET status = 'released', updated_at = ? WHERE pair_id = ? AND epoch = ? AND owner_token = ?")
                        .run(new Date().toISOString(), row.pair_id, row.epoch, row.owner_token);
                }
            }
        }
        const epoch = (row?.epoch || 0) + 1;
        this.db.prepare(`INSERT INTO authority_leases (pair_id, host_id, epoch, owner_token, pid, process_start_time, status, updated_at) VALUES (?, ?, ?, ?, ?, ?, 'active', ?) ON CONFLICT(pair_id) DO UPDATE SET host_id=excluded.host_id, epoch=excluded.epoch, owner_token=excluded.owner_token, pid=excluded.pid, process_start_time=excluded.process_start_time, status='active', updated_at=excluded.updated_at`).run(request.pair_id, request.host_id, epoch, ownerToken, request.credentials.process.pid, request.credentials.process.start_time, timestamp);
        return { pair_id: request.pair_id, host_id: request.host_id, execution_epoch: epoch, owner_token: ownerToken };
    }
    resumePair(request) {
        const credentials = this.credentials(request);
        this.verifyProcess(credentials.process);
        const row = this.lease(credentials);
        if (!row || row.status !== 'active')
            throw new Error('pair lease is not active');
        return { pair_id: row.pair_id, host_id: row.host_id, execution_epoch: row.epoch, owner_token: row.owner_token };
    }
    releasePair(request) {
        const credentials = this.credentials(request);
        const row = this.lease(credentials);
        if (!row || row.status !== 'active')
            throw new Error('pair lease is not active');
        this.db.prepare("UPDATE authority_leases SET status = 'released', updated_at = ? WHERE pair_id = ? AND epoch = ? AND owner_token = ?").run(new Date().toISOString(), credentials.pair_id, credentials.execution_epoch, credentials.owner_token);
        return { released: true };
    }
    claimSubmission(request) {
        const credentials = this.credentials(request);
        this.assertLease(credentials);
        const gate = this.journal.startupGate(credentials.pair_id);
        if (!gate.enrolled || gate.enrolled.history_verified !== 1)
            throw new Error('pair is not enrolled for durable dispatch');
        const chatgptBinding = request.chatgpt_conversation_id || credentials.chatgpt_conversation_id;
        const opencodeBinding = request.opencode_session_id || credentials.opencode_session_id;
        if (!validText(chatgptBinding) || !validText(opencodeBinding) || gate.enrolled.chatgpt_conversation_id !== chatgptBinding || gate.enrolled.opencode_session_id !== opencodeBinding)
            throw new Error('pair enrollment binding does not match claim configuration');
        const excluded = gate.barriers.find((b) => b.sourceId === request.source_id);
        if (excluded)
            throw new Error(`source is permanently excluded by migration barrier ${excluded.barrierId}; live startup synchronization does not replay historical sources`);
        if (!validText(request.source_id) || !validText(request.direction) || !validText(request.destination) || typeof request.payload !== 'string')
            throw new Error('delivery identity and payload are required');
        const sourceRole = request.source_role || 'legacy_untyped';
        const sourcePolicy = request.source_policy || 'legacy_untyped';
        const sourceConversationId = request.source_conversation_id || '';
        const sourceObservedAt = request.source_observed_at || '';
        const observationBoundary = JSON.stringify(request.observation_boundary || {});
        const claim = { pairId: credentials.pair_id, sourceId: request.source_id, direction: request.direction, destination: request.destination, payload: request.payload, sourceRole, sourcePolicy, sourceConversationId, sourceObservedAt, observationBoundary, executionEpoch: credentials.execution_epoch, ownerHostId: credentials.host_id };
        const fence = this.fence(credentials);
        const fingerprint = payloadFingerprint(request.payload);
        const existingPermit = this.db.prepare('SELECT * FROM submission_permits WHERE pair_id = ? AND source_id = ? AND destination = ? AND execution_epoch = ?').get(credentials.pair_id, request.source_id, request.destination, credentials.execution_epoch);
        if (existingPermit) {
            if (existingPermit.direction !== request.direction || existingPermit.payload_sha256 !== fingerprint.sha256 || Number(existingPermit.payload_length) !== fingerprint.length || existingPermit.source_role !== sourceRole || existingPermit.source_policy !== sourcePolicy || existingPermit.source_conversation_id !== sourceConversationId) {
                throw new Error('submission identity or payload fingerprint conflicts with existing permit');
            }
            return { permit_id: existingPermit.permit_id, status: this.journal.get(claim)?.status || 'unknown', attempt_count: this.journal.get(claim)?.attemptCount || 0, payload_sha256: fingerprint.sha256, payload_length: fingerprint.length, replayed: true, reusable: false };
        }
        const current = this.journal.get(claim);
        if (!current)
            this.journal.create(claim, fence);
        const begun = this.journal.beginSubmission(claim, fence);
        if (!begun.ok)
            throw new Error(begun.reason);
        const permitId = crypto.randomUUID();
        this.db.prepare('INSERT INTO submission_permits (permit_id, pair_id, source_id, direction, destination, payload_sha256, payload_length, source_role, source_policy, source_conversation_id, source_observed_at, observation_boundary, execution_epoch, owner_token, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').run(permitId, credentials.pair_id, request.source_id, request.direction, request.destination, fingerprint.sha256, fingerprint.length, sourceRole, sourcePolicy, sourceConversationId, sourceObservedAt, observationBoundary, credentials.execution_epoch, credentials.owner_token, new Date().toISOString());
        return { permit_id: permitId, status: begun.record?.status || 'submitting', attempt_count: begun.record?.attemptCount || 1, payload_sha256: fingerprint.sha256, payload_length: fingerprint.length, replayed: false, reusable: true };
    }
    recordOutcome(request) {
        const credentials = this.credentials(request);
        this.assertLease(credentials);
        const permit = this.permit(request, credentials);
        const key = { pairId: credentials.pair_id, sourceId: permit.source_id };
        const fence = this.fence(credentials);
        if (request.evidence && request.evidence.length > 2000)
            throw new Error('evidence is too large');
        if (request.destination && request.destination !== permit.destination)
            throw new Error('destination does not match permit');
        const outcome = request.evidence ? request.evidence : 'no evidence supplied';
        if (request.source_id && request.source_id !== permit.source_id)
            throw new Error('source does not match permit');
        const status = request.outcome;
        if (status === 'confirmed') {
            this.validateConfirmationEvidence(outcome, permit);
            return { status: this.journal.confirmObserved(key, outcome, fence).status };
        }
        if (status === 'uncertain')
            return { status: this.journal.markUncertain(key, outcome, fence).status };
        throw new Error('record_outcome requires outcome=confirmed or outcome=uncertain');
    }
    validateConfirmationEvidence(raw, permit) {
        let evidence;
        try {
            evidence = JSON.parse(raw);
        }
        catch {
            throw new Error('confirmed evidence must be structured JSON');
        }
        if (!evidence || typeof evidence !== 'object'
            || evidence.destination_id !== permit.destination
            || evidence.source_id !== permit.source_id
            || typeof evidence.destination_message_id !== 'string' || evidence.destination_message_id.length === 0
            || typeof evidence.message_boundary !== 'string' || evidence.message_boundary.length === 0
            || evidence.payload_sha256 !== permit.payload_sha256
            || Number(evidence.payload_length) !== Number(permit.payload_length)
            || typeof evidence.observed_at !== 'string' || typeof evidence.provenance !== 'string' || evidence.provenance.length === 0
            || evidence.beyond_watermark !== true) {
            throw new Error('confirmed evidence lacks destination identity, source correlation, message boundary, or post-watermark proof');
        }
    }
    reconcile(request) {
        const credentials = this.credentials(request);
        this.assertLease(credentials);
        if (!validText(request.source_id) || !validText(request.evidence, 2000))
            throw new Error('source and reconciliation evidence are required');
        return { status: this.journal.reconcile({ pairId: credentials.pair_id, sourceId: request.source_id }, request.evidence, this.fence(credentials)).status };
    }
    consumeOnce(request) {
        const credentials = this.credentials(request);
        this.assertLease(credentials);
        if (!validText(request.source_id))
            throw new Error('source is required');
        return { consumed: this.journal.consumeOnce({ pairId: credentials.pair_id, sourceId: request.source_id }, this.fence(credentials)) };
    }
    initializeTurnState(request) {
        const credentials = this.credentials(request);
        this.assertLease(credentials);
        if (!request.expected_speaker || !request.updated_watermark)
            throw new Error('turn state requires expected speaker and watermarks');
        return this.journal.initializeTurnState(credentials.pair_id, request.expected_speaker, request.updated_watermark, this.fence(credentials));
    }
    getTurnState(request) {
        if (!validText(request.pair_id))
            throw new Error('pair is required');
        return (this.journal.getTurnState(request.pair_id) || {});
    }
    consumeAndAdvance(request) {
        const credentials = this.credentials(request);
        this.assertLease(credentials);
        if (!validText(request.source_id) || !validText(request.direction) || !validText(request.evidence_id)
            || !request.expected_previous_turn || !request.next_expected_speaker || !request.updated_watermark) {
            throw new Error('atomic turn consumption requires source, direction, evidence, expected turn, next speaker, and watermarks');
        }
        const result = this.journal.consumeAndAdvance({ pairId: credentials.pair_id, sourceId: request.source_id }, request.direction, request.evidence_id, request.expected_previous_turn, request.next_expected_speaker, request.updated_watermark, this.fence(credentials));
        return result;
    }
    diagnostics(request) {
        if (!validText(request.pair_id))
            throw new Error('pair is required');
        const deliveries = this.journal.list(request.pair_id).map((delivery) => {
            const permit = this.db.prepare('SELECT permit_id FROM submission_permits WHERE pair_id = ? AND source_id = ? ORDER BY created_at DESC LIMIT 1').get(request.pair_id, delivery.sourceId);
            return { ...delivery, permitId: permit?.permit_id || null };
        });
        const gate = this.journal.startupGate(request.pair_id);
        return { deliveries, turn_state: this.journal.getTurnState(request.pair_id), lease: this.db.prepare('SELECT pair_id, host_id, epoch, pid, process_start_time, status, updated_at FROM authority_leases WHERE pair_id = ?').get(request.pair_id) || null, enrollment: gate.enrolled, barriers: gate.barriers, barrier_audit: this.journal.listBarrierAudit(request.pair_id), startup_blocked: !gate.enrolled || gate.enrolled.history_verified !== 1, unresolved_barriers: gate.barriers.filter((b) => b.status === 'open') };
    }
    startupGate(request) {
        const credentials = this.credentials(request);
        this.assertLease(credentials);
        if (!validText(request.chatgpt_conversation_id) || !validText(request.opencode_session_id))
            throw new Error('startup gate requires exact pair bindings');
        const gate = this.journal.startupGate(credentials.pair_id);
        const open = gate.barriers.filter((b) => b.status === 'open');
        const bindingMatch = Boolean(gate.enrolled && gate.enrolled.chatgpt_conversation_id === request.chatgpt_conversation_id && gate.enrolled.opencode_session_id === request.opencode_session_id);
        return { enrolled: gate.enrolled, barriers: gate.barriers, startup_blocked: !gate.enrolled || gate.enrolled.history_verified !== 1 || !bindingMatch, unresolved_count: open.length, reason: !gate.enrolled ? 'pair enrollment is missing' : gate.enrolled.history_verified !== 1 ? 'pair historical migration is incomplete' : !bindingMatch ? 'pair enrollment binding does not match startup configuration' : null };
    }
    enrollPair(request) {
        const credentials = this.credentials(request);
        this.assertLease(credentials);
        if (request.enrollment_mode !== 'fresh' && request.enrollment_mode !== 'migrated')
            throw new Error('enrollment mode is required');
        if (request.enrollment_mode === 'fresh' && request.history_verified !== true)
            throw new Error('fresh enrollment requires independently verified history');
        if (!validText(request.enrollment_evidence, 2000) || !validText(request.chatgpt_conversation_id) || !validText(request.opencode_session_id))
            throw new Error('enrollment requires evidence and exact pair bindings');
        return this.journal.enrollPair(credentials.pair_id, request.enrollment_mode, request.history_verified === true, request.enrollment_evidence, request.chatgpt_conversation_id, request.opencode_session_id, `${credentials.host_id}:epoch-${credentials.execution_epoch}`, this.fence(credentials));
    }
    createMigrationBarrier(request) {
        const credentials = this.credentials(request);
        this.assertLease(credentials);
        if (!validText(request.barrier_id) || !validText(request.source_id) || !validText(request.direction) || !validText(request.destination) || !validText(request.evidence_type) || !validText(request.evidence) || !validText(request.decision_evidence || request.evidence))
            throw new Error('barrier identity, evidence type, and evidence are required');
        if (request.evidence_type !== 'complete_fingerprint' && request.evidence_type !== 'historical_identity_only')
            throw new Error('unsupported migration barrier evidence type');
        const complete = request.evidence_type === 'complete_fingerprint';
        if (complete && (!validText(request.payload_sha256, 64) || !Number.isInteger(request.payload_length)))
            throw new Error('complete-fingerprint barrier requires SHA-256 and byte length');
        if (!complete && (request.payload_sha256 !== undefined && request.payload_sha256 !== null || request.payload_length !== undefined && request.payload_length !== null))
            throw new Error('identity-only barrier must explicitly omit fingerprint fields');
        const barrierId = request.barrier_id;
        const sourceId = request.source_id;
        const direction = request.direction;
        const destination = request.destination;
        const hash = complete ? request.payload_sha256 : null;
        const length = complete ? request.payload_length : null;
        const reason = request.evidence;
        const evidence = request.decision_evidence || request.evidence;
        return this.journal.createBarrier({ barrierId, pairId: credentials.pair_id, sourceId, direction, destination, evidenceType: request.evidence_type, payloadSha256: hash, payloadLength: length, sourceConversationId: request.source_conversation_id, uncertaintyReason: reason, originalEvidence: evidence }, this.fence(credentials));
    }
    decideMigrationBarrier(request) {
        const credentials = this.credentials(request);
        this.assertLease(credentials);
        if (!validText(request.barrier_id) || !request.decision || !validText(request.decision_actor) || !validText(request.decision_evidence))
            throw new Error('barrier decision requires barrier, decision, actor, and evidence');
        if (request.decision === 'quarantine_and_continue' && !request.decision_actor)
            throw new Error('quarantine requires explicit operator actor');
        return this.journal.decideBarrier(request.barrier_id, credentials.pair_id, request.decision, request.decision_actor, `${credentials.host_id}:epoch-${credentials.execution_epoch}`, request.decision_evidence, this.fence(credentials));
    }
    /** The authority is the only owner of the Planner browser boundary. */
    plannerConfig(request) {
        const credentials = this.credentials(request);
        this.assertLease(credentials);
        const url = request.planner_url || this.options.plannerUrl;
        const conversationId = request.chatgpt_conversation_id || credentials.chatgpt_conversation_id;
        if (!validText(url) || !validText(conversationId))
            throw new Error('Planner transport requires an exact configured conversation URL and binding');
        const match = url.match(/\/c\/([^/?#]+)/);
        if (!match || decodeURIComponent(match[1]) !== conversationId)
            throw new Error('Planner URL does not match the enrolled conversation binding');
        const enrollment = this.journal.startupGate(credentials.pair_id).enrolled;
        if (!enrollment || enrollment.chatgpt_conversation_id !== conversationId)
            throw new Error('Planner conversation does not match the enrolled pair binding');
        const extractor = this.options.plannerExtractorPath || path.resolve(process.cwd(), 'extract_chatgpt.js');
        const sender = this.options.plannerSenderPath || path.resolve(process.cwd(), 'send_chatgpt.js');
        return { url, conversationId, extractor, sender, node: this.options.nodeBinary || process.execPath };
    }
    runPlannerScript(script, args, input) {
        const result = spawnSync(this.options.nodeBinary || process.execPath, [script, ...args], {
            input, encoding: 'utf8', timeout: 120000, maxBuffer: AUTHORITY_MAX_FRAME_BYTES * 2,
        });
        if (result.error || result.status !== 0)
            throw new Error(`Planner transport failed: ${String(result.stderr || result.error || 'child process failed').slice(-1000)}`);
        const lines = String(result.stdout || '').trim().split(/\r?\n/).filter(Boolean);
        let value;
        try {
            value = JSON.parse(lines[lines.length - 1] || '');
        }
        catch {
            throw new Error('Planner transport returned invalid JSON');
        }
        if (value?.completion_status === 'error' || value?.status === 'error' || value?.status === 'failed_before_submit')
            throw new Error(String(value.error_reason || value.error || value.reason || 'Planner transport failed'));
        return value;
    }
    plannerSnapshot(request) {
        const config = this.plannerConfig(request);
        const snapshot = this.runPlannerScript(config.extractor, [config.url, '--with-timestamps', ...(request.refresh ? ['--refresh'] : [])]);
        const observedMatch = String(snapshot.conversation_url || '').match(/\/c\/([^/?#]+)/);
        if (!observedMatch || decodeURIComponent(observedMatch[1]) !== config.conversationId)
            throw new Error('Planner extractor conversation identity mismatch');
        const timestamp = typeof snapshot.message_created_at === 'number' ? snapshot.message_created_at : (typeof snapshot.message_timestamp === 'number' ? snapshot.message_timestamp : null);
        const policy = request.source_policy;
        if (policy !== 'supervised_user_instruction' && policy !== 'autonomous_planner_assistant')
            throw new Error('Planner source policy is required');
        const users = Array.isArray(snapshot.user_turns) ? snapshot.user_turns : [];
        const turns = (Array.isArray(snapshot.all_turns) ? snapshot.all_turns : []).filter((item) => item && item.id && String(item.text || '').trim());
        const latest = turns[turns.length - 1];
        let selected = policy === 'supervised_user_instruction' ? users[users.length - 1] : (snapshot.message_identifier ? turns.find((item) => item.id === snapshot.message_identifier) : latest);
        if (policy === 'supervised_user_instruction' && (!selected || !selected.id))
            throw new Error('Planner user source identity is missing');
        const text = selected?.text ? String(selected.text).trim() : (latest?.text ? String(latest.text).trim() : null);
        const messageId = selected?.id || latest?.id || null;
        let state = 'IDLE';
        let detail = null;
        if (snapshot.evidence_state === 'WORKING' || snapshot.completion_status === 'streaming')
            state = 'WORKING';
        else if (snapshot.evidence_state === 'UNKNOWN' || snapshot.evidence_state === 'AMBIGUOUS') {
            state = 'UNKNOWN';
            detail = snapshot.error_reason || String(snapshot.evidence_state).toLowerCase();
        }
        else if (snapshot.evidence_state === 'EMPTY_VERIFIED') {
            state = 'IDLE';
            selected = null;
        }
        const observation = selected?.id && text ? {
            source_id: selected.id, source_role: policy === 'supervised_user_instruction' ? 'user' : 'assistant', source_policy: policy,
            source_conversation_id: config.conversationId, completion_status: snapshot.completion_status,
            payload_sha256: payloadFingerprint(text).sha256, payload_length: payloadFingerprint(text).length,
            observed_at: snapshot.observed_at || new Date().toISOString(), observation_boundary: { extractor: 'transport-authority' },
        } : null;
        return { state, message_id: messageId, text, timestamp, observation, ...(detail ? { detail } : {}) };
    }
    plannerObserve(request) { return this.plannerSnapshot(request); }
    plannerWatermark(request) {
        const config = this.plannerConfig(request);
        const snapshot = this.runPlannerScript(config.extractor, [config.url]);
        const observedMatch = String(snapshot.conversation_url || '').match(/\/c\/([^/?#]+)/);
        if (!observedMatch || decodeURIComponent(observedMatch[1]) !== config.conversationId)
            throw new Error('Planner watermark conversation identity mismatch');
        const users = Array.isArray(snapshot.user_turns) ? snapshot.user_turns : [];
        if (users.some((item) => !item?.id))
            throw new Error('Planner watermark contains an unidentified user message');
        return { conversation_id: config.conversationId, last_user_id: users.length ? users[users.length - 1].id : null, user_count: users.length, user_ids: users.map((item) => item.id), captured_at: new Date().toISOString(), provenance: 'transport-authority.chatgpt_dom' };
    }
    plannerSend(request) {
        const config = this.plannerConfig(request);
        if (typeof request.payload !== 'string')
            throw new Error('Planner payload is required');
        return this.runPlannerScript(config.sender, [config.url], request.payload);
    }
    plannerVerify(request) {
        const config = this.plannerConfig(request);
        if (typeof request.payload !== 'string' || !request.watermark || !validText(request.source_id))
            throw new Error('Planner verification requires payload, watermark, and source');
        const snapshot = this.runPlannerScript(config.extractor, [config.url]);
        const observedMatch = String(snapshot.conversation_url || '').match(/\/c\/([^/?#]+)/);
        if (!observedMatch || decodeURIComponent(observedMatch[1]) !== config.conversationId)
            return { verdict: 'inconclusive', evidence: { reason: 'Planner conversation identity mismatch' } };
        const users = Array.isArray(snapshot.user_turns) ? snapshot.user_turns : [];
        const boundary = request.watermark;
        if (boundary.conversation_id !== config.conversationId || !Number.isInteger(boundary.user_count))
            return { verdict: 'inconclusive', evidence: { reason: 'Planner watermark identity is invalid' } };
        const index = boundary.last_user_id === null ? -1 : users.findIndex((item) => item?.id === boundary.last_user_id);
        if (index + 1 !== boundary.user_count)
            return { verdict: 'inconclusive', evidence: { reason: 'Planner history changed across watermark' } };
        const fingerprint = payloadFingerprint(request.payload);
        const matches = users.slice(index + 1).filter((item) => payloadFingerprint(String(item?.text || '')).sha256 === fingerprint.sha256 && payloadFingerprint(String(item?.text || '')).length === fingerprint.length);
        if (matches.length !== 1)
            return { verdict: matches.length ? 'inconclusive' : 'absent', evidence: { reason: 'no unique post-watermark payload match', candidate_count: matches.length, observed_at: new Date().toISOString(), provenance: 'transport-authority.chatgpt_dom' } };
        const item = matches[0];
        return { verdict: 'confirmed', evidence: { destination_id: config.conversationId, source_id: request.source_id, destination_message_id: item.id, message_boundary: boundary.last_user_id || 'empty-conversation:0', beyond_watermark: true, payload_sha256: fingerprint.sha256, payload_length: fingerprint.length, observed_at: new Date().toISOString(), provenance: 'transport-authority.chatgpt_dom' } };
    }
    credentials(request) {
        if (!request.credentials || !validText(request.credentials.pair_id) || !validText(request.credentials.host_id) || !validText(request.credentials.owner_token) || !Number.isInteger(request.credentials.execution_epoch))
            throw new Error('owner credentials are required');
        return request.credentials;
    }
    lease(credentials) {
        return this.db.prepare('SELECT * FROM authority_leases WHERE pair_id = ? AND epoch = ? AND owner_token = ? AND host_id = ?').get(credentials.pair_id, credentials.execution_epoch, credentials.owner_token, credentials.host_id);
    }
    assertLease(credentials) {
        const row = this.lease(credentials);
        if (!row || row.status !== 'active')
            throw new Error('stale or invalid owner credentials');
        this.verifyProcess(credentials.process);
    }
    verifyProcess(identity) {
        if (!Number.isInteger(identity.pid) || identity.pid <= 0 || !validText(identity.start_time, 256))
            throw new Error('invalid process identity');
        const current = this.identity(identity.pid);
        if (!current || current.pid !== identity.pid || current.start_time !== identity.start_time)
            throw new Error('process identity is not verified');
    }
    fence(credentials) {
        return { pairId: credentials.pair_id, executionEpoch: credentials.execution_epoch, ownerHostId: credentials.host_id, validate: () => {
                const row = this.lease(credentials);
                return Boolean(row?.status === 'active' && row.epoch === credentials.execution_epoch && row.owner_token === credentials.owner_token && row.host_id === credentials.host_id);
            } };
    }
    permit(request, credentials) {
        if (!validText(request.permit_id))
            throw new Error('permit is required');
        const permit = this.db.prepare('SELECT * FROM submission_permits WHERE permit_id = ? AND pair_id = ? AND execution_epoch = ? AND owner_token = ?').get(request.permit_id, credentials.pair_id, credentials.execution_epoch, credentials.owner_token);
        if (!permit)
            throw new Error('permit is invalid or stale');
        return permit;
    }
    equalSecret(actual, expected) {
        const a = Buffer.from(actual);
        const b = Buffer.from(expected);
        return a.length === b.length && crypto.timingSafeEqual(a, b);
    }
    replayedResponse(request) {
        const row = this.db.prepare('SELECT auth_digest, response_json FROM authority_request_receipts WHERE request_id = ?').get(request.id);
        if (!row)
            return null;
        const digest = crypto.createHash('sha256').update(request.auth_token).digest('hex');
        if (row.auth_digest !== digest)
            throw new Error('request ID was already used with different credentials');
        return JSON.parse(row.response_json);
    }
    rememberResponse(request, value) {
        const digest = crypto.createHash('sha256').update(request.auth_token).digest('hex');
        this.db.prepare('INSERT INTO authority_request_receipts (request_id, auth_digest, response_json, created_at) VALUES (?, ?, ?, ?)').run(request.id, digest, JSON.stringify(value), new Date().toISOString());
    }
    write(socket, value) { socket.write(encodeFrame(value)); }
    writeError(socket, id, code, message) {
        try {
            this.write(socket, response(id, false, undefined, { code, message: message.slice(0, 500) }));
        }
        catch {
            socket.destroy();
        }
    }
}
