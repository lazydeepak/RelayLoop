#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
if (fs.existsSync(path.join(root, 'controller-release.json'))
    && process.env.BOT_RELAY_MODE !== 'durable_authority') {
  console.error('packaged authority requires explicit durable controller mode');
  process.exit(1);
}
if (process.env.BOT_RELAY_MODE === 'durable_authority') {
  // Durable authority may be started only under the same binding gate as the
  // relay. Validate in a fresh Python process before opening a socket/database.
  try {
    execFileSync(process.env.PYTHON || 'python3', [path.join(root, 'controller.py'),
      'authorize-child', 'authority'], { cwd: root, env: process.env, stdio: 'pipe' });
  } catch (error) {
    console.error(`controller authorization rejected authority startup: ${String(error.stderr || error.message).trim()}`);
    process.exit(1);
  }
}
const artifact = path.resolve(process.env.BOT_AUTHORITY_ARTIFACT || path.join(root, 'dist-authority', 'sync', 'delivery-authority.js'));
const protocolArtifact = path.join(path.dirname(artifact), 'authority-protocol.js');
if (!fs.existsSync(artifact) || !fs.existsSync(protocolArtifact)) {
  console.error(`compiled delivery authority artifact is missing: ${artifact}`);
  console.error('Build it with: npm run build:authority');
  process.exit(1);
}
const { AUTHORITY_PROTOCOL_VERSION, AUTHORITY_SCHEMA_VERSION } = await import(pathToFileURL(protocolArtifact).href);
if (AUTHORITY_PROTOCOL_VERSION !== 1 || AUTHORITY_SCHEMA_VERSION !== 6) {
  console.error(`incompatible compiled authority versions: protocol=${AUTHORITY_PROTOCOL_VERSION} schema=${AUTHORITY_SCHEMA_VERSION}; required protocol=1 schema=6`);
  process.exit(1);
}
const { DeliveryAuthority, endpointFor } = await import(pathToFileURL(artifact).href);
const dataDir = path.resolve(process.env.BOT_DATA_DIR || path.join(root, '.relay-authority'));
const dbPath = path.resolve(process.env.BOT_DELIVERY_DB || path.join(dataDir, 'delivery-authority.db'));
const endpoint = process.env.BOT_AUTHORITY_ENDPOINT || endpointFor(dataDir);
const tokenPath = path.resolve(process.env.BOT_AUTHORITY_TOKEN || path.join(dataDir, 'delivery-authority.token'));

fs.mkdirSync(path.dirname(dbPath), { recursive: true, mode: 0o700 });
fs.mkdirSync(path.dirname(tokenPath), { recursive: true, mode: 0o700 });
let token;
try { token = fs.readFileSync(tokenPath, 'utf8').trim(); } catch { token = crypto.randomBytes(32).toString('hex'); fs.writeFileSync(tokenPath, `${token}\n`, { mode: 0o600 }); }
fs.chmodSync(tokenPath, 0o600);

const authority = new DeliveryAuthority({
  dbPath, endpoint, authToken: token,
  plannerExtractorPath: process.env.BOT_PLANNER_EXTRACTOR,
  plannerSenderPath: process.env.BOT_PLANNER_SENDER,
  plannerUrl: process.env.BOT_CHATGPT_URL,
});
try {
  await authority.start();
  console.log(JSON.stringify({ protocol_version: 1, schema_version: 6, pid: process.pid, endpoint }));
} catch (error) {
  console.error(error?.stack || error);
  try { await authority.close(); } catch { /* startup failure already reported */ }
  process.exit(1);
}

let closing = false;
const close = async () => {
  if (closing) return;
  closing = true;
  await authority.close();
  console.log(JSON.stringify({ status: 'closed', pid: process.pid, endpoint }));
};
process.on('SIGINT', () => { void close().finally(() => process.exit(130)); });
process.on('SIGTERM', () => { void close().finally(() => process.exit(143)); });
process.on('uncaughtException', (error) => { console.error(error.stack || error); void close().finally(() => process.exit(1)); });
