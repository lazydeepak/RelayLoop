#!/usr/bin/env python3
"""Validate local adapter imports in an extracted terminal package."""
from __future__ import annotations

import re
import sys
from pathlib import Path


ENTRYPOINTS = (
    "extract_chatgpt.js",
    "send_chatgpt.js",
    "create_chatgpt_conversation.js",
)
IMPORT_RE = re.compile(r"\b(?:import|export)\b[^\n]*?\bfrom\s*[\"']([^\"']+)[\"']|\bimport\s*[\"']([^\"']+)[\"']")


def local_js_closure(package: Path) -> set[str]:
    pending = list(ENTRYPOINTS)
    seen: set[str] = set()
    while pending:
        relative = pending.pop()
        if relative in seen:
            continue
        seen.add(relative)
        path = package / relative
        if not path.is_file():
            raise FileNotFoundError(f"missing packaged adapter entrypoint: {relative}")
        for match in IMPORT_RE.finditer(path.read_text(encoding="utf-8")):
            imported = match.group(1) or match.group(2)
            if not imported.startswith("."):
                continue
            candidate = (path.parent / imported).resolve()
            try:
                relative_candidate = candidate.relative_to(package.resolve()).as_posix()
            except ValueError as exc:
                raise ValueError(f"local adapter import escapes package: {relative} -> {imported}") from exc
            if not candidate.is_file():
                raise FileNotFoundError(f"missing packaged local adapter dependency: {relative} -> {relative_candidate}")
            pending.append(relative_candidate)
    return seen


def main() -> int:
    if len(sys.argv) != 2:
        print("usage: check_cli_package.py EXTRACTED_PACKAGE", file=sys.stderr)
        return 2
    package = Path(sys.argv[1]).resolve()
    try:
        closure = local_js_closure(package)
    except (OSError, ValueError) as exc:
        print(f"CLI package closure failed: {exc}", file=sys.stderr)
        return 1
    print(f"CLI package closure passed: {', '.join(sorted(closure))}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
