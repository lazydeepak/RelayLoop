"""Explicitly selected minimal Core Relay profile.

This profile intentionally has no authority, deduplication, watermark,
durable-evidence, recovery, or diagnostic behavior.  It reads each side's
latest message and forwards it, so historical messages may be replayed on
every poll.  Use only with disposable/fake transports or an operator-approved
controlled pair; the safeguarded relay remains the default.
"""

import threading
import time


class CoreRelay:
    """Planner -> Worker -> Planner forwarding loop with no safety state."""

    def __init__(self, planner_latest, worker_latest, send_to_worker,
                 send_to_planner, sleep=time.sleep):
        self.planner_latest = planner_latest
        self.worker_latest = worker_latest
        self.send_to_worker = send_to_worker
        self.send_to_planner = send_to_planner
        self.sleep = sleep

    @staticmethod
    def _message(latest):
        value = latest()
        if isinstance(value, tuple):
            return value[-1]
        if isinstance(value, dict):
            return value.get("text") or value.get("message") or ""
        return value or ""

    def run(self, stop_event=None, max_turns=None):
        stop_event = stop_event or threading.Event()
        turn = "planner"
        turns = 0
        while not stop_event.is_set() and (max_turns is None or turns < max_turns):
            if turn == "planner":
                message = self._message(self.planner_latest)
                if not message:
                    self.sleep(0)
                    continue
                self.send_to_worker(message)
                turn = "worker"
            else:
                message = self._message(self.worker_latest)
                if not message:
                    self.sleep(0)
                    continue
                self.send_to_planner(message)
                turn = "planner"
            turns += 1
        return turns


def run_core_relay(planner_latest, worker_latest, send_to_worker,
                   send_to_planner, stop_event=None, max_turns=None,
                   sleep=time.sleep):
    return CoreRelay(planner_latest, worker_latest, send_to_worker,
                     send_to_planner, sleep=sleep).run(
                         stop_event=stop_event, max_turns=max_turns)
