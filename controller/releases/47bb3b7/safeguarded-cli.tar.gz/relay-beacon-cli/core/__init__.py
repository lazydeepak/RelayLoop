"""Minimal transport-injected relay core.

This package deliberately does not contain the safeguarded relay's durable
authority or recovery machinery; that authority remains in the existing
managed relay runtime.
"""
