# Relay Beacon terminal CLI release

## Supported environment

The terminal package is verified on macOS with Python 3.9+ and Node.js 20+.
It requires OpenCode and Playwright 1.64.0. Live ChatGPT transport additionally
requires a browser exposing CDP on `127.0.0.1:9222`. Linux and Windows are not
claimed by this release procedure.

## Build

The shared command-by-command host, desktop, and CLI runbook is
[`BUILD_PACKAGE_RUNBOOK.md`](BUILD_PACKAGE_RUNBOOK.md). The CLI-specific steps
are repeated here for convenience.

From a clean checkout, run:

```sh
npm run build:authority
python3 scripts/build_cli_release.py --output release/relay-beacon-cli.tar.gz
```

The builder uses the declared release inputs, including the generated compiled
authority, normalizes archive metadata, and writes a sibling SHA-256 file. It excludes the desktop shell, credentials,
session identifiers, host identity, runtime registries, audit logs, and logs.

## Install and configure

Extract the archive into a dedicated directory and install the exact runtime
dependencies declared by its manifest. Keep this directory separate from the
development checkout and project target:

```sh
tar -xzf relay-beacon-cli.tar.gz
cd relay-beacon-cli
npm install --omit=dev --ignore-scripts
```

The supported operator entry point is `controller.py`. Do not start the authority
or relay directly. Create `config/binding.json` with mode `live`, the explicit
`pair_id`, `project_id`, canonical `project_path`, Planner URL and conversation
ID, Worker session ID, `source_policy`, `opencode_bin`, and `source_path`. Set
`source_sha` to the package's `controller-release.json` value. Add
`identity_verification` matching the exact Planner, Worker, project ID and path,
plus independently collected `verified_by` and `evidence`. Protect the binding
with mode 0600. The source checkout must be clean at the pinned revision and
must not overlap the runtime or project.

For synthetic rehearsals use `mode: "synthetic"`, `synthetic_only: true`, and
three fake adapters under `config/` (planner extractor, planner sender, Worker).
The adapter paths must be explicitly listed in `synthetic_adapters`; synthetic
mode rejects live provider endpoints and is never eligible for live mode.
Both modes require an `identity_verification` object matching the explicit
Planner, Worker and project values. Synthetic mode additionally requires that
its evidence is explicitly labelled synthetic.

Supported lifecycle commands:

```sh
python3 controller.py start --mode live
python3 controller.py status
python3 controller.py stop --timeout 30
```

`start` refuses duplicate/stale ownership, verifies both children and journal
readiness, and revalidates authorization inside both child entry points. `status`
is read-only. `stop` signals the relay first so it finishes the executing tick,
then shuts down the authority; drain timeout preserves ownership and is never
followed by SIGKILL. Do not use a production pair registry or `.relay_state*`
file. Ambiguous journal records remain held for evidence-based reconciliation;
restart does not imply permission to resend.

Every direct effectful relay command and a packaged authority launch without a
valid controller authorization context fail closed. A live loop is a separate,
explicit authorization decision; this CLI does not grant unrestricted
automation.
