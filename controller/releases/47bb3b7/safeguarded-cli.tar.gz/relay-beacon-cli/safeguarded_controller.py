"""Fail-closed configuration gate for an isolated safeguarded relay runtime.

This module deliberately does not select a pair or infer project/session
identity. Callers must supply a mode-0600 JSON binding and a pinned source
checkout; live operation additionally requires explicit operator verification.
"""

import json
import hashlib
import os
import re
import subprocess
from pathlib import Path
from urllib.parse import unquote, urlparse


class ControllerConfigError(ValueError):
    pass


# Digests keep historical workstation bindings out of the sanitized package.
_HISTORICAL_BINDING_DIGESTS = {
    "pair_id": {"a3103d45fd9aa530b27bad7af82d72833542f7cb286a4614b99f5a4513c4e7f3"},
    "planner_conversation_id": {"42ec71b91e7417ad2dc1b411c3df24f6e6bd0f29fb018be5fe70752ab49f91ae"},
    "worker_session_id": {"31f307f229303e3be63e0518224c86f3e4177fef674e4b3903fbccf5340f85ce"},
}


def _digest(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def load_binding(path, *, runtime_dir, expected_source_sha, live=False):
    path = Path(path).resolve(strict=True)
    mode = path.stat().st_mode & 0o777
    if mode & 0o077:
        raise ControllerConfigError("binding file must not be group/world accessible")
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ControllerConfigError("binding file is unreadable or invalid JSON") from exc

    required = ("pair_id", "project_id", "project_path", "source_sha",
                "planner_conversation_url", "planner_conversation_id",
                "worker_session_id")
    missing = [key for key in required if not isinstance(data.get(key), str) or not data[key].strip()]
    if missing:
        raise ControllerConfigError("explicit binding fields required: " + ", ".join(missing))
    if not re.fullmatch(r"[A-Za-z0-9._-]{1,128}", data["pair_id"]):
        raise ControllerConfigError("pair_id has invalid characters")
    for key, digests in _HISTORICAL_BINDING_DIGESTS.items():
        if _digest(data[key]) in digests:
            raise ControllerConfigError("historical default binding is forbidden: " + key)
    if data["source_sha"] != expected_source_sha:
        raise ControllerConfigError("binding source SHA does not match pinned runtime")
    parsed_planner = urlparse(data["planner_conversation_url"])
    planner_path_id = unquote(parsed_planner.path.rstrip("/").split("/")[-1])
    if parsed_planner.scheme != "https" or not parsed_planner.netloc or planner_path_id != data["planner_conversation_id"]:
        raise ControllerConfigError("Planner URL and explicit conversation identity do not match")
    project = Path(data["project_path"]).resolve(strict=True)
    runtime = Path(runtime_dir).resolve(strict=True)
    if project == runtime or project in runtime.parents or runtime in project.parents:
        raise ControllerConfigError("project target and controller runtime must be separate")
    if live:
        if data.get("synthetic_only") is True:
            raise ControllerConfigError("synthetic-only binding cannot enter live mode")
        verification = data.get("identity_verification")
        expected = {
            "planner_conversation_id": data["planner_conversation_id"],
            "worker_session_id": data["worker_session_id"],
            "project_id": data["project_id"], "project_path": str(project),
        }
        if (not isinstance(verification, dict)
                or any(verification.get(key) != value for key, value in expected.items())
                or not isinstance(verification.get("verified_by"), str)
                or not verification["verified_by"].strip()
                or not isinstance(verification.get("evidence"), str)
                or not verification["evidence"].strip()):
            raise ControllerConfigError("live binding requires exact Planner, Worker, and project verification evidence")
        evidence_text = (verification["verified_by"] + " " + verification["evidence"]).lower()
        if any(marker in evidence_text for marker in ("synthetic", "fake", "fixture", "test-only", "placeholder")):
            raise ControllerConfigError("synthetic verification evidence cannot enter live mode")
    elif data.get("mode") == "synthetic":
        verification = data.get("identity_verification")
        expected = {
            "planner_conversation_id": data["planner_conversation_id"],
            "worker_session_id": data["worker_session_id"],
            "project_id": data["project_id"], "project_path": str(project),
        }
        if (not isinstance(verification, dict)
                or any(verification.get(key) != value for key, value in expected.items())
                or not isinstance(verification.get("verified_by"), str)
                or not verification["verified_by"].strip()
                or not isinstance(verification.get("evidence"), str)
                or "synthetic" not in verification["evidence"].lower()):
            raise ControllerConfigError("synthetic binding requires matching synthetic identity-verification evidence")
    return {**data, "project_path": str(project), "binding_path": str(path)}


def require_clean_pinned_source(source_path, expected_sha):
    source = Path(source_path).resolve(strict=True)
    try:
        head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=source, text=True).strip()
        changes = subprocess.check_output(["git", "status", "--porcelain"], cwd=source, text=True)
    except (OSError, subprocess.CalledProcessError) as exc:
        raise ControllerConfigError("pinned source checkout cannot be verified") from exc
    if head != expected_sha or changes.strip():
        raise ControllerConfigError("source checkout is not the clean pinned revision")
    return source


def isolated_environment(binding, runtime_dir):
    """Return explicit durable-mode variables; no legacy/default fallback."""
    runtime = Path(runtime_dir).resolve(strict=True)
    required_dirs = ("config", "state", "logs", "tmp", "home")
    paths = {name: runtime / name for name in required_dirs}
    if any(not path.is_dir() for path in paths.values()):
        raise ControllerConfigError("isolated runtime directories are incomplete")
    env = {
        "BOT_RELAY_MODE": "durable_authority",
        "BOT_PAIR_ID": binding["pair_id"],
        "BOT_CHATGPT_URL": binding["planner_conversation_url"],
        "BOT_SESSION_ID": binding["worker_session_id"],
        "BOT_PAIRS_FILE": str(paths["config"] / "pairs.json"),
        "BOT_DATA_DIR": str(paths["state"]),
        "BOT_RUN_DIR": str(paths["state"] / "runs"),
        "BOT_WORKER_CONTINUATION_FILE": str(paths["state"] / "worker-continuation.json"),
        "BOT_RECOVERY_STATE_FILE": str(paths["state"] / "recovery-state.json"),
        "BOT_RECOVERY_DECISION_FILE": str(paths["state"] / "recovery-decision.json"),
        "BOT_DELIVERY_EVIDENCE_FILE": str(paths["state"] / "delivery-evidence.json"),
        "HOME": str(paths["home"]),
        "TMPDIR": str(paths["tmp"]),
    }
    if not env["BOT_CHATGPT_URL"] or not env["BOT_SESSION_ID"]:
        raise ControllerConfigError("Planner and Worker identities are mandatory")
    return env


def authorize_child(role, operation=None):
    """Revalidate authorization inside each executable process boundary."""
    if role not in ("relay", "authority"):
        raise ControllerConfigError("unknown controller child role")
    runtime = Path(os.environ.get("BOT_CONTROLLER_RUNTIME", "")).resolve(strict=True)
    binding_path = os.environ.get("BOT_CONTROLLER_BINDING")
    expected_sha = os.environ.get("BOT_CONTROLLER_SOURCE_SHA")
    mode = os.environ.get("BOT_CONTROLLER_MODE")
    if mode not in ("live", "synthetic") or not binding_path or not expected_sha:
        raise ControllerConfigError("controller authorization context is required")
    if os.environ.get("BOT_RELAY_MODE") != "durable_authority":
        raise ControllerConfigError("controller children must use durable authority mode")
    binding = load_binding(binding_path, runtime_dir=runtime,
                           expected_source_sha=expected_sha, live=(mode == "live"))
    if binding.get("mode") != mode:
        raise ControllerConfigError("authorized operating mode does not match binding")
    if binding.get("pair_id") != os.environ.get("BOT_PAIR_ID"):
        raise ControllerConfigError("authorized pair does not match child environment")
    if (binding.get("planner_conversation_url") != os.environ.get("BOT_CHATGPT_URL")
            or binding.get("worker_session_id") != os.environ.get("BOT_SESSION_ID")):
        raise ControllerConfigError("authorized Planner/Worker identity does not match child environment")
    if (binding.get("source_policy") not in ("supervised_user_instruction", "autonomous_planner_assistant")
            or binding.get("source_policy") != os.environ.get("BOT_SOURCE_POLICY")):
        raise ControllerConfigError("explicit Planner source policy does not match child environment")
    if mode == "live":
        source_path = binding.get("source_path")
        if not isinstance(source_path, str) or not source_path:
            raise ControllerConfigError("live binding requires a pinned source checkout path")
        require_clean_pinned_source(source_path, expected_sha)
    else:
        if role == "relay" and operation != "loop":
            raise ControllerConfigError("synthetic mode authorizes only the durable packaged loop")
        if binding.get("synthetic_only") is not True:
            raise ControllerConfigError("synthetic mode requires an explicitly synthetic-only binding")
        adapters = binding.get("synthetic_adapters")
        if not isinstance(adapters, dict) or set(adapters) != {"planner_extractor", "planner_sender", "worker"}:
            raise ControllerConfigError("synthetic mode requires three explicit fake adapters")
        expected_env = {
            "BOT_PLANNER_EXTRACTOR": "planner_extractor",
            "BOT_PLANNER_SENDER": "planner_sender",
            "BOT_OPENCODE_BIN": "worker",
        }
        for env_name, key in expected_env.items():
            adapter = Path(adapters[key]).resolve(strict=True)
            try:
                adapter.relative_to(runtime / "config")
            except ValueError as exc:
                raise ControllerConfigError("synthetic adapters must remain under isolated runtime config") from exc
            if str(adapter) != str(Path(os.environ.get(env_name, "")).resolve()):
                raise ControllerConfigError("synthetic adapter identity mismatch: " + key)
            if not ("fake" in adapter.name.lower() or "synthetic" in adapter.name.lower()
                    or "fake" in adapter.parent.name.lower() or "synthetic" in adapter.parent.name.lower()):
                raise ControllerConfigError("synthetic adapter path must be visibly fake/synthetic")
            text = adapter.read_text(encoding="utf-8", errors="replace").lower()
            if not any(marker in text for marker in ("synthetic", "fake")):
                raise ControllerConfigError("synthetic adapter lacks a synthetic identity marker")
            if any(marker in text for marker in ("chatgpt.com", "api.openai.com", "opencode.ai")):
                raise ControllerConfigError("synthetic adapter contains a live provider endpoint")
            if re.search(r"\b(fetch|websocket|child_process|spawn|exec)\s*\(|node:https?|node:http|\b(curl|wget)\b", text):
                raise ControllerConfigError("synthetic adapter contains a network/process execution capability")
        if role == "authority" and (not os.environ.get("BOT_PLANNER_EXTRACTOR") or not os.environ.get("BOT_PLANNER_SENDER")):
            raise ControllerConfigError("synthetic authority requires fake Planner transports")
    return binding
