#!/usr/bin/env python3
"""Single-process-owner CLI for the isolated terminal relay package."""
import argparse
import fcntl
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import uuid

from authority_client import DeliveryAuthorityClient
from safeguarded_controller import (
    ControllerConfigError, authorize_child, isolated_environment, load_binding,
    require_clean_pinned_source,
)


class LifecycleError(RuntimeError):
    pass


def _runtime(path, create=True):
    root = Path(path).resolve(strict=True)
    for name in ("config", "state", "logs", "tmp", "home"):
        if create:
            (root / name).mkdir(parents=True, exist_ok=True, mode=0o700)
        elif not (root / name).is_dir():
            raise LifecycleError("controller runtime is incomplete: " + name)
    return root


def _read_release(runtime):
    try:
        release = json.loads((runtime / "controller-release.json").read_text())
        sha = release["source_sha"]
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise LifecycleError("package source identity metadata is missing or invalid") from exc
    if not isinstance(sha, str) or len(sha) != 40:
        raise LifecycleError("package source identity is malformed")
    return sha


def _binding(runtime, binding_path, mode):
    if mode not in ("live", "synthetic"):
        raise LifecycleError("--mode must explicitly be live or synthetic")
    sha = _read_release(runtime)
    binding = load_binding(binding_path, runtime_dir=runtime,
                           expected_source_sha=sha, live=(mode == "live"))
    if binding.get("mode") != mode:
        raise LifecycleError("binding mode must exactly match requested mode")
    if binding.get("source_policy") not in ("supervised_user_instruction", "autonomous_planner_assistant"):
        raise LifecycleError("binding requires an explicit supported Planner source_policy")
    if mode == "synthetic" and binding.get("synthetic_only") is not True:
        raise LifecycleError("synthetic mode requires synthetic_only=true")
    if mode == "live":
        require_clean_pinned_source(binding.get("source_path", ""), sha)
    return binding, sha


def _manifest(runtime):
    return runtime / "state" / "controller-owner.json"


def _lock(runtime):
    path = runtime / "state" / "controller.lock"
    fd = os.open(path, os.O_CREAT | os.O_RDWR, 0o600)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError as exc:
        os.close(fd)
        raise LifecycleError("another controller lifecycle command owns the lock") from exc
    return fd


def _process_identity(pid):
    try:
        result = subprocess.run(["ps", "-p", str(pid), "-o", "lstart=", "-o", "command="],
                                capture_output=True, text=True, timeout=3)
    except (OSError, subprocess.TimeoutExpired):
        return None
    value = result.stdout.strip()
    if result.returncode or not value:
        return None
    fields = value.split(None, 5)
    if len(fields) < 6:
        return None
    return {"started": " ".join(fields[:5]), "command": fields[5]}


def _owned(entry):
    current = _process_identity(entry.get("pid"))
    return bool(current and current["started"] == entry.get("started")
                and entry.get("owner_nonce") in current["command"]
                and str(entry.get("runtime")) in current["command"])


def _save_manifest(path, data):
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(data, indent=2) + "\n")
    temp.chmod(0o600)
    os.replace(temp, path)


def _pair_registry(runtime, binding):
    fake = binding.get("synthetic_adapters") or {}
    opencode = fake.get("worker") if binding["mode"] == "synthetic" else binding.get("opencode_bin")
    if not opencode:
        raise LifecycleError("binding must select an explicit OpenCode executable")
    registry = {
        "default_pair_id": binding["pair_id"],
        "pairs": [{
            "id": binding["pair_id"], "name": "Safeguarded controller binding",
            "chatgpt_url": binding["planner_conversation_url"],
            "session_id": binding["worker_session_id"], "opencode_bin": opencode,
            "source_policy": binding["source_policy"],
            "status": "stopped", "pid": None,
        }],
    }
    path = runtime / "config" / "pairs.json"
    _save_manifest(path, registry)
    return path


def _environment(runtime, binding, source_sha, owner_nonce):
    env = isolated_environment(binding, runtime)
    fake = binding.get("synthetic_adapters") or {}
    mode = binding["mode"]
    env.update({
        "BOT_CONTROLLER_RUNTIME": str(runtime),
        "BOT_CONTROLLER_BINDING": str(binding["binding_path"]),
        "BOT_CONTROLLER_SOURCE_SHA": source_sha,
        "BOT_CONTROLLER_MODE": mode,
        "BOT_CONTROLLER_OWNER_NONCE": owner_nonce,
        "BOT_SOURCE_POLICY": binding["source_policy"],
        "BOT_OPENCODE_BIN": fake.get("worker") if mode == "synthetic" else binding["opencode_bin"],
        "BOT_HOST_ID": binding.get("host_id") or ("synthetic-controller-host" if mode == "synthetic" else ""),
        "PATH": os.environ.get("PATH", os.defpath),
    })
    if mode == "synthetic":
        env.update({
            "BOT_PLANNER_EXTRACTOR": fake["planner_extractor"],
            "BOT_PLANNER_SENDER": fake["planner_sender"],
        })
        for key, value in (binding.get("synthetic_environment") or {}).items():
            if not key.startswith("FAKE_"):
                raise LifecycleError("synthetic environment overrides must use FAKE_ names")
            env[key] = str(value)
    env["BOT_PAIRS_FILE"] = str(_pair_registry(runtime, binding))
    env["BOT_AUTHORITY_ENDPOINT"] = str(Path("/private/tmp") / ("tbc-" + owner_nonce[:20] + ".sock"))
    env["BOT_AUTHORITY_TOKEN_FILE"] = str(runtime / "state" / "authority" / "delivery-authority.token")
    env["BOT_AUTHORITY_TOKEN"] = env["BOT_AUTHORITY_TOKEN_FILE"]
    env["BOT_DATA_DIR"] = str(runtime / "state" / "authority")
    env["BOT_RUN_DIR"] = str(runtime / "state" / "runs")
    env["BOT_RELAY_DEBUG"] = "1"
    env["BOT_STORAGE"] = "files"
    return env


def _wait_ready(proc, log_path, marker, timeout):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if proc.poll() is not None:
            raise LifecycleError("child exited before readiness: " + str(log_path))
        try:
            text = log_path.read_text(errors="replace")
        except OSError:
            text = ""
        if marker(text):
            return
        time.sleep(.05)
    raise LifecycleError("timed out waiting for child readiness: " + str(log_path))


def _journal_diagnostics(env, pair_id):
    token = Path(env["BOT_AUTHORITY_TOKEN_FILE"]).read_text().strip()
    client = DeliveryAuthorityClient(env["BOT_AUTHORITY_ENDPOINT"], token)
    try:
        return client.call("diagnostics", {"pair_id": pair_id})
    finally:
        client.close()


def _seed_synthetic_journal(runtime, env, binding):
    seed = binding.get("synthetic_enrollment")
    if not isinstance(seed, dict) or seed.get("enrollment_mode") != "fresh":
        raise LifecycleError("synthetic first start requires explicit fresh synthetic_enrollment evidence")
    evidence = seed.get("evidence")
    watermarks = seed.get("watermarks")
    if (not isinstance(evidence, str) or "synthetic" not in evidence.lower()
            or not isinstance(watermarks, dict)
            or not isinstance(watermarks.get("planner"), str)
            or not isinstance(watermarks.get("worker"), str)):
        raise LifecycleError("synthetic enrollment evidence and both explicit watermarks are required")
    script = r'''import json, os
from durable_relay import DurableRelayAuthority
a = DurableRelayAuthority.from_environment(os.environ["BOT_PAIR_ID"], os.environ["BOT_CHATGPT_URL"], os.environ["BOT_SESSION_ID"])
a.acquire()
try:
    a.enroll_pair("fresh", True, os.environ["BOT_SYNTHETIC_ENROLLMENT_EVIDENCE"])
    a.initialize_turn_state("planner", json.loads(os.environ["BOT_SYNTHETIC_WATERMARKS"]))
finally:
    a.close()
'''
    setup_env = env.copy()
    setup_env.pop("BOT_AUTHORITY_TOKEN", None)
    setup_env["BOT_SYNTHETIC_ENROLLMENT_EVIDENCE"] = evidence
    setup_env["BOT_SYNTHETIC_WATERMARKS"] = json.dumps({
        "chatgpt": watermarks["planner"], "opencode": watermarks["worker"]})
    result = subprocess.run([sys.executable, "-c", script], cwd=runtime,
                            env=setup_env, capture_output=True, text=True, timeout=15)
    if result.returncode:
        raise LifecycleError("synthetic journal enrollment failed: " + (result.stderr or result.stdout)[-1500:])


def start(runtime, binding_path, mode, readiness_timeout=15):
    runtime = _runtime(runtime)
    lock = _lock(runtime)
    children = []
    try:
        binding, sha = _binding(runtime, binding_path, mode)
        owner_path = _manifest(runtime)
        if owner_path.exists():
            old = json.loads(owner_path.read_text())
            if any(_owned(old.get(role, {})) for role in ("authority", "relay")):
                raise LifecycleError("controller already has an owned child; duplicate start refused")
            raise LifecycleError("stale/partial ownership record exists; inspect with status and recover manually")
        nonce = uuid.uuid4().hex
        env = _environment(runtime, binding, sha, nonce)
        authority_log = runtime / "logs" / ("authority-" + nonce + ".log")
        relay_log = runtime / "logs" / ("relay-" + nonce + ".log")
        for path in (authority_log, relay_log):
            path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        auth_handle = authority_log.open("a")
        authority = subprocess.Popen(
            ["node", "scripts/run-delivery-authority.mjs", "--controller-owner=" + nonce,
             "--controller-runtime=" + str(runtime)],
            cwd=runtime, env=env, stdin=subprocess.DEVNULL, stdout=auth_handle,
            stderr=subprocess.STDOUT, start_new_session=True,
        )
        children.append((authority, auth_handle))
        auth_handle.close()
        _wait_ready(authority, authority_log,
                    lambda text: any(_valid_ready_line(line, authority.pid, env["BOT_AUTHORITY_ENDPOINT"])
                                     for line in text.splitlines()), readiness_timeout)
        journal_before = _journal_diagnostics(env, binding["pair_id"])
        if not journal_before.get("enrollment") and mode == "synthetic":
            _seed_synthetic_journal(runtime, env, binding)
            journal_before = _journal_diagnostics(env, binding["pair_id"])
        if journal_before.get("startup_blocked") or not journal_before.get("enrollment"):
            raise LifecycleError("authority journal is not enrolled/ready for this exact pair")
        relay_handle = relay_log.open("a")
        relay_env = env.copy()
        relay_env.pop("BOT_AUTHORITY_TOKEN", None)  # Node's token-path setting is not a Python token.
        relay = subprocess.Popen(
            [sys.executable, "-u", "relay_chatgpt_opencode.py", "loop",
             "--controller-owner=" + nonce, "--controller-runtime=" + str(runtime)],
            cwd=runtime, env=relay_env, stdin=subprocess.DEVNULL, stdout=relay_handle,
            stderr=subprocess.STDOUT, start_new_session=True,
        )
        children.append((relay, relay_handle))
        relay_handle.close()
        _wait_ready(relay, relay_log,
                    lambda text: "Relay running (Ctrl+C to stop)." in text,
                    readiness_timeout)
        journal = _journal_diagnostics(env, binding["pair_id"])
        if journal.get("startup_blocked") or not journal.get("enrollment"):
            raise LifecycleError("authority journal is not execution-ready for this exact pair")
        data = {
            "owner_nonce": nonce, "runtime": str(runtime), "mode": mode,
            "binding": {key: binding[key] for key in ("pair_id", "project_id", "planner_conversation_id", "worker_session_id")},
            "source_sha": sha, "started_at": time.time(),
            "authority": _record(authority.pid, nonce, runtime),
            "relay": _record(relay.pid, nonce, runtime),
            "authority_endpoint": env["BOT_AUTHORITY_ENDPOINT"],
            "token_file": env["BOT_AUTHORITY_TOKEN_FILE"],
            "authority_log": str(authority_log), "relay_log": str(relay_log),
        }
        _save_manifest(owner_path, data)
        print(json.dumps({"status": "running", "authority_pid": authority.pid,
                          "relay_pid": relay.pid, "pair_id": binding["pair_id"],
                          "source_sha": sha, "owner_nonce": nonce}))
        return 0
    except Exception as exc:
        # Startup rollback signals only children spawned by this invocation.
        for proc, handle in reversed(children):
            if proc.poll() is None:
                proc.send_signal(signal.SIGTERM)
                try:
                    proc.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    pass  # preserve process; never force-kill a possibly active provider call
            handle.close()
        survivors = {"owner_nonce": nonce if "nonce" in locals() else "startup-failed",
                     "runtime": str(runtime), "mode": mode,
                     "binding": ({key: binding[key] for key in ("pair_id", "project_id", "planner_conversation_id", "worker_session_id")}
                                 if "binding" in locals() else {}),
                     "source_sha": sha if "sha" in locals() else None,
                     "startup_error": str(exc)}
        for role, (proc, _handle) in zip(("authority", "relay"), children):
            if proc.poll() is None:
                survivors[role] = _record(proc.pid, survivors["owner_nonce"], runtime)
        if any(role in survivors for role in ("authority", "relay")):
            survivors["authority_endpoint"] = env.get("BOT_AUTHORITY_ENDPOINT") if "env" in locals() else None
            survivors["token_file"] = env.get("BOT_AUTHORITY_TOKEN_FILE") if "env" in locals() else None
            survivors["authority_log"] = str(authority_log) if "authority_log" in locals() else None
            survivors["relay_log"] = str(relay_log) if "relay_log" in locals() else None
            _save_manifest(_manifest(runtime), survivors)
        raise
    finally:
        os.close(lock)


def _valid_ready_line(line, pid, endpoint):
    try:
        data = json.loads(line)
    except (TypeError, ValueError):
        return False
    return data.get("pid") == pid and data.get("endpoint") == endpoint and data.get("protocol_version") == 1


def _record(pid, nonce, runtime):
    identity = _process_identity(pid)
    if not identity:
        raise LifecycleError("child process disappeared during readiness")
    return {"pid": pid, "started": identity["started"], "command": identity["command"],
            "owner_nonce": nonce, "runtime": str(runtime)}


def _load_owner(runtime):
    path = _manifest(runtime)
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text())
        if data.get("runtime") != str(runtime):
            raise LifecycleError("ownership record belongs to another runtime")
        return data
    except (OSError, ValueError) as exc:
        raise LifecycleError("ownership record is unreadable; refusing process signals") from exc


def status(runtime):
    runtime = _runtime(runtime, create=False)
    owner = _load_owner(runtime)
    if owner is None:
        print(json.dumps({"status": "stopped", "owned_processes": [], "journal": None}))
        return 0
    processes = {role: {"pid": owner.get(role, {}).get("pid"),
                        "owned_and_alive": _owned(owner.get(role, {}))}
                 for role in ("authority", "relay")}
    journal = None
    if processes["authority"]["owned_and_alive"]:
        try:
            token = Path(owner["token_file"]).read_text().strip()
            client = DeliveryAuthorityClient(owner["authority_endpoint"], token)
            try:
                journal = client.call("diagnostics", {"pair_id": owner["binding"]["pair_id"]})
            finally:
                client.close()
        except Exception as exc:
            journal = {"health": "unavailable", "reason": str(exc)}
    alive = [item["owned_and_alive"] for item in processes.values()]
    recorded_alive = [bool(_process_identity(owner.get(role, {}).get("pid")))
                      for role in ("authority", "relay")]
    label = "running" if all(alive) else (
        "stale_ownership" if not any(recorded_alive) else "partial_or_stale")
    print(json.dumps({"status": label, "mode": owner.get("mode"), "binding": owner.get("binding"),
                      "source_sha": owner.get("source_sha"), "processes": processes,
                      "logs": {"authority": owner.get("authority_log"), "relay": owner.get("relay_log")},
                      "journal": journal}, sort_keys=True))
    return 0 if label == "running" else 1 if label in ("partial_or_stale", "stale_ownership") else 0


def stop(runtime, timeout=30):
    runtime = _runtime(runtime)
    lock = _lock(runtime)
    try:
        owner = _load_owner(runtime)
        if owner is None:
            print(json.dumps({"status": "stopped", "stopped": []}))
            return 0
        relay = owner.get("relay", {})
        authority = owner.get("authority", {})
        if not _owned(relay) and _process_identity(relay.get("pid")):
            raise LifecycleError("relay PID is live but ownership cannot be proven; refusing to signal")
        if _owned(relay):
            os.kill(relay["pid"], signal.SIGTERM)
            if not _wait_exit(relay, timeout):
                print(json.dumps({"status": "draining", "relay_pid": relay["pid"],
                                  "authority_retained": True, "forced_kill": False}))
                return 2
        if not _owned(authority) and _process_identity(authority.get("pid")):
            raise LifecycleError("authority PID is live but ownership cannot be proven; refusing to signal")
        if _owned(authority):
            os.kill(authority["pid"], signal.SIGTERM)
            if not _wait_exit(authority, timeout):
                print(json.dumps({"status": "authority_shutdown_deferred", "authority_pid": authority["pid"],
                                  "forced_kill": False}))
                return 2
        relay_clean = "Graceful stop: relay admission quiesced after current tick." in Path(owner["relay_log"]).read_text(errors="replace")
        authority_clean = '"status":"closed"' in Path(owner["authority_log"]).read_text(errors="replace").replace(" ", "")
        if not (relay_clean and authority_clean):
            print(json.dumps({"status": "stopped_without_clean_evidence", "relay_clean": relay_clean,
                              "authority_clean": authority_clean, "forced_kill": False}))
            return 2
        _manifest(runtime).unlink(missing_ok=True)
        print(json.dumps({"status": "stopped", "stopped": ["relay", "authority"],
                          "relay_exit": 0, "authority_exit": 143,
                          "forced_kill": False}))
        return 0
    finally:
        os.close(lock)


def _wait_exit(entry, timeout):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if not _owned(entry):
            return True
        time.sleep(.1)
    return not _owned(entry)


def _exit_code(entry):
    # Exit status is included in each child log; ps does not retain a reaped code.
    return "exited (see owned process log)" if not _owned(entry) else "still-running"


def main(argv=None):
    parser = argparse.ArgumentParser(prog="terminal-controller")
    parser.add_argument("operation", choices=("start", "status", "stop", "authorize-child"))
    parser.add_argument("role", nargs="?", choices=("relay", "authority"))
    parser.add_argument("--runtime", default=str(Path(__file__).resolve().parent))
    parser.add_argument("--binding", default=None)
    parser.add_argument("--mode", choices=("live", "synthetic"))
    parser.add_argument("--timeout", type=int, default=30)
    args = parser.parse_args(argv)
    try:
        runtime = _runtime(args.runtime, create=args.operation != "status")
        if args.operation == "authorize-child":
            authorize_child(args.role)
            return 0
        if args.operation == "start":
            binding = args.binding or str(runtime / "config" / "binding.json")
            if not args.mode:
                raise LifecycleError("start requires explicit --mode")
            return start(runtime, binding, args.mode, args.timeout)
        if args.operation == "status":
            return status(runtime)
        return stop(runtime, args.timeout)
    except (ControllerConfigError, LifecycleError, OSError, ValueError) as exc:
        print(json.dumps({"status": "blocked", "error": str(exc)}), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
