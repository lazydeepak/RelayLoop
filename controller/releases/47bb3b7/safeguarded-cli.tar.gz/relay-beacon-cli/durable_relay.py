"""Opt-in durable-authority adapter for the Python relay.

The legacy relay does not import this module unless an authority object is
explicitly supplied to ``tick``/``run_loop``. Planner observation and browser
submission are performed by the Transport Authority; OpenCode remains native.
"""
import hashlib
import json
import os
import re
import socket
import datetime
from urllib.parse import unquote

from authority_client import DeliveryAuthorityClient, owner_credentials, process_identity


class DurableRelayError(RuntimeError):
    pass


def _receipt_timestamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def validate_adapter_contract(relay):
    """Fail before authority acquisition if durable adapter wiring is incomplete."""
    required = (
        "capture_opencode_watermark_evidence",
        "verify_opencode_arrival_evidence",
        "send_opencode",
    )
    missing = [name for name in required if not callable(getattr(relay, name, None))]
    if missing:
        raise DurableRelayError(
            "durable adapter contract unavailable: " + ", ".join(missing)
        )
    return True


def _fingerprint(value):
    raw = value.encode("utf-8")
    return hashlib.sha256(raw).hexdigest(), len(raw)


class DurableRelayAuthority:
    def __init__(self, client, pair_id, host_id, planner_destination, worker_destination):
        self.client = client
        self.pair_id = pair_id
        self.host_id = host_id
        match = re.search(r"/c/([^/?#]+)", planner_destination or "")
        self.planner_destination = unquote(match.group(1)) if match else planner_destination
        self.planner_destination_url = planner_destination
        self.worker_destination = worker_destination
        self.chatgpt_conversation_id = self.planner_destination
        self.opencode_session_id = worker_destination
        self.credentials = None
        self._identity = process_identity()

    def planner_observe(self, refresh=False):
        import relay_chatgpt_opencode as relay
        result = self.client.planner_observe(self.credentials, self.planner_destination_url,
            self.chatgpt_conversation_id, relay.SOURCE_POLICY, refresh)
        if isinstance(result, dict):
            # The compiled authority protocol uses uppercase state enums;
            # relay.tick and _durable_recheck use the Python relay constants.
            # Normalize at this adapter boundary so a valid IDLE Planner source
            # is not treated as a changed/unsafe source before submission.
            state = result.get("state")
            result = dict(result)
            result["state"] = {
                "IDLE": relay.IDLE, "WORKING": relay.WORKING,
                "UNKNOWN": relay.UNKNOWN, "AMBIGUOUS": relay.UNKNOWN,
            }.get(state, state)
        return result

    def planner_watermark(self):
        return self.client.planner_watermark(self.credentials, self.planner_destination_url, self.chatgpt_conversation_id)

    def planner_send(self, payload):
        return self.client.planner_send(self.credentials, self.planner_destination_url, self.chatgpt_conversation_id, payload)

    def planner_verify(self, payload, source_id, watermark):
        return self.client.planner_verify(self.credentials, self.planner_destination_url, self.chatgpt_conversation_id, payload, source_id, watermark)

    @classmethod
    def from_environment(cls, pair_id, planner_destination, worker_destination):
        endpoint = os.environ.get("BOT_AUTHORITY_ENDPOINT")
        token_file = os.environ.get("BOT_AUTHORITY_TOKEN_FILE")
        token = os.environ.get("BOT_AUTHORITY_TOKEN")
        if token_file:
            try:
                mode = os.stat(token_file).st_mode & 0o777
                if mode & 0o077:
                    raise DurableRelayError("durable authority token file must not be group/world accessible")
                with open(token_file, encoding="utf-8") as handle:
                    token = handle.read().strip()
            except DurableRelayError:
                raise
            except OSError as exc:
                raise DurableRelayError("durable authority token file is unavailable: %s" % exc) from exc
        if token_file and os.environ.get("BOT_AUTHORITY_TOKEN"):
            raise DurableRelayError("set either BOT_AUTHORITY_TOKEN_FILE or BOT_AUTHORITY_TOKEN, not both")
        if not endpoint or not token:
            raise DurableRelayError(
                "durable_authority requires BOT_AUTHORITY_ENDPOINT and a protected authority token file"
            )
        host_id = os.environ.get("BOT_HOST_ID") or socket.gethostname()
        timeout = float(os.environ.get("BOT_AUTHORITY_TIMEOUT", "5"))
        client = DeliveryAuthorityClient(endpoint, token, timeout=timeout)
        return cls(client, pair_id, host_id, planner_destination, worker_destination)

    def acquire(self):
        result = self.client.call("acquire_pair", {
            "pair_id": self.pair_id,
            "host_id": self.host_id,
            "credentials": {
                "pair_id": self.pair_id,
                "host_id": self.host_id,
                "execution_epoch": 0,
                "owner_token": "not-used",
                "process": self._identity,
            },
        })
        self.credentials = owner_credentials(
            self.pair_id, self.host_id, result["execution_epoch"], result["owner_token"], self._identity["pid"]
        )
        return result

    def validate_owner(self):
        if not self.credentials:
            raise DurableRelayError("authority owner credentials are not established")
        return self.client.call("resume_pair", {"credentials": self.credentials})

    def close(self):
        if self.credentials:
            try:
                self.client.call("release_pair", {"credentials": self.credentials})
            finally:
                self.credentials = None
        self.client.close()

    def turn_state(self):
        result = self.client.call("get_turn_state", {"pair_id": self.pair_id})
        return result or None

    def initialize_turn_state(self, expected, baseline):
        return self.client.call("initialize_turn_state", {
            "credentials": self.credentials,
            "expected_speaker": expected,
            "updated_watermark": {
                "planner": baseline.get("chatgpt"),
                "worker": baseline.get("opencode"),
            },
        })

    def diagnostics(self):
        return self.client.call("diagnostics", {"pair_id": self.pair_id})

    def startup_gate(self):
        return self.client.call("startup_gate", {"credentials": self.credentials, "chatgpt_conversation_id": self.chatgpt_conversation_id, "opencode_session_id": self.opencode_session_id})

    def enroll_pair(self, mode="migrated", history_verified=True, evidence="operator-verified enrollment"):
        return self.client.call("enroll_pair", {"credentials": self.credentials, "enrollment_mode": mode, "history_verified": history_verified, "enrollment_evidence": evidence, "chatgpt_conversation_id": self.chatgpt_conversation_id, "opencode_session_id": self.opencode_session_id})

    def create_migration_barrier(self, barrier_id, source_id, direction, destination, payload_sha256, payload_length, reason, evidence, source_conversation_id="", evidence_type="complete_fingerprint"):
        fields = {"credentials": self.credentials, "barrier_id": barrier_id, "source_id": source_id, "direction": direction, "destination": destination, "source_conversation_id": source_conversation_id, "evidence": reason, "decision_evidence": evidence, "evidence_type": evidence_type}
        if evidence_type == "complete_fingerprint":
            fields.update({"payload_sha256": payload_sha256, "payload_length": payload_length})
        return self.client.call("create_migration_barrier", fields)

    def decide_migration_barrier(self, barrier_id, decision, actor, evidence):
        return self.client.call("decide_migration_barrier", {"credentials": self.credentials, "barrier_id": barrier_id, "decision": decision, "decision_actor": actor, "decision_evidence": evidence})

    def claim(self, source_id, direction, destination, payload, observation=None):
        observation = observation or {}
        result = self.client.call("claim_submission", {
            "credentials": self.credentials,
            "source_id": source_id,
            "direction": direction,
            "destination": destination,
            "payload": payload,
            "source_role": observation.get("source_role"),
            "source_policy": observation.get("source_policy"),
            "source_conversation_id": observation.get("source_conversation_id"),
            "source_observed_at": observation.get("observed_at") or _receipt_timestamp(),
            "observation_boundary": observation.get("observation_boundary"),
            "chatgpt_conversation_id": self.chatgpt_conversation_id,
            "opencode_session_id": self.opencode_session_id,
        })
        if result.get("reusable") is not True:
            raise DurableRelayError("existing submission permit is not reusable")
        return result

    def record_outcome(self, permit_id, outcome, evidence):
        if not isinstance(evidence, str):
            evidence = json.dumps(evidence, separators=(",", ":"), sort_keys=True)
        return self.client.call("record_outcome", {
            "credentials": self.credentials,
            "permit_id": permit_id,
            "outcome": outcome,
            "evidence": evidence,
        })

    def reconcile(self, source_id, evidence):
        return self.client.call("reconcile", {
            "credentials": self.credentials,
            "source_id": source_id,
            "evidence": evidence,
        })

    def consume_and_advance(self, pending, evidence_id, next_expected, watermarks):
        return self.client.call("consume_and_advance", {
            "credentials": self.credentials,
            "source_id": pending["source_id"],
            "direction": pending["direction"],
            "evidence_id": evidence_id,
            "expected_previous_turn": pending["speaker"],
            "next_expected_speaker": next_expected,
            "updated_watermark": watermarks,
        })


def _state_from_authority(authority, snapshots, log):
    """Acquire ownership and construct state without dispatching startup data."""
    import relay_chatgpt_opencode as relay

    authority.acquire()
    gate = authority.startup_gate()
    if gate.get("startup_blocked"):
        raise DurableRelayError("startup blocked: " + (gate.get("reason") or "migration or enrollment gate rejected the pair"))
    durable = authority.turn_state()
    if callable(getattr(authority, "planner_observe", None)):
        planner_result = authority.planner_observe()
        planner_snapshot = (planner_result.get("state", relay.UNKNOWN), planner_result.get("message_id"),
                            planner_result.get("text"), planner_result.get("timestamp"), planner_result.get("detail"))
        relay._planner_observation = planner_result.get("observation")
    else:
        planner_snapshot = snapshots[0]
    state = relay.new_state()
    if durable:
        state["expected"] = durable["expectedSpeaker"]
        state["baseline"] = {
            "chatgpt": durable.get("plannerWatermark"),
            "opencode": durable.get("workerWatermark"),
        }
        log("durable authority state loaded; startup dispatch disabled")
    else:
        c, o = planner_snapshot, snapshots[1]
        c_time = c[3] if len(c) > 3 and isinstance(c[3], (int, float)) else None
        o_time = o[3] if len(o) > 3 and isinstance(o[3], (int, float)) else None
        state["expected"] = "worker" if c_time is not None and o_time is not None and c_time >= o_time else "planner"
        state["baseline"] = {"chatgpt": c[1], "opencode": o[1]}
        authority.initialize_turn_state(state["expected"], state["baseline"])
        log("durable authority baseline initialized; historical turns excluded")

    diagnostics = authority.diagnostics()
    records = [r for r in diagnostics.get("deliveries", [])
               if r.get("status") in ("submitting", "uncertain")]
    if records:
        if len(records) > 1:
            raise DurableRelayError("multiple unresolved durable deliveries require manual recovery")
        record = records[0]
        state["pending"] = {
            "direction": record["direction"],
            "source": "chatgpt" if record["direction"] == relay.P2W else "opencode",
            "speaker": "planner" if record["direction"] == relay.P2W else "worker",
            "source_id": record["sourceId"],
            "text": None,
            "permit_id": record.get("permitId"),
            "destination_id": authority.worker_destination if record["direction"] == relay.P2W else authority.planner_destination,
            "recovery_only": True,
            "outcome_recorded": record.get("status") == "uncertain",
        }
        log("durable unresolved delivery loaded; transport submission disabled")
    return state


def startup_state(authority, snapshots, log):
    try:
        return _state_from_authority(authority, snapshots, log)
    except Exception:
        authority.close()
        raise


def _destination(relay, direction, authority):
    return authority.worker_destination if direction == relay.P2W else authority.planner_destination


def _structured_evidence(relay, pending, raw):
    if not isinstance(raw, dict):
        raise DurableRelayError("durable confirmation requires structured evidence")
    required = ("destination_id", "source_id", "destination_message_id", "message_boundary",
                "payload_sha256", "payload_length", "observed_at", "provenance")
    if any(not raw.get(key) for key in required) or raw.get("source_id") != pending["source_id"]:
        raise DurableRelayError("confirmation evidence lacks source correlation or message boundary")
    if raw.get("destination_id") != pending["destination_id"] or raw.get("beyond_watermark") is not True:
        raise DurableRelayError("confirmation evidence lacks destination identity or post-watermark proof")
    expected_hash, expected_length = _fingerprint(pending["text"])
    if raw.get("payload_sha256") != expected_hash or int(raw.get("payload_length", -1)) != expected_length:
        raise DurableRelayError("confirmation evidence payload fingerprint does not match the claimed payload")
    return json.dumps(raw, separators=(",", ":"))


def _source_identity(observation):
    """The stable identity of a source observation.

    Only the fields that identify *which* source was observed belong here.
    `observed_at` is a wall-clock capture stamp that always advances between
    two reads of an unchanged source, and `observation_boundary` is derived
    context; neither may be used to decide that the source changed.
    """
    if not isinstance(observation, dict):
        return None
    return (
        observation.get("source_id"),
        observation.get("source_role"),
        observation.get("source_policy"),
        observation.get("source_conversation_id"),
        observation.get("payload_sha256"),
        observation.get("payload_length"),
    )


def _source_binding_valid(relay, pending):
    observation = pending.get("source_observation") or {}
    if observation.get("source_id") != pending.get("source_id"):
        return False
    expected_hash, expected_length = _fingerprint(pending.get("text") or "")
    if observation.get("payload_sha256") != expected_hash or int(observation.get("payload_length", -1)) != expected_length:
        return False
    if pending.get("direction") == relay.P2W:
        expected_role = "user" if relay.SOURCE_POLICY == "supervised_user_instruction" else "assistant"
        if observation.get("source_policy") != relay.SOURCE_POLICY or observation.get("source_role") != expected_role:
            return False
    return bool(observation.get("source_conversation_id"))


def _finish_confirmed(state, pending, authority, evidence, log):
    if not pending.get("outcome_recorded"):
        authority.record_outcome(pending["permit_id"], "confirmed", evidence)
        pending["outcome_recorded"] = True
    authority.reconcile(pending["source_id"], evidence)
    relay = __import__("relay_chatgpt_opencode")
    if pending["direction"] == relay.P2W:
        watermarks = {"planner": pending["source_id"], "worker": pending["worker_watermark"]}
    else:
        watermarks = {"planner": pending["mark_chatgpt"], "worker": pending["source_id"]}
    result = {"state": {"revision": "internal-recovery"}}
    if pending.get("recovery_kind") not in ("review", "prompt_request", "authorization_decision"):
        result = authority.consume_and_advance(pending, "evidence:" + pending["source_id"],
                                               relay._other(pending["speaker"]), watermarks)
    state["confirmed"][pending["direction"]] = pending["source_id"]
    if pending.get("recovery_kind") not in ("review", "prompt_request", "authorization_decision"):
        state["baseline"][pending["source"]] = pending["source_id"]
    if pending["direction"] == relay.W2P and pending.get("mark_chatgpt"):
        state["baseline"]["chatgpt"] = pending["mark_chatgpt"]
    state["pending"] = None
    state["expected"] = relay._other(pending["speaker"])
    if pending.get("authorization_decision"):
        relay._update_file_record(relay.AUTHORIZATION_FILE, pending["source_id"], "confirmed")
    if pending.get("recovery_kind") == "review":
        state["internal_pause"] = {
            "reason": pending.get("recovery_reason") or "non-actionable Planner message",
            "source_id": pending.get("recovery_source_id"),
            "worker_source_id": pending.get("recovery_worker_source_id"),
            "stage": "awaiting_planner_decision",
            "prompt_sent": True,
        }
        state["expected"] = "planner"
        relay._persist_recovery_state(state)
        log("RECOVERY_EVENT state=AWAITING_PLANNER_DECISION source=%s durable; awaiting exact Planner YES or NO" % pending.get("recovery_source_id"))
    elif pending.get("recovery_kind") == "prompt_request":
        state["internal_pause"]["stage"] = "awaiting_worker_prompt"
        state["expected"] = "planner"
        relay._persist_recovery_state(state)
        log("RECOVERY_EVENT state=AWAITING_WORKER_PROMPT source=%s durable; Planner approved; awaiting Worker prompt" % pending.get("recovery_source_id"))
    elif pending.get("recovery_kind") == "worker_prompt":
        state["internal_pause"] = None
        relay._persist_recovery_state(state)
        state["planner_loop_history"] = []
        state["planner_loop_source_id"] = None
        state["expected"] = "worker"
        log("RECOVERY_EVENT state=COMPLETED durable; normal relay resumes")
    elif pending["direction"] == relay.W2P:
        state["recovery_rounds"] = 0
    log("CONFIRMED durable %s [%s] revision=%s timestamp=%s" %
        (pending["direction"], pending["source_id"], result.get("state", {}).get("revision"),
         relay._iso_timestamp(pending.get("source_timestamp"))))
    return "confirmed " + pending["direction"]


def _queue_recovery_delivery(state, authority, transports, log, direction, source_id,
                            text, speaker, recovery_kind, reason=None,
                            worker_source_id=None, mark_chatgpt=None):
    """Claim and submit one internal recovery message through durable authority."""
    import relay_chatgpt_opencode as relay
    payload_hash, payload_length = _fingerprint(text)
    source_conversation_id = authority.worker_destination if direction == relay.W2P else authority.planner_destination
    authorization_decision = recovery_kind == "authorization_decision"
    observation = {
        "source_id": source_id,
        "source_role": "owner" if authorization_decision else ("worker_assistant" if direction == relay.W2P else "assistant"),
        "source_policy": "owner_authorization_decision" if authorization_decision else ("worker_report" if direction == relay.W2P else relay.SOURCE_POLICY),
        "source_conversation_id": source_conversation_id,
        "completion_status": "completed",
        "payload_sha256": payload_hash,
        "payload_length": payload_length,
        "observed_at": "authorization_decision" if authorization_decision else "recovery",
        "observation_boundary": {"authorization_decision": True} if authorization_decision else {"recovery": True},
    }
    destination_id = _destination(relay, direction, authority)
    pending = {
        "direction": direction,
        "source": "opencode" if direction == relay.W2P else "chatgpt",
        "speaker": speaker,
        "source_id": source_id,
        "text": text,
        "permit_id": None,
        "destination_id": destination_id,
        "watermark": None,
        "worker_watermark": state["baseline"].get("opencode"),
        "mark_chatgpt": mark_chatgpt,
        "outcome_recorded": False,
        "source_observation": observation,
        "source_timestamp": None,
        "recovery_kind": None if authorization_decision else recovery_kind,
        "recovery_reason": None if authorization_decision else reason,
        "recovery_source_id": None if authorization_decision else source_id,
        "recovery_worker_source_id": None if authorization_decision else worker_source_id,
        "authorization_decision": authorization_decision,
    }
    try:
        authority.validate_owner()
        permit = authority.claim(source_id, direction, destination_id, text, observation)
        pending["permit_id"] = permit["permit_id"]
    except Exception as exc:
        pending["claim_unknown"] = True
        state["pending"] = pending
        return "delivery held; durable recovery claim outcome is unknown (%s)" % exc
    state["pending"] = pending
    if direction == relay.P2W:
        capture = ((transports or {}).get("capture_opencode_watermark_evidence")
                   if transports is not None else None) or relay.capture_opencode_watermark_evidence
        pending["watermark"], error = capture()
        if pending["watermark"] is None:
            return "hold: recovery Worker watermark unavailable (%s); not sending" % error
    elif transports is None and callable(getattr(authority, "planner_watermark", None)):
        try:
            pending["watermark"] = authority.planner_watermark()
        except Exception as exc:
            return "hold: recovery Planner watermark unavailable (%s); not sending" % exc
    try:
        authority.validate_owner()
        if direction == relay.W2P and transports is None and callable(getattr(authority, "planner_send", None)):
            authority.planner_send(text)
        else:
            send_fn = ((transports or {}).get("send_chatgpt") if direction == relay.W2P
                       else (transports or {}).get("send_opencode"))
            send_fn = send_fn or (relay.send_chatgpt if direction == relay.W2P else relay.send_opencode)
            if not send_fn:
                raise DurableRelayError("OpenCode transport unavailable")
            send_fn(text)
    except Exception as exc:
        pending["submission_uncertain"] = True
        try:
            authority.record_outcome(pending["permit_id"], "uncertain", "recovery transport exception: %s" % exc)
            pending["outcome_recorded"] = True
        except Exception:
            pass
        return "delivery held; durable recovery submission outcome uncertain"
    return _durable_recheck(state, transports, authority, log)


def _durable_recovery_tick(state, snap_c, snap_o, transports, authority, log):
    """Advance the durable Recovery Conversation without forwarding control text."""
    import relay_chatgpt_opencode as relay
    recovery = state.get("internal_pause")
    if not recovery or state.get("expected") != "planner":
        return None
    c_id, c_text = snap_c[1], snap_c[2]
    o_st = snap_o[0]
    decision_result = relay._apply_recovery_decision(state, c_id, log)
    if decision_result is not None:
        return decision_result
    if not c_id or c_id == state["baseline"].get("chatgpt"):
        return "hold: Recovery Conversation awaits Planner"
    stage = recovery.get("stage", "awaiting_planner_decision")
    answer = relay._prompt_normalize(c_text)
    if stage == "awaiting_planner_decision":
        state["baseline"]["chatgpt"] = c_id
        relay._persist_recovery_state(state)
        if answer == "yes":
            source_id = "recovery_request_%s" % hashlib.sha256(
                (str(recovery.get("source_id")) + "\0" + str(c_id)).encode()).hexdigest()[:24]
            return _queue_recovery_delivery(
                state, authority, transports, log, relay.W2P, source_id,
                relay.RECOVERY_PROMPT_REQUEST, "worker", "prompt_request",
                worker_source_id=recovery.get("worker_source_id"), mark_chatgpt=c_id)
        if answer == "no":
            recovery["stage"] = "operator_decision_required"
            recovery["planner_reason"] = "Planner could not generate a safe Worker prompt."
            relay._persist_recovery_state(state)
            log("RECOVERY_EVENT state=OPERATOR_DECISION_REQUIRED source=%s durable; Planner could not generate a safe Worker prompt" % recovery.get("source_id"))
            return "hold: Planner requires operator decision"
        return "hold: Recovery Conversation requires exact YES or NO"
    if stage == "awaiting_worker_prompt":
        prompt = relay.extract_recovery_worker_prompt(c_text)
        if not prompt:
            recovery["prompt_attempts"] = recovery.get("prompt_attempts", 0) + 1
            if recovery["prompt_attempts"] >= relay.RECOVERY_MAX_ROUNDS:
                recovery["stage"] = "operator_decision_required"
                recovery["decision_request"] = "Planner did not provide a concrete Worker prompt within the bounded recovery attempts."
                relay._persist_recovery_state(state)
                log("RECOVERY_EVENT state=OPERATOR_DECISION_REQUIRED source=%s durable; prompt extraction limit reached" % recovery.get("source_id"))
                return "hold: Planner requires operator decision"
            relay._persist_recovery_state(state)
            return "hold: Planner prompt is not actionable"
        if o_st == relay.WORKING:
            return "hold: worker busy; recovery prompt deferred until worker is idle"
        state["baseline"]["chatgpt"] = c_id
        relay._persist_recovery_state(state)
        return _queue_recovery_delivery(
            state, authority, transports, log, relay.P2W, c_id, prompt,
            "planner", "worker_prompt", worker_source_id=recovery.get("worker_source_id"),
            mark_chatgpt=c_id)
    return "hold: Planner requires operator decision"


def _durable_recheck(state, transports, authority, log):
    import relay_chatgpt_opencode as relay
    pending = state["pending"]
    if not pending.get("permit_id"):
        return "delivery held; authority claim outcome is unknown"
    if pending.get("recovery_only"):
        return "delivery held; recovered uncertainty requires manual reconciliation"
    if pending["direction"] == relay.W2P and transports is None and callable(getattr(authority, "planner_verify", None)):
        try:
            result = authority.planner_verify(pending["text"], pending["source_id"], pending.get("watermark"))
            verdict = result.get("verdict", relay.INCONCLUSIVE)
            evidence = result.get("evidence") or {}
        except Exception as exc:
            verdict, evidence = relay.INCONCLUSIVE, {"error": str(exc)}
        structured = True
        verify_fn = None
    else:
        structured_key = "verify_opencode_evidence" if pending["direction"] == relay.P2W else "verify_chatgpt_evidence"
        legacy_key = "verify_opencode" if pending["direction"] == relay.P2W else "verify_chatgpt"
        structured = structured_key in (transports or {}) or transports is None
        verify_fn = ((transports or {}).get(structured_key) if structured else (transports or {}).get(legacy_key))
        if verify_fn is None and structured:
            verify_fn = getattr(relay, "verify_opencode_arrival_evidence" if pending["direction"] == relay.P2W else "verify_chatgpt_arrival_evidence", None)
        if not verify_fn:
            return "delivery held; structured durable verification is unavailable"
        try:
            if structured:
                raw = verify_fn(pending["text"], pending.get("watermark"), pending["source_id"], pending["destination_id"])
            elif pending["direction"] == relay.P2W:
                raw = verify_fn(pending["text"], pending.get("watermark"))
            else:
                raw = verify_fn(pending["text"])
            verdict, evidence = raw
        except Exception as exc:
            verdict, evidence = relay.INCONCLUSIVE, {"error": str(exc)}
    if (pending.get("recovery_kind") == "worker_prompt" and verdict != relay.CONFIRMED
            and not pending.get("supervisor_check_attempted")
            and pending.get("text") is not None):
        pending["supervisor_check_attempted"] = True
        supervisor = relay.supervisor_delivery_state(pending, evidence, log)
        pending["supervisor_state"] = supervisor
        supervisor_state = supervisor.get("state")
        message_id = supervisor.get("message_id")
        if supervisor_state in ("RECEIVED", "COMPLETED") and message_id and message_id != "NONE":
            payload_hash, payload_length = _fingerprint(pending["text"])
            verdict = relay.CONFIRMED
            evidence = {
                "destination_id": pending["destination_id"],
                "source_id": pending["source_id"],
                "destination_message_id": message_id,
                "message_boundary": message_id,
                "beyond_watermark": True,
                "payload_sha256": payload_hash,
                "payload_length": payload_length,
                "observed_at": relay._utc_now(),
                "provenance": "read-only-supervisor-inspection",
            }
        elif supervisor_state == "NOT_RECEIVED" and pending.get("recovery_retry_count", 0) < 1:
            pending["recovery_retry_count"] = pending.get("recovery_retry_count", 0) + 1
            pending["supervisor_check_attempted"] = False
            send_fn = (transports or {}).get("send_opencode") or relay.send_opencode
            try:
                authority.validate_owner()
                send_fn(pending["text"])
                log("RECOVERY_EVENT state=RETRYING_NOT_RECEIVED durable; retrying the same recovery operation once")
                return "Supervisor confirmed not received; durable recovery prompt retry sent"
            except Exception as exc:
                pending["submission_uncertain"] = True
                try:
                    authority.record_outcome(pending["permit_id"], "uncertain", "durable recovery retry exception: %s" % exc)
                    pending["outcome_recorded"] = True
                except Exception:
                    pass
                return "delivery held; durable recovery retry outcome uncertain (%s)" % exc
        elif supervisor_state == "STILL_WORKING":
            return "recovery prompt state check: Worker still working"
        elif supervisor_state == "UNABLE":
            return "delivery held; Supervisor could not determine recovery prompt state"
    if verdict == relay.CONFIRMED:
        try:
            structured = _structured_evidence(relay, pending, evidence)
            return _finish_confirmed(state, pending, authority, structured, log)
        except Exception as exc:
            evidence = {"error": str(exc), "verification": "structured evidence rejected"}
            verdict = relay.INCONCLUSIVE
    if not pending.get("outcome_recorded"):
        try:
            authority.record_outcome(pending["permit_id"], "uncertain", json.dumps(evidence, default=str)[:2000])
            pending["outcome_recorded"] = True
        except Exception as exc:
            log("durable outcome could not be recorded; holding: %s" % exc)
    return "delivery held; durable outcome is uncertain"


def durable_tick(state, snap_c, snap_o, transports, authority, log):
    import relay_chatgpt_opencode as relay
    c_st, c_id, c_text = snap_c[:3]
    o_st, o_id, o_text = snap_o[:3]
    if c_st == relay.UNKNOWN or o_st == relay.UNKNOWN:
        return "hold: a source is UNKNOWN; durable dispatch withheld"
    if state.get("pending"):
        if state["pending"]["direction"] == relay.W2P and c_id:
            state["pending"]["mark_chatgpt"] = c_id
        return _durable_recheck(state, transports, authority, log)
    queued = relay.authorization_guidance()
    if state.get("expected") == "planner" and queued and queued.get("destination") == "planner":
        if c_st == relay.WORKING:
            return "hold: Planner busy; authorization decision queued"
        result = _queue_recovery_delivery(
            state, authority, transports, log, relay.W2P,
            queued["message_id"], queued["message"], "owner",
            "authorization_decision", mark_chatgpt=c_id)
        if state.get("pending") is not None:
            state["pending"]["authorization_decision"] = True
        return result
    recovery_result = _durable_recovery_tick(state, snap_c, snap_o, transports, authority, log)
    if recovery_result is not None:
        return recovery_result
    if c_st == relay.WORKING or o_st == relay.WORKING:
        if c_st == relay.WORKING and o_st == relay.WORKING:
            return "hold: planner busy; worker busy"
        if o_st == relay.WORKING:
            return "hold: worker busy"
        return "hold: planner busy"
    direction, source, dest = relay._route(state["expected"])
    latest_id, latest_text = (c_id, c_text) if source == "chatgpt" else (o_id, o_text)
    if not latest_id or latest_id == state["baseline"].get(source):
        return "hold: no new completed message from " + source
    if direction == relay.P2W:
        if relay._is_verified_terminal_stop(latest_text):
            state["baseline"]["chatgpt"] = latest_id
            state["planner_loop_history"] = []
            state["planner_loop_source_id"] = None
            state["expected"] = "planner"
            return "hold: Planner confirmed all authorized work complete"
        # Durable authority must apply the same semantic gate as the legacy
        # relay before it claims a permit. A completed Planner status is still
        # a completed source observation, but it is not Worker work; claiming
        # it would turn an acknowledgement loop into an authorized delivery.
        # Count a source only once while it remains the latest observation so
        # polling the same message cannot manufacture a loop.
        if relay.extract_worker_prompt(latest_text) is None:
            if relay.planner_requires_owner_authorization(latest_text):
                state["baseline"]["chatgpt"] = latest_id
                state["planner_loop_history"] = []
                state["planner_loop_source_id"] = None
                state["expected"] = "planner"
                scope = relay.planner_authorization_scope(latest_text)
                alternative_id = "authorization_alternatives_" + hashlib.sha256(
                    ((getattr(authority, "pair_id", None) or relay.PAIR_ID) + "\0" + latest_id).encode()).hexdigest()[:48]
                state["pending"] = {
                    "direction": relay.W2P, "source": "opencode", "speaker": "worker",
                    "source_id": alternative_id, "text": relay.AUTHORIZATION_ALTERNATIVE_PROMPT,
                    "supervisor_id": None, "mark_chatgpt": latest_id, "attempts": 0,
                    "retry_ready": False, "watermark": None,
                    "authorization_alternative_request": True,
                }
                log("AUTHORIZATION_HOLD source=%s reason=owner_authorization_required scope=%s worker_dispatch=none" %
                    (latest_id, scope))
                return "hold: Planner requires owner authorization; requesting alternate authorized work separately"
            reason = "Planner message has no actionable prompt"
            if state.get("planner_loop_source_id") != latest_id:
                state["planner_loop_source_id"] = latest_id
                if relay._planner_loop_detected(state, latest_text, o_text):
                    reason = "repeated Planner status loop"
                else:
                    reason = "Planner message has no actionable prompt"
            if reason == "repeated Planner status loop" or not o_text or (transports and "verify_chatgpt_evidence" not in transports):
                log("STATUS_HOLD durable source=%s reason=%s" % (latest_id, reason))
                return "hold: " + reason
            source_id = "recovery_%s" % hashlib.sha256(
                ((getattr(authority, "pair_id", None) or relay.PAIR_ID) + "\0" + reason + "\0" + str(latest_id) + "\0" + str(o_id)).encode()
            ).hexdigest()[:24]
            prompt = relay.recovery_conversation_prompt(o_text, reason)
            return _queue_recovery_delivery(
                state, authority, transports, log, relay.W2P, source_id,
                prompt, "worker", "review", reason=reason,
                worker_source_id=o_id, mark_chatgpt=latest_id
            )
        state["planner_loop_history"] = []
        state["planner_loop_source_id"] = None
    wm = None
    if direction == relay.P2W:
        capture = ((transports or {}).get("capture_opencode_watermark_evidence")
                   if transports is None or "capture_opencode_watermark_evidence" in (transports or {})
                   else (transports or {}).get("capture_opencode_watermark"))
        capture = capture or (relay.capture_opencode_watermark_evidence if transports is None else relay.capture_opencode_watermark)
        wm, err = capture()
        if wm is None:
            return "hold: pre-dispatch watermark unavailable (%s); not sending" % err
    else:
        if transports is None and callable(getattr(authority, "planner_watermark", None)):
            try:
                wm = authority.planner_watermark()
            except Exception as exc:
                return "hold: pre-dispatch Planner watermark unavailable (%s); not sending" % exc
        else:
            if transports is not None and "capture_chatgpt_watermark_evidence" not in transports:
                wm = None
                capture = None
            else:
                capture = ((transports or {}).get("capture_chatgpt_watermark_evidence") or getattr(relay, "capture_chatgpt_watermark_evidence", None))
            if capture:
                wm, err = capture()
                if wm is None:
                    return "hold: pre-dispatch watermark unavailable (%s); not sending" % err
            elif transports is None:
                return "hold: pre-dispatch Planner watermark unavailable; not sending"
    if direction == relay.P2W:
        observation = relay.planner_source_observation()
        if observation is None or observation.get("source_id") != latest_id:
            payload_hash, payload_length = _fingerprint(latest_text)
            observation = {
                "source_id": latest_id,
                "source_role": "assistant",
                "source_policy": relay.SOURCE_POLICY,
                "source_conversation_id": relay._chatgpt_conversation_identity(relay.CHATGPT_URL) or relay.CHATGPT_URL,
                "completion_status": "completed",
                "payload_sha256": payload_hash,
                "payload_length": payload_length,
                "observed_at": "synthetic",
                "observation_boundary": {"synthetic": True},
            }
    else:
        payload_hash, payload_length = _fingerprint(latest_text)
        observation = {
            "source_id": latest_id,
            "source_role": "worker_assistant",
            "source_policy": "worker_report",
            "source_conversation_id": authority.worker_destination,
            "completion_status": "completed",
            "payload_sha256": payload_hash,
            "payload_length": payload_length,
            "observation_boundary": {"worker_watermark": state["baseline"].get("opencode")},
        }
    if not isinstance(observation, dict) or observation.get("source_id") != latest_id:
        return "hold: source observation is missing or changed; not claiming"
    try:
        authority.validate_owner()
        permit = authority.claim(latest_id, direction, _destination(relay, direction, authority), latest_text, observation)
    except Exception as exc:
        # A claim timeout may have committed a permit. Preserve a local barrier
        # and do not issue a second claim or invoke the browser transport.
        state["pending"] = {
            "direction": direction, "source": source, "speaker": state["expected"],
            "source_id": latest_id, "text": latest_text, "permit_id": None,
            "destination_id": _destination(relay, direction, authority),
            "claim_unknown": True,
        }
        return "delivery held; authority claim outcome is unknown (%s)" % exc
    pending = {
        "direction": direction, "source": source, "speaker": state["expected"],
        "source_id": latest_id, "text": latest_text, "permit_id": permit["permit_id"],
        "destination_id": _destination(relay, direction, authority), "watermark": wm,
        "worker_watermark": state["baseline"].get("opencode"),
        "mark_chatgpt": c_id, "outcome_recorded": False,
        "source_observation": observation,
        "source_timestamp": relay._iso_timestamp(observation.get("observed_at")),
    }
    state["pending"] = pending
    send_fn = ((transports or {}).get("send_opencode") or getattr(relay, "send_opencode", None)) if direction == relay.P2W else None
    if direction == relay.P2W and not send_fn:
        pending["submission_uncertain"] = True
        return "delivery held; durable transport unavailable"
    try:
        authority.validate_owner()
        if direction == relay.P2W and transports is None:
            if callable(getattr(authority, "planner_observe", None)):
                fresh = authority.planner_observe()
                fresh_state, fresh_id, fresh_text = fresh.get("state"), fresh.get("message_id"), fresh.get("text")
                fresh_observation = fresh.get("observation")
            else:
                fresh_state, fresh_id, fresh_text = relay.planner_state()[:3]
                fresh_observation = relay.planner_source_observation()
            # Compare the observed source identity only. The capture timestamp
            # advances on every read, so a whole-dict comparison would report
            # a changed source for an unchanged Planner turn.
            if (fresh_state != relay.IDLE or fresh_id != pending["source_id"]
                    or fresh_text != pending["text"]
                    or _source_identity(fresh_observation)
                    != _source_identity(pending["source_observation"])):
                pending["submission_uncertain"] = True
                authority.record_outcome(pending["permit_id"], "uncertain", "Planner source changed before submission")
                pending["outcome_recorded"] = True
                return "delivery held; Planner source changed before submission"
        if not _source_binding_valid(relay, pending):
            pending["submission_uncertain"] = True
            authority.record_outcome(pending["permit_id"], "uncertain", "source observation or permit binding changed before submission")
            pending["outcome_recorded"] = True
            return "delivery held; source binding changed before submission"
        if direction == relay.P2W:
            if transports is None:
                send_fn(latest_text, progress=log)
            else:
                send_fn(latest_text)
        elif transports is None and callable(getattr(authority, "planner_send", None)):
            authority.planner_send(latest_text)
        else:
            send_fn = (transports or {}).get("send_chatgpt") or getattr(relay, "send_chatgpt", None)
            if not send_fn:
                raise DurableRelayError("Planner transport unavailable")
            send_fn(latest_text)
    except Exception as exc:
        pending["submission_uncertain"] = True
        try:
            authority.record_outcome(pending["permit_id"], "uncertain", "transport exception: %s" % exc)
            pending["outcome_recorded"] = True
        except Exception:
            pass
        return "delivery held; durable submission outcome uncertain"
    return _durable_recheck(state, transports, authority, log)
