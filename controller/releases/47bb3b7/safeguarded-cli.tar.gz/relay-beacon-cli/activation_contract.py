"""Fail-closed validation for the M6 coordinated-dispatch activation contract."""

import json
from datetime import date
from pathlib import Path


ROOT = Path(__file__).resolve().parent
CONTRACT_PATH = ROOT / "M6_ACTIVATION_CONTRACT.json"
ALLOWED_CLASSES = {"proven", "environment-dependent", "manual-attestation"}
ALLOWED_STATUSES = {"proven", "partial", "missing"}
ALLOWED_LEVELS = {"L1", "L2", "L3", "L4"}
LEVEL_RANK = {level: rank for rank, level in enumerate(sorted(ALLOWED_LEVELS), start=1)}


def load_contract(path=CONTRACT_PATH):
    with Path(path).open(encoding="utf-8") as stream:
        contract = json.load(stream)
    if contract.get("schema") not in {1, 2} or contract.get("activation") not in {"closed", "open"}:
        raise ValueError("M6 contract has an invalid activation state")
    items = contract.get("items")
    if not isinstance(items, list) or not items:
        raise ValueError("M6 contract has no controls")
    ids = []
    for item in items:
        if not isinstance(item, dict):
            raise ValueError("M6 contract contains an invalid control")
        control_id = item.get("id")
        if not isinstance(control_id, str) or not control_id or control_id in ids:
            raise ValueError("M6 contract contains duplicate or invalid control IDs")
        ids.append(control_id)
        if item.get("class") not in ALLOWED_CLASSES:
            raise ValueError(f"unknown evidence class for {control_id}")
        if item.get("status") not in ALLOWED_STATUSES:
            raise ValueError(f"unknown status for {control_id}")
        if item.get("required") is not True or item.get("minimum_level") not in ALLOWED_LEVELS:
            raise ValueError(f"incomplete evidence declaration for {control_id}")
        if not isinstance(item.get("required_platforms"), list) or not item["required_platforms"] or not isinstance(item.get("required_capability"), str):
            raise ValueError(f"incomplete requirement declaration for {control_id}")
        evidence = item.get("evidence")
        required_evidence = {"level", "platform", "environment", "capability", "mock", "reference", "commit", "verified_at", "expires_at", "dependencies"}
        if not isinstance(evidence, dict) or not required_evidence.issubset(evidence):
            raise ValueError(f"incomplete evidence record for {control_id}")
        if evidence["level"] not in ALLOWED_LEVELS or not isinstance(evidence["platform"], list) or not evidence["platform"]:
            raise ValueError(f"invalid evidence level or platform for {control_id}")
        if not isinstance(evidence["environment"], str) or not isinstance(evidence["capability"], str) or not isinstance(evidence["mock"], bool):
            raise ValueError(f"invalid evidence identity for {control_id}")
        if not isinstance(evidence["reference"], str) or not evidence["reference"]:
            raise ValueError(f"missing evidence reference for {control_id}")
        if not isinstance(evidence["commit"], (str, list)) or not evidence["commit"]:
            raise ValueError(f"missing evidence commit for {control_id}")
        try:
            verified = date.fromisoformat(evidence["verified_at"])
            expires = date.fromisoformat(evidence["expires_at"])
        except (TypeError, ValueError) as error:
            raise ValueError(f"invalid evidence dates for {control_id}") from error
        if expires < verified or expires < date.today():
            raise ValueError(f"expired evidence for {control_id}")
        if not isinstance(evidence["dependencies"], list):
            raise ValueError(f"invalid evidence dependencies for {control_id}")
    blockers = contract.get("hard_blockers")
    if not isinstance(blockers, list) or any(blocker not in ids for blocker in blockers):
        raise ValueError("M6 contract has invalid hard blockers")
    return contract


def activation_report(path=CONTRACT_PATH):
    contract = load_contract(path)
    missing = []
    insufficient = {}
    for item in contract["items"]:
        if not item["required"]:
            continue
        evidence = item["evidence"]
        reasons = []
        if item["status"] != "proven":
            reasons.append("status is not proven")
        if LEVEL_RANK[evidence["level"]] < LEVEL_RANK[item["minimum_level"]]:
            reasons.append(f"{evidence['level']} is below {item['minimum_level']}")
        if not set(item["required_platforms"]).issubset(set(evidence["platform"])):
            reasons.append("evidence platform scope does not satisfy required platforms")
        if evidence["capability"] != item["required_capability"]:
            reasons.append("evidence capability does not satisfy required capability")
        if reasons:
            missing.append(item["id"])
            insufficient[item["id"]] = reasons
    missing.sort()
    blockers = sorted(set(missing) & set(contract["hard_blockers"]))
    return {
        "ready": not missing and not blockers and contract["activation"] == "open",
        "activation": contract["activation"],
        "missing_controls": missing,
        "partial_controls": sorted(item["id"] for item in contract["items"] if item["status"] == "partial"),
        "insufficient_evidence": insufficient,
        "hard_blockers": blockers,
        "evidence_classes": {item["id"]: item["class"] for item in contract["items"]},
        "evidence_matrix": {
            item["id"]: {
                "level": item["evidence"]["level"],
                "minimum_level": item["minimum_level"],
                "required_platforms": item["required_platforms"],
                "required_capability": item["required_capability"],
                "platform": item["evidence"]["platform"],
                "mock": item["evidence"]["mock"],
                "reference": item["evidence"]["reference"],
            } for item in contract["items"]
        },
    }


if __name__ == "__main__":
    print(json.dumps(activation_report(), sort_keys=True))
