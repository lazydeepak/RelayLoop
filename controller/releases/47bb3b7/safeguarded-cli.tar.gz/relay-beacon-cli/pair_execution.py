"""Exact binding validation for already-registered Planner/Worker pairs.

This replaces permanent retirement policy authorization. Registration and
restoration do not dispatch provider messages; callers must supply the exact
registered pair binding before invoking an execution operation.
"""
from contextlib import contextmanager
from urllib.parse import urlparse
import re


class PairExecutionError(RuntimeError):
    pass


def validate_binding(pair_id, chatgpt_url=None, session_id=None):
    if not isinstance(pair_id, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,79}", pair_id):
        raise PairExecutionError("A valid registered pair ID is required.")
    if not isinstance(chatgpt_url, str) or not isinstance(session_id, str):
        raise PairExecutionError(f"Pair '{pair_id}' has no complete Planner/Worker binding.")
    parsed = urlparse(chatgpt_url)
    if parsed.scheme != "https" or parsed.hostname not in ("chatgpt.com", "www.chatgpt.com") or parsed.username or parsed.password or parsed.query or parsed.fragment or not re.search(r"(?:^|/)c/[A-Za-z0-9._%:-]+/?$", parsed.path):
        raise PairExecutionError("Planner conversation URL must identify an exact HTTPS ChatGPT conversation.")
    if not re.fullmatch(r"ses_[A-Za-z0-9]+", session_id):
        raise PairExecutionError("Worker session ID is invalid.")


@contextmanager
def authorize(pair_id, action, chatgpt_url=None, session_id=None):
    validate_binding(pair_id, chatgpt_url, session_id)
    yield {"pair_id": pair_id, "action": action, "chatgpt_url": chatgpt_url, "session_id": session_id}
