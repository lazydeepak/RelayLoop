"""Additive locked launcher; no lifecycle registry writes or provider retries."""
import json
import os
import sys

from relay_pair_lock import acquire_pair_lock


def run(relay, managed=True, **loop_options):
    lock = acquire_pair_lock(relay.PAIR_ID)
    if lock is None:
        raise RuntimeError('Pair already has a relay owner or its lock is unavailable')
    try:
        if not managed:
            return relay.run_loop(relay.establish_baseline(), **loop_options)
        if os.environ.get('BOT_RELAY_MODE', 'legacy_fail_closed') != 'legacy_fail_closed':
            raise RuntimeError('Managed Node admission cannot silently bypass a different relay authority mode')
        if os.environ.get('BOT_DISPATCH_POLICY', 'legacy') != 'legacy':
            raise RuntimeError('Managed Node admission cannot downgrade a different dispatch policy')
        from managed_dispatch import ManagedDispatch
        admission = ManagedDispatch(relay, {})
        def fresh_boundary():
            observed = {}

            def observe(side, read):
                value = read()
                observed[side] = value
                return value

            state = relay.establish_baseline(
                sp=lambda: observe('chatgpt', relay.planner_state),
                sw=lambda: observe('opencode', relay.worker_state),
                durable_records=admission.startup_records(),
                startup_mode=getattr(relay, "STARTUP_MODE", None),
            )
            if any(snapshot[0] == relay.UNKNOWN for snapshot in observed.values()):
                raise RuntimeError('Cannot establish a readable managed startup boundary')
            # Durable source records are the only authority allowed to reopen a
            # startup turn: they prove which messages were already delivered and
            # substitute a deterministic recovery prompt instead of replaying.
            # Without that evidence, startup and timed reconciliation must never
            # reopen historical turns — the timestamp heuristic cannot tell a
            # new instruction from one the previous generation already sent.
            if not state.get('durable_startup'):
                state['baseline'] = {side: snapshot[1] for side, snapshot in observed.items()}
                state['expected'] = 'planner'
                state['pending'] = None
                state.pop('startup_recovery', None)
            return state

        state = fresh_boundary()
        ready = os.environ['BOT_RELAY_READY_FILE']
        token = os.environ['BOT_RELAY_START_TOKEN']
        with open(ready + '.tmp', 'w') as stream:
            json.dump({'pair_id': relay.PAIR_ID, 'pid': os.getpid(), 'token': token}, stream)
        os.replace(ready + '.tmp', ready)
        # EOF on Node crash/cancellation cannot authorize execution.
        command = sys.stdin.readline()
        if not command or json.loads(command) != {'go': token}:
            raise RuntimeError('Managed relay admission was not confirmed')
        # The parent only completes the running lifecycle transition as part of
        # the go handshake, so durable history is only readable now. Re-run the
        # boundary only when durable records actually exist: re-observing
        # without evidence could baseline away a message that arrived during
        # the handshake, and the pre-ready fail-closed baseline is already safe.
        if admission.startup_records():
            state = fresh_boundary()
        admission.state = state
        if loop_options.get('transports') is not None:
            raise RuntimeError('Managed execution cannot replace its admission transports')
        loop_options['transports'] = admission.transports()
        loop_options['restart_baseline'] = fresh_boundary
        restore = admission.install_fences()
        try:
            return relay.run_loop(state, **loop_options)
        finally:
            restore()
    finally:
        lock.release()
