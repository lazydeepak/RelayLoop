/**
 * Comprehensive ChatGPT tab state inspector for diagnosing timeouts,
 * background throttling, modal blockers, and DOM virtualization during relay operations.
 */

export async function inspectChatGPTTabState(page) {
  if (!page || typeof page.evaluate !== 'function') {
    return { evaluationError: 'Invalid page object' };
  }
  try {
    return await page.evaluate(() => {
      const href = location.href;
      const title = document.title;
      const readyState = document.readyState;
      const visibilityState = document.visibilityState;

      // Detect Cloudflare Turnstile or CAPTCHA challenges
      const cloudflare = Boolean(
        document.querySelector('#challenge-running, #cf-turnstile, [data-cf-beacon], iframe[src*="cloudflare"], iframe[src*="challenges"]') ||
        title.toLowerCase().includes('just a moment') ||
        title.toLowerCase().includes('attention required')
      );

      // Detect unauthenticated / login redirect state
      const authBlocked = Boolean(
        (document.querySelector('a[href*="/auth/login"], a[href*="/login"], button[data-testid="login-button"]') &&
         !document.querySelector('#prompt-textarea, [data-testid="send-button"], [data-message-author-role]')) ||
        href.includes('/auth/login') ||
        href.includes('/login')
      );

      // Detect blocking modal dialogs
      const dialogs = Array.from(document.querySelectorAll('[role="dialog"], [role="alertdialog"], .modal')).map((el) => {
        const heading = el.querySelector('h1, h2, h3, [role="heading"]');
        return {
          title: heading?.innerText?.trim() || el.getAttribute('aria-label') || 'unnamed-dialog',
          visible: Boolean(el.offsetWidth > 0 && el.offsetHeight > 0),
        };
      }).filter((d) => d.visible);

      // Detect error banners or rate-limit warnings
      const errorBanners = Array.from(document.querySelectorAll(
        '[role="alert"], [data-testid*="error"], .text-token-text-error, .bg-red-500, .border-red-500, [class*="errorMessage"]'
      )).map((el) => (el.innerText || el.textContent || '').trim()).filter(Boolean).slice(0, 3);

      // Inspect composer elements
      const composerSelectors = [
        '#prompt-textarea',
        'form [contenteditable="true"][role="textbox"]',
        '[contenteditable="true"][role="textbox"]',
        'textarea[tabindex="0"]',
      ];
      let composerFound = false;
      let composerVisible = false;
      let composerDisabled = false;
      let composerTextLength = 0;
      let composerSelector = null;
      let composerCount = 0;

      for (const sel of composerSelectors) {
        const nodes = document.querySelectorAll(sel);
        if (nodes.length > 0) {
          composerFound = true;
          composerCount = nodes.length;
          composerSelector = sel;
          const first = nodes[0];
          composerVisible = Boolean(first.offsetWidth > 0 && first.offsetHeight > 0);
          composerDisabled = first.hasAttribute('disabled') ||
            first.getAttribute('aria-disabled') === 'true' ||
            first.getAttribute('contenteditable') === 'false';
          const text = first.value || first.innerText || first.textContent || '';
          composerTextLength = text.length;
          break;
        }
      }

      // Inspect send button candidates
      const sendSelectors = [
        'button[data-testid="send-button"]',
        'button[data-testid="fruitjuice-send-button"]',
        'button[data-testid*="send" i]',
        'button[aria-label="Send prompt"]',
        'button[aria-label="Send message"]',
        'button[aria-label*="Send" i]',
        'form button[type="submit"]',
      ];
      let sendButtonFound = false;
      let sendButtonVisible = false;
      let sendButtonEnabled = false;
      let sendButtonSelector = null;

      for (const sel of sendSelectors) {
        const btn = document.querySelector(sel);
        if (btn) {
          sendButtonFound = true;
          sendButtonSelector = sel;
          sendButtonVisible = Boolean(btn.offsetWidth > 0 && btn.offsetHeight > 0);
          sendButtonEnabled = !btn.disabled && btn.getAttribute('aria-disabled') !== 'true';
          break;
        }
      }

      // Inspect stop button & streaming signals
      const stopBtn = document.querySelector('button[data-testid="stop-button"], button[aria-label*="Stop" i], button[data-testid*="stop" i]');
      const stopButtonVisible = Boolean(stopBtn && stopBtn.offsetWidth > 0 && stopBtn.offsetHeight > 0);
      const isStreaming = Boolean(
        document.querySelector('[data-is-streaming="true"], [data-result-streaming="true"], [data-composer-streaming="true"]') ||
        stopButtonVisible
      );

      // Inspect turn counts
      const userMessageCount = document.querySelectorAll('[data-user-message-bubble], [data-message-author-role="user"]').length;
      const assistantMessageCount = document.querySelectorAll('[data-content-search-unit-key*="assistant"], [data-dil-message-id], [data-message-author-role="assistant"]').length;

      return {
        url: href,
        title,
        readyState,
        visibilityState,
        cloudflare,
        authBlocked,
        dialogs,
        errorBanners,
        composer: {
          found: composerFound,
          count: composerCount,
          selector: composerSelector,
          visible: composerVisible,
          disabled: composerDisabled,
          textLength: composerTextLength,
        },
        sendButton: {
          found: sendButtonFound,
          selector: sendButtonSelector,
          visible: sendButtonVisible,
          enabled: sendButtonEnabled,
        },
        generating: {
          stopButtonVisible,
          isStreaming,
        },
        messages: {
          user: userMessageCount,
          assistant: assistantMessageCount,
        },
      };
    });
  } catch (err) {
    return {
      evaluationError: err.message || String(err),
      url: page.url ? page.url() : 'unknown',
    };
  }
}

export function formatTabSummary(state) {
  if (!state) return 'tab_state=null';
  if (state.evaluationError) {
    return `evaluation_failed: ${state.evaluationError}`;
  }
  const flags = [];
  if (state.visibilityState && state.visibilityState !== 'visible') flags.push(`vis=${state.visibilityState}`);
  if (state.readyState && state.readyState !== 'complete') flags.push(`ready=${state.readyState}`);
  if (state.cloudflare) flags.push('CLOUDFLARE_CHALLENGE');
  if (state.authBlocked) flags.push('AUTH_REQUIRED');
  if (state.dialogs?.length) flags.push(`dialogs="${state.dialogs.map((d) => d.title).join(',')}"`);
  if (state.errorBanners?.length) flags.push(`errors="${state.errorBanners.join(';')}"`);
  if (state.generating?.isStreaming) flags.push('STREAMING');
  if (state.generating?.stopButtonVisible) flags.push('STOP_BTN_VISIBLE');

  const comp = state.composer?.found
    ? `comp[vis=${state.composer.visible},dis=${state.composer.disabled},len=${state.composer.textLength}]`
    : 'comp[NOT_FOUND]';

  const send = state.sendButton?.found
    ? `send[vis=${state.sendButton.visible},en=${state.sendButton.enabled}]`
    : 'send[NOT_FOUND]';

  const msgs = `msgs(u=${state.messages?.user || 0},a=${state.messages?.assistant || 0})`;

  const flagStr = flags.length ? ` !FLAGS:[${flags.join(' ')}]` : '';
  return `url=${state.url || 'unknown'} title="${state.title || ''}" ${comp} ${send} ${msgs}${flagStr}`;
}

export async function waitForFunctionWithDiagnostics(page, fn, arg, options = {}, contextLabel = 'wait') {
  const timeoutMs = options.timeout ?? 15000;
  const beforeState = await inspectChatGPTTabState(page);
  console.error(`[ChatGPT Tab State before ${contextLabel}] ${formatTabSummary(beforeState)}`);

  // If the page is hidden, bring it to front to prevent background timer throttling
  if (beforeState.visibilityState === 'hidden') {
    await page.bringToFront().catch(() => {});
  }

  try {
    return await page.waitForFunction(fn, arg, { ...options, timeout: timeoutMs });
  } catch (error) {
    const afterState = await inspectChatGPTTabState(page);
    const diagSummary = formatTabSummary(afterState);
    console.error(`[ChatGPT Tab State TIMEOUT in ${contextLabel} (${timeoutMs}ms)] ${diagSummary}`);
    const enrichedError = new Error(`${error.message} | Tab state at timeout: ${diagSummary}`);
    enrichedError.originalError = error;
    enrichedError.tabStateBefore = beforeState;
    enrichedError.tabStateAfter = afterState;
    throw enrichedError;
  }
}
