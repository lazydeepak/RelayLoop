import { chromium } from 'playwright';
import fs from 'fs';
import { destinationEvidence, payloadEvidence, redactDiagnostic, SUBMISSION_PHASES } from './chatgpt_submission.js';
import { inspectChatGPTTabState, formatTabSummary } from './chatgpt_tab_state.js';

const targetUrl = process.argv[2];
const message = fs.readFileSync(0, 'utf8');

function conversationId(url) {
  const match = url.match(/\/c\/([a-f0-9-]+)/i);
  return match ? match[1] : null;
}

function normalize(text) {
  return (text || '').replace(/\s+/g, ' ').trim();
}

function pageConversationId(url) {
  try {
    const path = new URL(url).pathname;
    const match = path.match(/\/c\/([^/?#]+)/i);
    return match ? decodeURIComponent(match[1]) : null;
  } catch {
    return null;
  }
}

async function readDestination(page, expectedConversationId) {
  return page.evaluate((conversationId) => {
    const identity = (node) => {
      const direct = node.getAttribute('data-message-id') || node.getAttribute('data-user-message-id') ||
        node.getAttribute('data-dil-message-id');
      if (direct) return { id: direct, ambiguous_id: false };
      const group = node.closest('[data-chatgpt-search-message-ids]');
      const values = (group?.getAttribute('data-chatgpt-search-message-ids') || '')
        .trim().split(/\s+/).filter(Boolean);
      const unique = [...new Set(values)];
      return { id: unique.length === 1 ? unique[0] : null, ambiguous_id: unique.length > 1 };
    };
    const currentId = (() => {
      try {
        const match = new URL(location.href).pathname.match(/\/c\/([^/?#]+)/i);
        return match ? decodeURIComponent(match[1]) : null;
      } catch { return null; }
    })();
    return {
      conversation_id: currentId,
      users: [...document.querySelectorAll('[data-user-message-bubble], [data-message-author-role="user"]')]
        .map((node) => ({ ...identity(node), text: node.innerText || node.textContent || '', conversation_id: currentId })),
      expected_conversation_id: conversationId,
    };
  }, expectedConversationId);
}

let activePage = null;
let lastObservedTabState = null;

async function observeDestination(page, conversationId, expectedText, beforeIds, timeoutMs = 15000) {
  const stateBefore = await inspectChatGPTTabState(page);
  lastObservedTabState = stateBefore;
  console.error(`[ChatGPT Tab State before observeDestination (${timeoutMs}ms)] ${formatTabSummary(stateBefore)}`);
  const deadline = Date.now() + timeoutMs;
  let last = { confirmed: false, reason: 'no observation yet' };
  while (Date.now() < deadline) {
    const snapshot = await readDestination(page, conversationId);
    last = destinationEvidence({
      conversation_id: snapshot.conversation_id,
      expected_conversation_id: conversationId,
      expected_text: expectedText,
      before_ids: beforeIds,
      observed: snapshot.users,
      observed_at: new Date().toISOString(),
    });
    if (last.confirmed) return last;
    await page.waitForTimeout(250);
  }
  const stateAfter = await inspectChatGPTTabState(page);
  lastObservedTabState = stateAfter;
  console.error(`[ChatGPT Tab State after observeDestination timeout] ${formatTabSummary(stateAfter)} - reason: ${last.reason || 'unconfirmed'}`);
  return last;
}

let phase = SUBMISSION_PHASES.PREPARING;
let irreversible = false;
let diagnostic = {};

async function findComposer(page, timeoutMs = 10000) {
  const stateBefore = await inspectChatGPTTabState(page);
  lastObservedTabState = stateBefore;
  console.error(`[ChatGPT Tab State before findComposer] ${formatTabSummary(stateBefore)}`);

  const candidateSelectors = [
    '#prompt-textarea',
    'form [contenteditable="true"][role="textbox"]',
    '[contenteditable="true"][role="textbox"][aria-label="Ask ChatGPT"]',
    '[contenteditable="true"][role="textbox"]',
    'textarea[tabindex="0"]',
  ];

  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    for (const selector of candidateSelectors) {
      const locator = page.locator(selector);
      const count = await locator.count().catch(() => 0);
      if (count === 0) continue;

      const visibleElements = [];
      for (let i = 0; i < count; i++) {
        const el = locator.nth(i);
        const isVisible = await el.isVisible().catch(() => false);
        if (isVisible) {
          visibleElements.push(el);
        }
      }

      if (visibleElements.length === 1) {
        return visibleElements[0];
      }

      if (visibleElements.length > 1) {
        // If multiple are visible, prefer the one inside a form
        for (const el of visibleElements) {
          const inForm = await el.evaluate((node) => Boolean(node.closest('form'))).catch(() => false);
          if (inForm) return el;
        }
        // Otherwise return the last visible one (bottom chat composer)
        return visibleElements[visibleElements.length - 1];
      }
    }
    await page.waitForTimeout(300);
  }

  const stateFail = await inspectChatGPTTabState(page);
  lastObservedTabState = stateFail;
  console.error(`[ChatGPT Tab State findComposer failed (${timeoutMs}ms)] ${formatTabSummary(stateFail)}`);
  throw new Error(`ChatGPT composer not found or not visible | Tab state: ${formatTabSummary(stateFail)}`);
}

(async () => {
  if (!targetUrl || !message.trim()) throw new Error('target URL and non-empty message are required');
  const id = conversationId(targetUrl);
  if (!id) throw new Error(`target URL does not contain a conversation ID`);

  const browser = await chromium.connectOverCDP('http://localhost:9222/json/version');
  try {
    const pages = browser.contexts().flatMap((context) => context.pages());
    const page = pages.find((candidate) => candidate.url().includes(id));
    if (!page) throw new Error(`ChatGPT conversation tab not found: ${id}`);
    activePage = page;
    const expectedConversationId = pageConversationId(targetUrl);
    if (!expectedConversationId || pageConversationId(page.url()) !== expectedConversationId) {
      throw new Error('ChatGPT destination conversation identity mismatch');
    }

    await page.bringToFront().catch(() => {});
    lastObservedTabState = await inspectChatGPTTabState(page);
    console.error(`[ChatGPT Tab State on attach] ${formatTabSummary(lastObservedTabState)}`);

    if (lastObservedTabState?.generating?.isStreaming || lastObservedTabState?.generating?.stopButtonVisible) {
      console.error('[ChatGPT Tab State] Waiting for active generation to conclude before composer typing...');
      const waitDeadline = Date.now() + 15000;
      while (Date.now() < waitDeadline) {
        await page.waitForTimeout(500);
        lastObservedTabState = await inspectChatGPTTabState(page);
        if (!lastObservedTabState?.generating?.isStreaming && !lastObservedTabState?.generating?.stopButtonVisible) {
          break;
        }
      }
      if (lastObservedTabState?.generating?.isStreaming || lastObservedTabState?.generating?.stopButtonVisible) {
        throw new Error(`ChatGPT is still generating previous response; cannot submit to busy composer | Tab state: ${formatTabSummary(lastObservedTabState)}`);
      }
    }

    const composer = await findComposer(page);
    let submissionMessage = message;
    const existingDraftRaw = await composer.evaluate((el) => el.value || el.innerText || el.textContent || '').catch(() => '');
    const existingDraft = normalize(
      existingDraftRaw
    );
    const retryOriginal = message.includes('Original message:')
      ? normalize(message.slice(message.indexOf('Original message:') + 'Original message:'.length))
      : '';
    // A prior attempt may have reached the composer but not the submit
    // boundary. Complete that exact pending draft instead of overwriting it
    // with a second copy of the logical operation.
    if (existingDraft && (existingDraft.includes(normalize(message))
        || (retryOriginal && existingDraft.includes(retryOriginal)))) {
      submissionMessage = existingDraftRaw;
    }
    await composer.focus();
    if (submissionMessage === message) {
      try {
        await composer.fill(message);
      } catch {
        if (typeof composer.pressSequentially === 'function') {
          await composer.pressSequentially(message);
        } else {
          await composer.type(message);
        }
      }
    }
    const draft = normalize(
      await composer.evaluate((el) => el.value || el.innerText || el.textContent || '').catch(() => '')
    );
    if (!draft.includes(normalize(submissionMessage))) {
      throw new Error('ChatGPT composer did not retain the full message draft');
    }
    phase = SUBMISSION_PHASES.COMPOSER_READY;

    // This is the irreversible provider boundary. Every later error is uncertain.
    phase = SUBMISSION_PHASES.SUBMIT_BOUNDARY_ENTERED;
    irreversible = true;

    const sendButtonCandidates = [
      'button[data-testid="send-button"]',
      'button[data-testid="fruitjuice-send-button"]',
      'button[data-testid*="send" i]',
      'button[aria-label="Send prompt"]',
      'button[aria-label="Send message"]',
      'button[aria-label="Send"]',
      'button[aria-label*="Send" i]',
      'form button[type="submit"]',
    ];

    const stopButtonSelectors = [
      'button[data-testid="stop-button"]',
      'button[aria-label*="Stop" i]',
      'button[data-testid*="stop" i]',
    ];

    const readDraft = async () => normalize(
      await composer.evaluate((el) => el.value || el.innerText || el.textContent || '').catch(() => '')
    );
    const messageNorm = normalize(submissionMessage);

    // Detect that ChatGPT actually started processing the submission: the send
    // button is replaced by a "stop generating" control, or the composer cleared.
    // This guards retries so we never send twice when the first Enter really did
    // register but the DOM was just slow to update.
    const initialStopButtonVisible = Boolean(lastObservedTabState?.generating?.stopButtonVisible);
    const submissionStarted = async () => {
      for (const sel of stopButtonSelectors) {
        const btn = page.locator(sel).first();
        if (await btn.isVisible().catch(() => false)) {
          if (!initialStopButtonVisible) return true;
        }
      }
      const d = await readDraft();
      if (!d || !d.includes(messageNorm)) return true;
      return false;
    };

    let submitActionAttempted = false;
    let cleared = false;

    // Retry is deliberately limited and guarded: we only retry when there is NO
    // evidence that the submission started (no stop button, draft still fully
    // present). That makes a duplicate send very unlikely while still recovering
    // from the rare case where Enter is swallowed by the DOM.
    for (let attempt = 0; attempt < 3 && !cleared; attempt++) {
      const stateBeforeAttempt = await inspectChatGPTTabState(page);
      lastObservedTabState = stateBeforeAttempt;
      console.error(`[ChatGPT Tab State before submit attempt ${attempt + 1}/3] ${formatTabSummary(stateBeforeAttempt)}`);

      if (await submissionStarted()) { cleared = true; break; }

      await composer.focus().catch(() => {});
      await page.waitForTimeout(100);

      // Attempt 1: Enter key
      try {
        await composer.press('Enter');
        submitActionAttempted = true;
      } catch {}
      await page.waitForTimeout(700);
      if (await submissionStarted()) { cleared = true; break; }

      // Attempt 2: click an enabled send button
      let clicked = false;
      for (const sel of sendButtonCandidates) {
        const btn = page.locator(sel).first();
        if (await btn.isVisible().catch(() => false) && await btn.isEnabled().catch(() => false)) {
          await btn.click().catch(() => {});
          submitActionAttempted = true;
          clicked = true;
          break;
        }
      }
      if (clicked) {
        await page.waitForTimeout(700);
        if (await submissionStarted()) { cleared = true; break; }
      }

      // Attempt 3: keyboard Enter as a final fallback within this iteration
      if (!cleared && !(await submissionStarted())) {
        await composer.focus().catch(() => {});
        await page.waitForTimeout(50);
        try {
          await page.keyboard.press('Enter');
          submitActionAttempted = true;
        } catch {}
        await page.waitForTimeout(700);
        if (await submissionStarted()) { cleared = true; break; }
      }
    }

    if (!submitActionAttempted) {
      throw new Error('ChatGPT submit action was not attempted');
    }
    // If, after guarded retries, there is still no evidence the submission
    // started, do not claim success — hold for reconciliation instead of
    // risking a silent stuck message or a false success.
    if (!cleared && !(await submissionStarted())) {
      const stateAfterSubmit = await inspectChatGPTTabState(page);
      lastObservedTabState = stateAfterSubmit;
      console.error(`[ChatGPT Tab State submit not cleared] ${formatTabSummary(stateAfterSubmit)}`);
      throw new Error(`ChatGPT composer did not clear after submit attempts; message may be stuck in input | Tab state: ${formatTabSummary(stateAfterSubmit)}`);
    }

    // The relay's durable logical identity correlates any bounded retry. DOM
    // read-back is deliberately diagnostic, not the turn-advancing gate:
    // ChatGPT can accept the submission while its message DOM is stale or
    // virtualized. Do not claim destination confirmation here.
    phase = SUBMISSION_PHASES.CONFIRMED;
    diagnostic = { ...payloadEvidence(submissionMessage), conversation_id: expectedConversationId, confirmation: 'submit_action_accepted' };
    console.log(JSON.stringify({ status: 'submitted', phase, evidence: diagnostic }));
  } finally {
    await browser.close().catch(() => {});
  }
})().catch(async (error) => {
  // A failure after the boundary is never a proven pre-submit failure.
  let finalState = null;
  if (activePage) {
    try { finalState = await inspectChatGPTTabState(activePage); } catch {}
  }
  if (finalState) {
    lastObservedTabState = finalState;
    console.error(`[ChatGPT Tab State at failure] ${formatTabSummary(finalState)}`);
  }
  const messageText = redactDiagnostic(error.message || String(error));
  const reportPhase = phase || SUBMISSION_PHASES.PREPARING;
  const status = irreversible ? SUBMISSION_PHASES.UNCERTAIN : SUBMISSION_PHASES.FAILED_BEFORE_SUBMIT;
  const report = { status, phase: reportPhase, error: messageText, diagnostic: { ...diagnostic, tab_state: finalState || lastObservedTabState } };
  console.log(JSON.stringify({ type: 'send_diagnostic', ...report }));
  console.error(JSON.stringify({ type: 'send_error', ...report }));
  process.exitCode = 1;
});
