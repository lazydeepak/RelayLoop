#!/usr/bin/env python3
"""Shared approved-model registry and terminal manager.

The registry stores model references and user-approved ordering only. Provider
credentials and OpenCode request headers remain in OpenCode's own credential
store and are never read or copied here.
"""
import json
import os
import re
import tempfile

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODELS_FILE = os.environ.get("BOT_MODELS_FILE", os.path.join(BASE_DIR, "models.json"))

DEFAULT_REGISTRY = {
    "version": 1,
    "models": [],
    "recovery": {
        "retry_delay_seconds": 60,
        "max_rounds": 3,
    },
}

_ID_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,63}$")
_MODEL_REF_RE = re.compile(r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.:/@~+-]+(?:#[A-Za-z0-9_.-]+)?$")


class ModelRegistryError(ValueError):
    pass


def validate_registry(data):
    """Validate and normalize the persisted registry without mutating it."""
    if not isinstance(data, dict) or data.get("version") != 1:
        raise ModelRegistryError("Model registry must be a version 1 object")
    models = data.get("models")
    if not isinstance(models, list):
        raise ModelRegistryError("models must be a list")

    seen_ids = set()
    seen_refs = set()
    normalized = []
    for index, model in enumerate(models):
        if not isinstance(model, dict):
            raise ModelRegistryError(f"models[{index}] must be an object")
        model_id = model.get("id")
        name = model.get("name")
        model_ref = model.get("model_ref")
        rank = model.get("rank")
        enabled = model.get("enabled", True)
        if not isinstance(model_id, str) or not _ID_RE.fullmatch(model_id):
            raise ModelRegistryError(f"models[{index}].id must be a lowercase slug")
        if model_id in seen_ids:
            raise ModelRegistryError(f"duplicate model id: {model_id}")
        if not isinstance(name, str) or not name.strip():
            raise ModelRegistryError(f"models[{index}].name is required")
        if not isinstance(model_ref, str) or not _MODEL_REF_RE.fullmatch(model_ref):
            raise ModelRegistryError(
                f"models[{index}].model_ref must be an OpenCode provider/model reference"
            )
        if model_ref in seen_refs:
            raise ModelRegistryError(f"duplicate model reference: {model_ref}")
        if not isinstance(rank, int) or isinstance(rank, bool) or rank < 1 or rank > 10000:
            raise ModelRegistryError(f"models[{index}].rank must be an integer from 1 to 10000")
        if not isinstance(enabled, bool):
            raise ModelRegistryError(f"models[{index}].enabled must be true or false")

        availability = model.get("availability")
        if availability is not None and availability not in ("local", "free", "paid", "unknown"):
            raise ModelRegistryError(f"models[{index}].availability is invalid")

        seen_ids.add(model_id)
        seen_refs.add(model_ref)
        normalized_item = {
            "id": model_id,
            "name": name.strip(),
            "model_ref": model_ref,
            "rank": rank,
            "enabled": enabled,
        }
        for key in ("provider_id", "availability", "free", "local", "cost", "source"):
            if key in model:
                normalized_item[key] = model[key]
        normalized.append(normalized_item)

    recovery = data.get("recovery", {})
    if not isinstance(recovery, dict):
        raise ModelRegistryError("recovery must be an object")
    retry_delay = recovery.get("retry_delay_seconds", 60)
    max_rounds = recovery.get("max_rounds", 3)
    if not isinstance(retry_delay, int) or isinstance(retry_delay, bool) or not 5 <= retry_delay <= 3600:
        raise ModelRegistryError("retry_delay_seconds must be an integer from 5 to 3600")
    if not isinstance(max_rounds, int) or isinstance(max_rounds, bool) or not 1 <= max_rounds <= 10:
        raise ModelRegistryError("max_rounds must be an integer from 1 to 10")

    normalized.sort(key=lambda item: (not item["enabled"], item["rank"], item["id"]))
    # Canonicalize ranks: each enabled/disabled group gets sequential 1..n ranks.
    enabled_rank = 0
    disabled_rank = 0
    for item in normalized:
        if item["enabled"]:
            enabled_rank += 1
            item["rank"] = enabled_rank
        else:
            disabled_rank += 1
            item["rank"] = disabled_rank

    return {
        "version": 1,
        "models": normalized,
        "recovery": {
            "retry_delay_seconds": retry_delay,
            "max_rounds": max_rounds,
        },
    }


def load_registry(path=None):
    path = path or MODELS_FILE
    if not os.path.exists(path):
        return json.loads(json.dumps(DEFAULT_REGISTRY))
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError) as exc:
        raise ModelRegistryError(f"Could not read model registry {path}: {exc}") from exc
    return validate_registry(data)


def save_registry(data, path=None):
    path = path or MODELS_FILE
    normalized = validate_registry(data)
    directory = os.path.dirname(os.path.abspath(path))
    fd, temp_path = tempfile.mkstemp(prefix=".models-", suffix=".tmp", dir=directory)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(normalized, f, indent=2)
            f.write("\n")
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp_path, path)
    finally:
        try:
            os.unlink(temp_path)
        except FileNotFoundError:
            pass
    return normalized


def enabled_models(registry=None):
    registry = registry or load_registry()
    return [model for model in registry["models"] if model["enabled"]]


def model_budget_allowed(model, budget=None):
    """Apply Phase 1's narrow budget rule without declaring unknown models free."""
    kind = model.get("availability")
    if kind in ("local", "free"):
        return True
    if kind == "paid":
        return isinstance(budget, (int, float)) and not isinstance(budget, bool) and budget > 0
    # Legacy entries have no OpenCode cost evidence. Keep them selectable only
    # under the existing explicit configuration; they are never free.
    return isinstance(budget, (int, float)) and not isinstance(budget, bool) and budget > 0


def sync_from_opencode(path=None, opencode_bin=None, include_paid=True):
    """Merge OpenCode's live catalog while preserving explicit selections."""
    from opencode_model_catalog import read_catalog
    current = load_registry(path)
    rows = read_catalog(opencode_bin)
    by_ref = {item["model_ref"]: item for item in current["models"]}
    next_rank = max((item["rank"] for item in current["models"]), default=0)
    additions = []
    for row in rows:
        if row["availability"] == "paid" and not include_paid:
            continue
        existing = by_ref.get(row["model_ref"])
        if existing:
            existing.update({k: row[k] for k in ("provider_id", "availability", "free", "local", "cost", "source")})
            continue
        next_rank += 10
        slug = re.sub(r"[^a-z0-9_-]+", "-", row["model_ref"].lower()).strip("-_")[:64] or f"model-{next_rank}"
        ids = {item["id"] for item in current["models"] + additions}
        base = slug
        while slug in ids:
            slug = f"{base[:55]}-{next_rank}"
        item = {"id": slug, "name": row["name"], "model_ref": row["model_ref"],
                "rank": next_rank, "enabled": row["availability"] in ("local", "free"), **row}
        additions.append(item)
    saved = save_registry({**current, "models": current["models"] + additions}, path)
    return saved, rows, additions


def _slug(value):
    slug = re.sub(r"[^a-z0-9_-]+", "-", value.lower()).strip("-_")
    return slug[:64] or "model"


def _ask(prompt, input_fn):
    return input_fn(prompt).strip()


def manage_models_terminal(input_fn=input, output_fn=print, path=None):
    """Interactive CRUD and priority editor used by the relay's N menu option."""
    while True:
        registry = load_registry(path)
        models = registry["models"]
        output_fn("\n--- Approved AI Models (priority order) ---")
        if not models:
            output_fn("No models approved yet. Add a model reference such as openrouter/provider/model.")
        for item in models:
            status = "enabled" if item["enabled"] else "disabled"
            output_fn(f"  [{item['rank']}] {item['name']} — {item['model_ref']} ({status}; id={item['id']})")
        output_fn(f"\nRetry wait: {registry['recovery']['retry_delay_seconds']}s; "
                  f"passes: {registry['recovery']['max_rounds']}")
        output_fn("Options: [A]dd, [E]dit, [R]ank, [T]oggle, [D]elete, [S]ettings, [0/B] Back")
        choice = _ask("Option: ", input_fn).lower()
        if choice in ("", "0", "b", "back", "q", "quit"):
            return
        if choice in ("a", "add"):
            name = _ask("Display name: ", input_fn)
            if not name:
                output_fn("Add cancelled: display name is required.")
                continue
            model_ref = _ask("OpenCode model reference (provider/model): ", input_fn)
            model_id = _slug(model_ref.replace("/", "-"))
            rank = max((m["rank"] for m in models), default=0) + 10
            candidate = {"id": model_id, "name": name, "model_ref": model_ref,
                         "rank": rank, "enabled": True}
            try:
                save_registry({**registry, "models": models + [candidate]}, path)
                output_fn(f"Added {name} at priority {rank}.")
            except ModelRegistryError as exc:
                output_fn(f"Could not add model: {exc}")
            continue
        if choice in ("e", "edit"):
            model_id = _ask("Model id to edit: ", input_fn)
            item = next((m for m in models if m["id"] == model_id), None)
            if not item:
                output_fn("Model not found.")
                continue
            name = _ask(f"Display name [{item['name']}]: ", input_fn) or item["name"]
            model_ref = _ask(f"Model reference [{item['model_ref']}]: ", input_fn) or item["model_ref"]
            rank_text = _ask(f"Rank [{item['rank']}]: ", input_fn)
            try:
                rank = int(rank_text) if rank_text else item["rank"]
                updated = [{**m, "name": name, "model_ref": model_ref, "rank": rank}
                           if m["id"] == model_id else m for m in models]
                save_registry({**registry, "models": updated}, path)
                output_fn("Model updated.")
            except (ValueError, ModelRegistryError) as exc:
                output_fn(f"Could not update model: {exc}")
            continue
        if choice in ("r", "rank", "reorder"):
            model_id = _ask("Model id to rank: ", input_fn)
            if not any(m["id"] == model_id for m in models):
                output_fn("Model not found.")
                continue
            rank_text = _ask("New rank (lower runs first): ", input_fn)
            try:
                rank = int(rank_text)
                updated = [{**m, "rank": rank} if m["id"] == model_id else m for m in models]
                save_registry({**registry, "models": updated}, path)
                output_fn("Priority updated.")
            except (ValueError, ModelRegistryError) as exc:
                output_fn(f"Could not update priority: {exc}")
            continue
        if choice in ("t", "toggle", "enable", "disable"):
            model_id = _ask("Model id to toggle: ", input_fn)
            if not any(m["id"] == model_id for m in models):
                output_fn("Model not found.")
                continue
            updated = [{**m, "enabled": not m["enabled"]} if m["id"] == model_id else m
                       for m in models]
            save_registry({**registry, "models": updated}, path)
            output_fn("Model enabled state updated.")
            continue
        if choice in ("d", "delete"):
            model_id = _ask("Model id to delete: ", input_fn)
            item = next((m for m in models if m["id"] == model_id), None)
            if not item:
                output_fn("Model not found.")
                continue
            confirm = _ask(f"Delete '{item['name']}'? [y/N]: ", input_fn).lower()
            if confirm in ("y", "yes"):
                save_registry({**registry, "models": [m for m in models if m["id"] != model_id]}, path)
                output_fn("Model deleted.")
            continue
        if choice in ("s", "settings"):
            delay_text = _ask(f"Retry delay seconds [{registry['recovery']['retry_delay_seconds']}]: ", input_fn)
            rounds_text = _ask(f"Maximum retry passes [{registry['recovery']['max_rounds']}]: ", input_fn)
            try:
                recovery = {
                    "retry_delay_seconds": int(delay_text) if delay_text else registry["recovery"]["retry_delay_seconds"],
                    "max_rounds": int(rounds_text) if rounds_text else registry["recovery"]["max_rounds"],
                }
                save_registry({**registry, "recovery": recovery}, path)
                output_fn("Recovery settings saved.")
            except (ValueError, ModelRegistryError) as exc:
                output_fn(f"Could not update recovery settings: {exc}")
            continue
        output_fn("Unknown option. Choose A/E/R/T/D/S or 0 to go back.")
