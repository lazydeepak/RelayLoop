"""Isolated adapters for the existing ChatGPT/OpenCode provider boundaries.

The normal Worker -> Planner ChatGPT boundary imports this module. Other
provider families use it only from isolated tests until separately integrated.
Adapters construct the same command shapes as the current implementations.
"""
import json
from dataclasses import dataclass, replace
from typing import Callable, Iterable, Optional

from dispatch_executor import (
    COORDINATED,
    Coordinator,
    CoordinatorAdmission,
    DispatchRequest,
    ExecutionOutcome,
    PreExecutionRejection,
    dispatch_once,
)


@dataclass(frozen=True)
class CommandResult:
    returncode: int
    stdout: str = ""
    stderr: str = ""


Runner = Callable[..., CommandResult]


def _redact_diagnostic(value: str) -> str:
    """Keep both streams while removing common credential-bearing fields."""
    import re
    text = str(value or "")
    text = re.sub(r"(?i)(authorization\s*[:=]\s*bearer\s+)[^\s,;]+", r"\1[redacted]", text)
    text = re.sub(r"(?i)(cookie\s*[:=]\s*)[^\n]+", r"\1[redacted]", text)
    text = re.sub(r"\bsk-[A-Za-z0-9_-]{12,}\b", "[redacted]", text)
    return text.strip()[:1000]


def _error(result: CommandResult, label: str) -> str:
    stdout = _redact_diagnostic(getattr(result, "stdout", "")) or "<empty>"
    stderr = _redact_diagnostic(getattr(result, "stderr", "")) or "<empty>"
    return "%s failed: stderr=%s; stdout=%s" % (label, stderr, stdout)


def _model_payload(model_ref: str) -> str:
    provider, separator, model = model_ref.partition("/")
    model_id, marker, variant = model.partition("#")
    if not separator or not provider or not model_id:
        raise PreExecutionRejection("invalid failover model reference")
    selected = {"providerID": provider, "id": model_id}
    if marker:
        selected["variant"] = variant
    return json.dumps({"model": selected}, separators=(",", ":"))


class ChatGPTDOMAdapter:
    """Build the existing `node send_chatgpt.js URL` submission boundary."""

    def __init__(self, script_path: str, runner: Runner):
        self.script_path = script_path
        self.runner = runner

    def invoke(self, request: DispatchRequest, _admission: Optional[CoordinatorAdmission] = None):
        result = self.runner(
            ["node", self.script_path, request.chatgpt_url], input=request.text,
            capture_output=True, text=True,
        )
        if result.returncode != 0:
            error = RuntimeError(_error(result, "ChatGPT DOM submission"))
            # Preserve both streams for callers that need structured phase
            # diagnostics, without exposing raw credential-bearing output.
            error.stdout = _redact_diagnostic(getattr(result, "stdout", ""))
            error.stderr = _redact_diagnostic(getattr(result, "stderr", ""))
            diagnostic = None
            for stream in (error.stdout, error.stderr):
                for line in reversed((stream or '').splitlines()):
                    try:
                        candidate = json.loads(line)
                    except (TypeError, ValueError):
                        continue
                    if isinstance(candidate, dict) and candidate.get('status'):
                        diagnostic = candidate
                        break
                if diagnostic:
                    break
            # The browser boundary explicitly proves that no Enter/click was
            # attempted. Preserve that proof as a retryable pre-execution
            # rejection instead of converting it into delivery ambiguity.
            if diagnostic and diagnostic.get('status') == 'failed_before_submit':
                raise PreExecutionRejection(
                    'ChatGPT submission failed before submit: %s' %
                    str(diagnostic.get('error') or diagnostic.get('reason') or 'unknown')[:500]
                ) from error
            raise error
        return result

    def legacy_provider(self, request: DispatchRequest):
        return self.invoke(request)

    def coordinated_provider(self, request: DispatchRequest, admission: CoordinatorAdmission):
        return self.invoke(request, admission)


class OpenCodeAdapter:
    """Build the existing `opencode run --session SESSION [--model MODEL]` edge."""

    def __init__(self, binary: str, runner: Runner,
                 definitive_failure: Optional[Callable[[CommandResult], bool]] = None):
        self.binary = binary
        self.runner = runner
        self.definitive_failure = definitive_failure or (lambda _result: False)

    def invoke(self, request: DispatchRequest, _admission: Optional[CoordinatorAdmission] = None,
               model_ref: Optional[str] = None, preserve_failure: bool = False):
        command = [self.binary, "run", "--session", request.session_id]
        if model_ref:
            command.extend(["--model", model_ref])
        command.append(request.text)
        result = self.runner(command, capture_output=True, text=True)
        if result.returncode != 0:
            if preserve_failure:
                return result
            if self.definitive_failure(result):
                raise PreExecutionRejection(_error(result, "OpenCode pre-execution rejection"))
            raise RuntimeError(_error(result, "OpenCode execution"))
        return result

    def legacy_provider(self, request: DispatchRequest):
        return self.invoke(request, preserve_failure=True)

    def coordinated_provider(self, request: DispatchRequest, admission: CoordinatorAdmission,
                             model_ref: Optional[str] = None):
        return self.invoke(request, admission, model_ref)


# Descriptive name for the production integration seam; retain the shorter
# adapter name used by the isolated M6 tests.
OpenCodeExecutionAdapter = OpenCodeAdapter


class OpenCodeContinuationAdapter(OpenCodeAdapter):
    """Continuation edge requiring the relay's existing admission context."""

    def coordinated_provider(self, request: DispatchRequest, admission: CoordinatorAdmission,
                             model_ref: Optional[str] = None):
        if not request.continuation_admission:
            raise PreExecutionRejection("continuation admission context is missing")
        return super().coordinated_provider(request, admission, model_ref)

    def legacy_provider(self, request: DispatchRequest):
        if not request.continuation_admission:
            raise RuntimeError("continuation admission context is missing")
        return self.invoke(request, preserve_failure=True)


class OpenCodeFailoverAdapter(OpenCodeAdapter):
    """Model switch plus run, matching the existing failover attempt boundary."""

    def __init__(self, binary: str, runner: Runner, switch_runner: Optional[Runner] = None,
                 definitive_failure: Optional[Callable[[CommandResult], bool]] = None):
        super().__init__(binary, runner, definitive_failure)
        self.switch_runner = switch_runner or runner

    def coordinated_provider(self, request: DispatchRequest, admission: CoordinatorAdmission,
                             model_ref: Optional[str] = None):
        return self._attempt(request, model_ref, coordinated=True, admission=admission)

    def legacy_attempt(self, request: DispatchRequest, model_ref: str):
        return self._attempt(request, model_ref, coordinated=False)

    def _attempt(self, request: DispatchRequest, model_ref: Optional[str], *,
                 coordinated: bool, admission: Optional[CoordinatorAdmission] = None):
        if not model_ref:
            raise PreExecutionRejection("failover attempt requires a model reference")
        switch = self.switch_runner([
            self.binary, "api", "post", "/api/session/%s/model" % request.session_id,
            "--data", _model_payload(model_ref),
        ])
        if switch.returncode != 0:
            if not coordinated:
                raise RuntimeError(_error(switch, "OpenCode model switch"))
            raise PreExecutionRejection(_error(switch, "OpenCode model switch"))
        if coordinated:
            return super().coordinated_provider(request, admission, model_ref)
        return self.invoke(request, model_ref=model_ref, preserve_failure=not coordinated)


def dispatch_failover(
    request: DispatchRequest,
    models: Iterable[str],
    adapter: OpenCodeAdapter,
    *,
    coordinator: Optional[Coordinator] = None,
    policy: str = COORDINATED,
    prompt_for_attempt: Optional[Callable[[int, str], str]] = None,
    on_outcome: Optional[Callable[[str, ExecutionOutcome], None]] = None,
):
    """Try independently identified model attempts without retrying ambiguity.

    Only a `rejected` result, which is recorded by the executor as a proven
    pre-execution rejection, permits another attempt. A provider timeout,
    adapter exception, or acknowledgment failure returns `ambiguous` and stops
    the sequence.
    """
    attempts = list(models)
    if not attempts:
        return ExecutionOutcome("rejected", "no failover models configured")
    last = None
    for index, model_ref in enumerate(attempts, 1):
        text = prompt_for_attempt(index, model_ref) if prompt_for_attempt else request.text
        attempt = replace(
            request,
            operation_id="%s:attempt-%d:%s" % (request.operation_id, index, model_ref),
            text=text,
        )
        if policy == COORDINATED:
            provider = lambda req, admission, model=model_ref: adapter.coordinated_provider(
                req, admission, model)
        else:
            provider = lambda req, model=model_ref: adapter.legacy_attempt(req, model)
        outcome = dispatch_once(attempt, provider, policy=policy, coordinator=coordinator)
        if on_outcome:
            on_outcome(model_ref, outcome)
        last = outcome
        if outcome.status != "rejected":
            return outcome
    return last
