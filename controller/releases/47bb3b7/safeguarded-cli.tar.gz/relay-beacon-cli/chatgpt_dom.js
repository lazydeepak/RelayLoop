// DOM-only ChatGPT conversation snapshot logic.  grabSnapshot is deliberately
// self-contained because Playwright serializes the function into the page.

export function grabSnapshot() {
  const epochMillis = (value) => {
    if (typeof value === 'number' && Number.isFinite(value)) return value < 1e12 ? value * 1000 : value;
    if (typeof value === 'string') {
      const numeric = Number(value);
      if (Number.isFinite(numeric) && value.trim()) return numeric < 1e12 ? numeric * 1000 : numeric;
      const parsed = Date.parse(value);
      if (Number.isFinite(parsed)) return parsed;
    }
    return null;
  };
  const timestamp = (node) => {
    if (!node) return null;
    const elements = [node, node.querySelector('time[datetime], [datetime], [data-timestamp], [data-created-at]')];
    let parent = node.parentElement;
    for (let i = 0; parent && i < 2; i += 1, parent = parent.parentElement) elements.push(parent);
    for (const element of elements) for (const attr of ['datetime', 'data-created-at', 'data-timestamp']) {
      const result = epochMillis(element?.getAttribute(attr));
      if (result !== null) return result;
    }
    return null;
  };
  const cleanText = (node) => {
    if (!node) return '';
    const clone = node.cloneNode(true);
    clone.querySelectorAll('button, [role="toolbar"], svg, [hidden], [aria-hidden="true"]')
      .forEach((element) => element.remove());
    clone.style.position = 'absolute'; clone.style.left = '-99999px'; clone.style.top = '0';
    document.body.appendChild(clone);
    const text = (clone.innerText || clone.textContent || '')
      .replace(/\u00a0/g, ' ').replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
    clone.remove();
    return text;
  };
  const signals = {
    stop_button: document.querySelectorAll('[data-testid="stop-button"]').length,
    aria_stop: document.querySelectorAll('button[aria-label*="Stop" i]').length,
    streaming_attr: document.querySelectorAll('[data-is-streaming="true"]').length,
    result_streaming: document.querySelectorAll('[data-result-streaming="true"]').length,
    composer_streaming: document.querySelectorAll('[data-composer-streaming="true"]').length,
  };
  const streaming = Object.values(signals).some((value) => value > 0);
  const current = Array.from(document.querySelectorAll('[data-content-search-unit-key*="assistant"]'));
  const dil = Array.from(document.querySelectorAll('[data-dil-message-id]'));
  const legacy = Array.from(document.querySelectorAll('[data-message-author-role="assistant"]'));
  const currentMode = current.length > 0;
  const candidates = currentMode ? current : (dil.length ? dil : legacy);
  const seen = new Set();
  const assistants = candidates.filter((node) => {
    if (seen.has(node)) return false;
    seen.add(node);
    if (!currentMode) return true;
    return node.querySelector('[data-conversation-role="assistant"]')?.getAttribute('data-conversation-role') === 'assistant' &&
      Boolean(node.querySelector('[data-chatgpt-selection-message-id], [data-chatgpt-search-message-ids]'));
  });
  const identity = (node) => node?.getAttribute('data-dil-message-id') || node?.getAttribute('data-message-id') ||
    node?.querySelector('[data-chatgpt-selection-message-id]')?.getAttribute('data-chatgpt-selection-message-id') ||
    node?.getAttribute('data-chatgpt-search-message-ids')?.split(/\s+/)[0] || null;
  const textNode = (node) => node.querySelector('[data-markdown-text-style="assistant-message"]') || node;
  const users = Array.from(document.querySelectorAll('[data-user-message-bubble], [data-message-author-role="user"]'));
  const userIdentity = (node) => node?.getAttribute('data-dil-message-id') || node?.getAttribute('data-message-id') ||
    node?.getAttribute('data-user-message-id') || node?.querySelector('[data-dil-message-id], [data-message-id], [data-user-message-id]')?.getAttribute('data-dil-message-id') ||
    node?.querySelector('[data-dil-message-id], [data-message-id], [data-user-message-id]')?.getAttribute('data-message-id') ||
    node?.querySelector('[data-dil-message-id], [data-message-id], [data-user-message-id]')?.getAttribute('data-user-message-id') ||
    // Current ChatGPT places the stable search ID on the user-turn ancestor,
    // not on data-user-message-bubble itself. Never derive an ID from text,
    // position, timestamp, or a content hash.
    node?.closest('[data-chatgpt-search-message-ids]')?.getAttribute('data-chatgpt-search-message-ids')?.split(/\s+/)[0] || null;
  const ids = assistants.map(identity);
  const ambiguousAssistant = ids.some((id) => !id);
  const allTurns = assistants.map((node, index) => ({ id: ids[index], text: cleanText(textNode(node)) }))
    .filter((turn) => turn.id && turn.text);
  const latest = assistants[assistants.length - 1] || null;
  const latestUser = users[users.length - 1] || null;
  const recentUserTexts = users.map(cleanText).filter(Boolean);
  const latestUserIdentifier = userIdentity(latestUser);
  return {
    selector_used: currentMode ? 'data-content-search-unit-key:data-conversation-role' :
      assistants.length && assistants[0].hasAttribute('data-dil-message-id') ? 'data-dil-message-id' :
        assistants.length ? 'data-message-author-role' : null,
    streaming,
    stream_signals: signals,
    assistant_count: assistants.length,
    ambiguous_assistant: ambiguousAssistant,
    user_count: document.querySelectorAll('[data-user-message-bubble]').length,
    legacy_user_count: document.querySelectorAll('[data-message-author-role="user"]').length,
    recent_user_texts: recentUserTexts,
    latest_user_text: recentUserTexts[recentUserTexts.length - 1] || '',
    latest_user_identifier: latestUserIdentifier,
    latest_user_identity_complete: !latestUser || Boolean(latestUserIdentifier),
    latest_message_is_assistant: !latestUser || Boolean(latest &&
      (latestUser.compareDocumentPosition(latest) & Node.DOCUMENT_POSITION_FOLLOWING)),
    user_node_count: users.length,
    all_turns: allTurns,
     user_turns: users.map((node) => ({ id: userIdentity(node), text: cleanText(node), timestamp: timestamp(node) }))
       .filter((turn) => turn.text),
    message_identifier: identity(latest),
    message_created_at: timestamp(latest),
    // Deprecated compatibility alias. Never substitute observation time.
    message_timestamp: timestamp(latest),
    text: latest ? cleanText(textNode(latest)) : '',
  };
}

// These helpers are intentionally pure so extractor and regression tests share
// the same evidence contract without launching a browser or contacting ChatGPT.
export function conversationIdFromUrl(url) {
  try {
    const parsed = new URL(url);
    const parts = parsed.pathname.split('/').filter(Boolean);
    const index = parts.lastIndexOf('c');
    return index >= 0 && index + 2 === parts.length && parts[index].toLowerCase() === 'c' && parts[index + 1]
      ? decodeURIComponent(parts[index + 1]) : null;
  } catch {
    return null;
  }
}

export function exactConversationMatch(url, expectedId) {
  return Boolean(expectedId && conversationIdFromUrl(url) === expectedId);
}

export function browserOwnershipMatches(argumentsList, expectedProfile, expectedPort = 9222) {
  if (!Array.isArray(argumentsList) || !expectedProfile) return false;
  const profileArg = `--user-data-dir=${expectedProfile}`;
  const portArg = `--remote-debugging-port=${expectedPort}`;
  return argumentsList.some((value) => value === profileArg) &&
    argumentsList.some((value) => value === portArg);
}

export function completionEvidence(previous, current) {
  if (!previous || !current || !current.text) return false;
  return previous.text === current.text &&
    previous.message_identifier === current.message_identifier &&
    previous.latest_user_identifier === current.latest_user_identifier &&
    previous.latest_user_text === current.latest_user_text &&
    current.latest_user_identity_complete === true &&
    previous.assistant_count === current.assistant_count &&
    previous.latest_message_is_assistant && current.latest_message_is_assistant &&
    !previous.streaming && !current.streaming;
}
