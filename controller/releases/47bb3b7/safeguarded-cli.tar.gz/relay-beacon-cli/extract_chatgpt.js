import { chromium } from 'playwright';
import { execFileSync } from 'child_process';
import os from 'node:os';
import path from 'path';
import { grabSnapshot, conversationIdFromUrl, exactConversationMatch, completionEvidence, browserOwnershipMatches } from './chatgpt_dom.js';
import { inspectChatGPTTabState, formatTabSummary } from './chatgpt_tab_state.js';

// ---------------------------------------------------------------------------
// ChatGPT assistant-message extractor (Playwright over CDP).
//
// The current ChatGPT DOM does NOT expose `data-message-author-role` /
// `data-message-id` on message containers any more (both return 0 elements).
// Verified live structure (Oct 2026):
//   * current assistant turn container :
//       [data-content-search-unit-key*="assistant"] with a nested
//       [data-conversation-role="assistant"] and stable
//       [data-chatgpt-selection-message-id]
//   * previous current layout : [data-dil-message-id="<uuid>"]
//   * user turn container      : [data-user-message-bubble]
//   * legacy (older layout)    : [data-message-author-role="assistant"]
//
// We prefer the current container and fall back to the legacy selector so the
// extractor keeps working if ChatGPT rolls the attribute back.
// ---------------------------------------------------------------------------

const DEFAULT_URL =
  process.env.BOT_CHATGPT_URL || '';

const TARGET_URL = process.argv[2] || DEFAULT_URL;
const REFRESH_FLAG = process.argv.includes('--refresh');
const REFRESH_IF_IDLE_FLAG = process.argv.includes('--refresh-if-idle');

function conversationId(url) {
  return conversationIdFromUrl(url);
}

function fail(reason, extra = {}) {
  console.log(JSON.stringify({
    conversation_url: TARGET_URL,
    selector_used: null,
    message_identifier: null,
    extracted_text: '',
    completion_status: 'error',
    evidence_state: 'ERROR',
    error_reason: reason,
    diagnostics: extra,
  }));
}

async function connect() {
  const profile = path.resolve(process.env.BOT_CHROME_PROFILE || path.join(os.homedir(), '.agent-relay', 'chrome-profile'));
  const verifyOwnership = async (browser) => {
    let session;
    try {
      session = await browser.newBrowserCDPSession();
      const result = await session.send('Browser.getBrowserCommandLine');
      return browserOwnershipMatches(result.arguments, profile, 9222);
    } catch {
      return false;
    } finally {
      await session?.detach().catch(() => {});
    }
  };

  let attachedBrowser;
  try {
    attachedBrowser = await chromium.connectOverCDP('http://localhost:9222/json/version');
  } catch {
    attachedBrowser = null;
  }
  if (attachedBrowser) {
    if (!await verifyOwnership(attachedBrowser)) {
      // Playwright's Browser object has no `disconnect()` method. `close()`
      // closes the CDP connection for an attached browser without treating
      // the remote Chrome process as ours.
      await attachedBrowser.close().catch(() => {});
      throw new Error('existing CDP browser ownership could not be verified');
    }
    return { browser: attachedBrowser, owned: false };
  }
  {
    // Never reuse the operator's default Chrome profile: a running normal
    // Chrome instance ignores later remote-debugging flags. Use a dedicated,
    // stable profile and open a separate app instance with explicit argv.
    const chromeArgs = [
      '-na', 'Google Chrome', '--args',
      `--user-data-dir=${profile}`,
      '--remote-debugging-port=9222',
      '--enable-automation',
      '--disable-blink-features=AutomationControlled',
    ];
    execFileSync('open', chromeArgs, { stdio: 'ignore' });

    // Chrome startup can take longer on a first launch. Retry the actual CDP
    // handshake instead of sleeping once and reporting a misleading failure.
    let lastError;
    for (let attempt = 0; attempt < 20; attempt++) {
      await new Promise((resolve) => setTimeout(resolve, 500));
      try {
        const browser = await chromium.connectOverCDP('http://127.0.0.1:9222');
        if (!await verifyOwnership(browser)) {
          await browser.close().catch(() => {});
          throw new Error('launched CDP browser ownership could not be verified');
        }
        return { browser, owned: true };
      } catch (error) {
        lastError = error;
      }
    }
    throw new Error(`Chrome did not expose CDP on 127.0.0.1:9222 after launch: ${lastError?.message || 'connection failed'}`);
  }
}

async function pageReadiness(page, expectedConversationId) {
  const identityOk = exactConversationMatch(page.url(), expectedConversationId);
  const pageState = await page.evaluate(() => {
    const body = (document.body?.innerText || '').toLowerCase();
    const errorText = ['conversation not found', 'something went wrong', 'log in to continue']
      .some((text) => body.includes(text));
    return {
      dom_ready: document.readyState === 'complete' || document.readyState === 'interactive',
      has_main: Boolean(document.querySelector('main')),
      has_composer: Boolean(document.querySelector('textarea, [contenteditable="true"]')),
      error_text: errorText,
    };
  });
  return { ...pageState, identity_ok: identityOk };
}

// Runs inside the page. Returns one structured snapshot of the conversation.
(async () => {
  let browser;
  let browserOwned = false;
  try {
    const connection = await connect();
    browser = connection.browser;
    browserOwned = connection.owned;
  } catch (e) {
    fail('CDP connection failed: ' + e.message);
    return;
  }

  const convId = conversationId(TARGET_URL);

  // Locate the existing tab for this exact conversation so we never navigate
  // (or hijack) an unrelated page.
  let page = null;
  for (const ctx of browser.contexts()) {
    for (const p of ctx.pages()) {
      try {
        if (convId && exactConversationMatch(p.url(), convId)) page = p;
      } catch {}
    }
  }

  let openedNew = false;
  try {
    if (!page) {
      const ctx = browser.contexts()[0] || (await browser.newContext());
      page = await ctx.newPage();
      await page.goto(TARGET_URL, { waitUntil: 'domcontentloaded', timeout: 45000 });
      openedNew = true;
    } else if (REFRESH_FLAG) {
      console.error('REFRESH: reloading conversation page for ' + convId);
      await page.reload({ waitUntil: 'domcontentloaded', timeout: 45000 });
      await new Promise(r => setTimeout(r, 3500));
    }

    let readiness = await pageReadiness(page, convId);

    // Wait for message containers to render (hydration), up to ~20s.
    const stateBeforeHydration = await inspectChatGPTTabState(page);
    console.error(`[ChatGPT Tab State before hydration wait] ${formatTabSummary(stateBeforeHydration)}`);
    const deadline = Date.now() + 20000;
    let rendered = false;
    while (Date.now() < deadline) {
      const counts = await page.evaluate(() => ({
        current: document.querySelectorAll('[data-content-search-unit-key*="assistant"]').length,
        dil: document.querySelectorAll('[data-dil-message-id]').length,
        legacy: document.querySelectorAll('[data-message-author-role="assistant"]').length,
      }));
      if (counts.current > 0 || counts.dil > 0 || counts.legacy > 0) { rendered = true; break; }
      await page.waitForTimeout(500);
    }
    if (!rendered) {
      const stateAfterHydration = await inspectChatGPTTabState(page);
      console.error(`[ChatGPT Tab State hydration timeout] ${formatTabSummary(stateAfterHydration)}`);
    }

    // Stability polling: a completed turn yields identical text on consecutive
    // reads and shows no stop/streaming signal. This refuses streaming answers.
    if (REFRESH_IF_IDLE_FLAG && !openedNew) {
      // Check twice immediately before reloading. A current stop/streaming
      // signal, changing text, or changing message ID means do not refresh.
      const before = await page.evaluate(grabSnapshot);
      await page.waitForTimeout(700);
      const confirm = await page.evaluate(grabSnapshot);
      const stableIdle = before.text && before.text === confirm.text &&
        before.message_identifier === confirm.message_identifier &&
        before.latest_user_text === confirm.latest_user_text &&
        before.latest_message_is_assistant && confirm.latest_message_is_assistant &&
        !before.streaming && !confirm.streaming;
      if (stableIdle) {
        console.error('REFRESH: stable idle conversation; reloading ' + convId);
        await page.reload({ waitUntil: 'domcontentloaded', timeout: 45000 });
        await new Promise(r => setTimeout(r, 3500));
        readiness = await pageReadiness(page, convId);
      } else {
        console.error('REFRESH: skipped because conversation is streaming, changing, or has no completed content');
      }
    }
    const stateBeforePolling = await inspectChatGPTTabState(page);
    console.error(`[ChatGPT Tab State before stability polling] ${formatTabSummary(stateBeforePolling)}`);
    const MAX_POLLS = 12;
    const POLL_MS = 700;
    let previousSnapshot = null;
    let stable = 0;
    let snap = null;

    for (let i = 0; i < MAX_POLLS; i++) {
      snap = await page.evaluate(grabSnapshot);
      if (completionEvidence(previousSnapshot, snap)) stable++;
      else stable = 0;
      if (stable >= 1 && !snap.streaming) break;
      previousSnapshot = snap;
      await page.waitForTimeout(POLL_MS);
    }

    readiness = await pageReadiness(page, convId);
    if (!readiness.identity_ok) {
      fail('conversation identity changed during extraction', { page_url: page.url() });
      return;
    }

    // Prefer the message's server timestamp when the signed-in conversation
    // endpoint is available. Preserve the DOM timestamp if the endpoint is
    // inaccessible or cannot match the rendered message identity.
    if (process.argv.includes('--with-timestamps') && snap.message_identifier) {
      const domTimestamp = snap.message_created_at;
      const serverTimestamp = await page.evaluate(async ({ id, messageId }) => {
        try {
          const response = await fetch(`/backend-api/conversation/${id}`, {
            credentials: 'include',
            headers: { accept: 'application/json' },
          });
          if (!response.ok) return null;
          const data = await response.json();
          const messages = Object.values(data.mapping || {})
            .map((item) => item && item.message)
            .filter((message) => message && message.id === messageId);
          if (!messages.length) return null;
          const value = messages[messages.length - 1].create_time;
          if (typeof value === 'number' && Number.isFinite(value)) {
            return value < 1e12 ? value * 1000 : value;
          }
          if (typeof value === 'string') {
            const numeric = Number(value);
            if (Number.isFinite(numeric)) return numeric < 1e12 ? numeric * 1000 : numeric;
            const parsed = Date.parse(value);
            if (Number.isFinite(parsed)) return parsed;
          }
        } catch {}
        return null;
      }, { id: convId, messageId: snap.message_identifier });
      // A provider/DOM timestamp is preferred. Missing creation time remains
      // unknown; observation time is emitted separately below.
      snap.message_created_at = serverTimestamp ?? domTimestamp ?? null;
      snap.message_timestamp = snap.message_created_at;
    }

    const currentTabState = await inspectChatGPTTabState(page).catch(() => null);
    const observedAt = new Date().toISOString();
    const emptyVerified = readiness.dom_ready && readiness.has_main && readiness.has_composer &&
      !readiness.error_text && readiness.identity_ok && snap.assistant_count === 0 && snap.user_node_count === 0;
    const evidenceState = snap.ambiguous_assistant ? 'AMBIGUOUS' :
      (snap.streaming || (snap.text && stable < 1)) ? 'WORKING' :
      (snap.text && stable >= 1 ? 'COMPLETED_OBSERVED' :
      (emptyVerified ? 'EMPTY_VERIFIED' : 'UNKNOWN'));
    const diagnostics = {
      selector_used: snap ? snap.selector_used : null,
      assistant_turn_count: snap ? snap.assistant_count : 0,
      ambiguous_assistant: snap ? snap.ambiguous_assistant : false,
      user_turn_count: snap ? snap.user_count : 0,
      user_node_count: snap ? snap.user_node_count : 0,
      legacy_user_count: snap ? snap.legacy_user_count : 0,
      stream_signals: snap ? snap.stream_signals : null,
      stable_polls: stable,
      text_length: snap && snap.text ? snap.text.length : 0,
      opened_new_tab: openedNew,
      rendered,
      tab_state: currentTabState,
    };

    // every payload below carries recent_user_texts for delivery evidence

    if (!snap || snap.assistant_count === 0) {
      console.log(JSON.stringify({
        conversation_url: page.url(),
        selector_used: snap ? snap.selector_used : null,
        message_identifier: null,
        message_created_at: null,
        message_timestamp: null,
        observed_at: observedAt,
        evidence_state: emptyVerified ? 'EMPTY_VERIFIED' : 'UNKNOWN',
        extracted_text: '',
        completion_status: 'no_completed_assistant',
        error_reason: 'No assistant message container found (thread empty or not hydrated)',
        recent_user_texts: [],
        all_turns: [],
        user_turns: [],
        diagnostics,
      }));
    } else if (snap.ambiguous_assistant) {
      console.log(JSON.stringify({
        conversation_url: page.url(),
        selector_used: snap.selector_used,
        message_identifier: null,
        message_created_at: null,
        message_timestamp: null,
        observed_at: observedAt,
        evidence_state: 'AMBIGUOUS',
        extracted_text: '',
        completion_status: 'no_completed_assistant',
        error_reason: 'Assistant message identity is missing or ambiguous',
        recent_user_texts: [],
        all_turns: [],
        user_turns: [],
        diagnostics,
      }));
    } else if (!snap.text || snap.text.length < 1) {
      // Containers existed but every candidate yielded no text.
      console.log(JSON.stringify({
        conversation_url: page.url(),
        selector_used: snap.selector_used,
        message_identifier: null,
        message_created_at: null,
        message_timestamp: null,
        observed_at: observedAt,
        evidence_state: 'UNKNOWN',
        extracted_text: '',
        completion_status: 'no_completed_assistant',
        error_reason: 'Assistant containers present but rendered text was empty (blank/stub turn)',
        recent_user_texts: [],
        all_turns: [],
        user_turns: [],
        diagnostics,
      }));
    } else if (snap.streaming || stable < 1) {
      console.log(JSON.stringify({
        conversation_url: page.url(),
        selector_used: snap.selector_used,
        message_identifier: snap.message_identifier,
         message_created_at: snap.message_created_at || null,
         message_timestamp: snap.message_created_at || null,
         observed_at: observedAt,
         evidence_state: evidenceState,
        extracted_text: '',
        completion_status: 'streaming',
        error_reason: snap.streaming
          ? 'Assistant response still streaming (stop signal present)'
          : 'Assistant response text not stable across reads (likely streaming)',
        recent_user_texts: [],
        all_turns: [],
        diagnostics,
      }));
    } else {
      console.log(JSON.stringify({
        conversation_url: page.url(),
        selector_used: snap.selector_used,
        message_identifier: snap.message_identifier,
         message_created_at: snap.message_created_at || null,
         message_timestamp: snap.message_created_at || null,
         observed_at: observedAt,
         evidence_state: evidenceState,
        extracted_text: snap.text,
        completion_status: 'completed',
        error_reason: null,
        recent_user_texts: snap.recent_user_texts || [],
        all_turns: snap.all_turns || [],
        user_turns: snap.user_turns || [],
        diagnostics,
      }));
    }
  } catch (e) {
    fail('Extraction failed: ' + e.message, { opened_new_tab: openedNew });
  } finally {
    if (browser) {
      if (browserOwned) await browser.close().catch(() => {});
      else await browser.close().catch(() => {});
    }
  }
})();
