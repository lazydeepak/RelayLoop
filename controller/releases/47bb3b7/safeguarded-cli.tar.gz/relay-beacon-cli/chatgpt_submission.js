import { createHash } from 'node:crypto';

export const SUBMISSION_PHASES = Object.freeze({
  PREPARING: 'preparing',
  COMPOSER_READY: 'composer_ready',
  SUBMIT_BOUNDARY_ENTERED: 'submit_boundary_entered',
  OBSERVING: 'observing',
  CONFIRMED: 'confirmed',
  UNCERTAIN: 'uncertain',
  FAILED_BEFORE_SUBMIT: 'failed_before_submit',
});

export function payloadEvidence(text) {
  const value = Buffer.from(text || '', 'utf8');
  return {
    payload_sha256: createHash('sha256').update(value).digest('hex'),
    payload_length: value.length,
  };
}

export function destinationEvidence({ conversation_id, expected_conversation_id, expected_text, before_ids, observed, observed_at }) {
  if (!conversation_id || !Array.isArray(before_ids) || !Array.isArray(observed)) {
    return { confirmed: false, reason: 'destination boundary is incomplete' };
  }
  if (expected_conversation_id && conversation_id !== expected_conversation_id) {
    return { confirmed: false, reason: 'destination conversation identity changed' };
  }
  if (observed.some((item) => !item || item.conversation_id !== conversation_id)) {
    return { confirmed: false, reason: 'destination conversation identity changed' };
  }
  if (observed.some((item) => !item.id || item.ambiguous_id)) {
    return { confirmed: false, reason: 'destination user-message identity is missing or ambiguous' };
  }
  const observedIds = observed.map((item) => item.id);
  if (new Set(observedIds).size !== observedIds.length) {
    return { confirmed: false, reason: 'destination user-message identity is duplicated or ambiguous' };
  }
  const expected = payloadEvidence(expected_text);
  const candidates = observed.filter((item) => {
    if (before_ids.includes(item.id)) return false;
    const actual = payloadEvidence(item.text);
    return item.text === expected_text &&
      actual.payload_sha256 === expected.payload_sha256 &&
      actual.payload_length === expected.payload_length;
  });
  if (candidates.length !== 1) {
    return {
      confirmed: false,
      reason: candidates.length ? 'destination payload match is not unique' : 'exact post-submit payload not observed',
      candidate_count: candidates.length,
      observed_ids: observedIds,
    };
  }
  return {
    confirmed: true,
    conversation_id,
    destination_message_id: candidates[0].id,
    beyond_watermark: true,
    payload_sha256: expected.payload_sha256,
    payload_length: expected.payload_length,
    observed_at,
    provenance: 'chatgpt_dom.user_message_bubble',
  };
}

export function redactDiagnostic(value) {
  return String(value || '')
    .replace(/(authorization\s*[:=]\s*bearer\s+)[^\s,;]+/gi, '$1[redacted]')
    .replace(/(cookie\s*[:=]\s*)[^\n]+/gi, '$1[redacted]')
    .replace(/\bsk-[A-Za-z0-9_-]{12,}\b/g, '[redacted]')
    .slice(0, 1000);
}
