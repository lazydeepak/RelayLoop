"""Pure model-attempt routing for the existing OpenCode failover loop."""

from dataclasses import dataclass
from typing import Iterable, Mapping


@dataclass(frozen=True)
class RoutingDecision:
    """One deterministic model attempt in the current failover schedule."""

    model_ref: str
    model_index: int
    pass_number: int
    candidate_number: int
    total_candidates: int


def route_model_attempts(
    models: Iterable[Mapping[str, object]],
    max_rounds: int,
    start_index: int = 0,
) -> tuple[RoutingDecision, ...]:
    """Return the existing approved-model attempt order without side effects."""
    model_refs = tuple(str(model["model_ref"]) for model in models)
    if not model_refs or max_rounds <= 0:
        return ()

    first = start_index % len(model_refs)
    decisions: list[RoutingDecision] = []
    for pass_number in range(1, max_rounds + 1):
        for offset in range(len(model_refs)):
            index = (first + offset) % len(model_refs)
            decisions.append(RoutingDecision(
                model_ref=model_refs[index],
                model_index=index,
                pass_number=pass_number,
                candidate_number=offset + 1,
                total_candidates=len(model_refs),
            ))
        first = (first + 1) % len(model_refs)
    return tuple(decisions)
