"""Synchronous Python client for the standalone delivery authority.

This module is the Python-side protocol boundary for durable relay mode.
Planner browser operations are requested through this client; the relay never
opens the Planner browser boundary directly in that mode.
"""
import json
import os
import socket
import uuid


PROTOCOL_VERSION = 1
SCHEMA_VERSION = 6
MAX_FRAME_BYTES = 64 * 1024


class AuthorityClientError(RuntimeError):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


class AuthorityTimeout(AuthorityClientError):
    def __init__(self, message="authority request timed out; outcome is not inferred"):
        super().__init__("timeout", message)


class AuthorityTransport:
    """Injectable byte transport used by tests and platform adapters."""

    def send(self, payload):
        raise NotImplementedError

    def receive(self):
        raise NotImplementedError

    def close(self):
        pass


class UnixSocketTransport(AuthorityTransport):
    def __init__(self, endpoint, timeout):
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.settimeout(timeout)
        try:
            self.sock.connect(endpoint)
        except OSError as exc:
            self.sock.close()
            raise AuthorityClientError("unavailable", str(exc)) from exc

    def send(self, payload):
        try:
            self.sock.sendall(payload)
        except OSError as exc:
            raise AuthorityClientError("unavailable", str(exc)) from exc

    def receive(self):
        chunks = []
        total = 0
        while True:
            try:
                chunk = self.sock.recv(4096)
            except socket.timeout as exc:
                raise AuthorityTimeout() from exc
            except OSError as exc:
                raise AuthorityClientError("disconnected", str(exc)) from exc
            if not chunk:
                raise AuthorityClientError("disconnected", "authority connection closed")
            total += len(chunk)
            if total > MAX_FRAME_BYTES:
                raise AuthorityClientError("frame_too_large", "authority response is too large")
            chunks.append(chunk)
            if b"\n" in chunk:
                raw = b"".join(chunks).split(b"\n", 1)[0]
                if len(raw) > MAX_FRAME_BYTES:
                    raise AuthorityClientError("frame_too_large", "authority response is too large")
                return raw

    def close(self):
        try:
            self.sock.close()
        except OSError:
            pass


class WindowsNamedPipeTransport(AuthorityTransport):
    """Named-pipe seam; a native adapter can be supplied without changing the protocol."""
    def __init__(self, endpoint, _timeout):
        raise AuthorityClientError(
            "unavailable",
            "Windows named-pipe transport requires the approved native adapter",
        )


def default_transport(endpoint, timeout):
    if os.name == "nt" or str(endpoint).startswith("\\\\.\\pipe\\"):
        return WindowsNamedPipeTransport(endpoint, timeout)
    return UnixSocketTransport(endpoint, timeout)


class DeliveryAuthorityClient:
    def __init__(self, endpoint, auth_token, timeout=5.0, transport_factory=None):
        if not isinstance(endpoint, str) or not endpoint:
            raise ValueError("authority endpoint is required")
        if not isinstance(auth_token, str) or not auth_token:
            raise ValueError("authority auth token is required")
        self.endpoint = endpoint
        self.auth_token = auth_token
        self.timeout = timeout
        self.transport_factory = transport_factory or default_transport
        self._closed = False
        self._transport = None

    def close(self):
        """Close client resources without releasing leases or reconciling work."""
        if self._closed:
            return
        self._closed = True
        transport = self._transport
        self._transport = None
        if transport is not None:
            try:
                transport.close()
            except Exception:
                pass

    def call(self, operation, fields=None, request_id=None):
        if self._closed:
            raise AuthorityClientError("closed", "authority client is closed")
        request = {
            "id": request_id or str(uuid.uuid4()),
            "protocol_version": PROTOCOL_VERSION,
            "schema_version": SCHEMA_VERSION,
            "auth_token": self.auth_token,
            "operation": operation,
        }
        if fields:
            request.update(fields)
        try:
            raw = (json.dumps(request, separators=(",", ":")) + "\n").encode("utf-8")
        except (TypeError, ValueError) as exc:
            raise AuthorityClientError("malformed_request", str(exc)) from exc
        if len(raw) > MAX_FRAME_BYTES:
            raise AuthorityClientError("frame_too_large", "authority request is too large")

        transport = self.transport_factory(self.endpoint, self.timeout)
        self._transport = transport
        try:
            transport.send(raw)
            response = json.loads(transport.receive().decode("utf-8"))
        except AuthorityClientError:
            raise
        except (UnicodeDecodeError, json.JSONDecodeError, TypeError, ValueError) as exc:
            raise AuthorityClientError("malformed_response", str(exc)) from exc
        finally:
            try:
                transport.close()
            finally:
                if self._transport is transport:
                    self._transport = None

        if not isinstance(response, dict) or response.get("id") != request["id"]:
            raise AuthorityClientError("protocol_error", "authority response ID did not match request")
        if (response.get("protocol_version") != PROTOCOL_VERSION
                or response.get("schema_version") != SCHEMA_VERSION):
            raise AuthorityClientError("version_mismatch", "authority response version is unsupported")
        if not response.get("ok"):
            error = response.get("error") or {}
            raise AuthorityClientError(error.get("code", "authority_error"), error.get("message", "authority request failed"))
        result = response.get("result")
        return result if isinstance(result, dict) else {}

    def planner_observe(self, credentials, planner_url, conversation_id, source_policy, refresh=False):
        return self.call("planner_observe", {"credentials": credentials, "planner_url": planner_url,
            "chatgpt_conversation_id": conversation_id, "source_policy": source_policy, "refresh": bool(refresh)})

    def planner_watermark(self, credentials, planner_url, conversation_id):
        return self.call("planner_watermark", {"credentials": credentials, "planner_url": planner_url,
            "chatgpt_conversation_id": conversation_id})

    def planner_send(self, credentials, planner_url, conversation_id, payload):
        return self.call("planner_send", {"credentials": credentials, "planner_url": planner_url,
            "chatgpt_conversation_id": conversation_id, "payload": payload})

    def planner_verify(self, credentials, planner_url, conversation_id, payload, source_id, watermark):
        return self.call("planner_verify", {"credentials": credentials, "planner_url": planner_url,
            "chatgpt_conversation_id": conversation_id, "payload": payload,
            "source_id": source_id, "watermark": watermark})


def process_identity(pid=None):
    """Return the same normalized macOS/Linux identity used by the authority."""
    pid = int(pid or os.getpid())
    try:
        import subprocess
        value = subprocess.check_output(
            ["ps", "-p", str(pid), "-o", "lstart="],
            text=True,
            stderr=subprocess.DEVNULL,
            timeout=2,
        ).strip()
    except (OSError, subprocess.SubprocessError):
        value = ""
    if not value:
        raise AuthorityClientError("identity_unavailable", "process start identity is unavailable")
    return {"pid": pid, "start_time": value}


def owner_credentials(pair_id, host_id, execution_epoch, owner_token, pid=None):
    return {
        "pair_id": pair_id,
        "host_id": host_id,
        "execution_epoch": int(execution_epoch),
        "owner_token": owner_token,
        "process": process_identity(pid),
    }
