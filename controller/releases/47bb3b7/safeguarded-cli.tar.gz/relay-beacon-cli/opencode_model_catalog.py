"""Read-only model discovery from the OpenCode executable.

OpenCode owns provider credentials and the executable model list.  The relay only
keeps the non-secret fields needed for selection and budget safety.
"""
import json
import os
import re
import subprocess


_REF = re.compile(r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.:/@~+-]+$")
_LOCAL_PROVIDERS = frozenset({"ollama", "lmstudio", "llamacpp", "local"})


def _cost_is_zero(cost):
    if not isinstance(cost, list) or not cost:
        return False
    for item in cost:
        if not isinstance(item, dict):
            return False
        cache = item.get("cache") if isinstance(item.get("cache"), dict) else {}
        for value in (item.get("input"), item.get("output"), cache.get("read"), cache.get("write")):
            if not isinstance(value, (int, float)) or value != 0:
                return False
    return True


def classify_model(metadata):
    """Classify only from OpenCode provider metadata, never from the name."""
    provider = str(metadata.get("providerID") or "").lower()
    settings = metadata.get("settings") if isinstance(metadata.get("settings"), dict) else {}
    base_url = str(settings.get("baseURL") or "").lower()
    local = provider in _LOCAL_PROVIDERS or any(host in base_url for host in (
        "localhost", "127.0.0.1", "::1"))
    if local:
        return "local"
    if _cost_is_zero(metadata.get("cost")):
        return "free"
    cost = metadata.get("cost")
    if isinstance(cost, list) and cost:
        return "paid" if any(isinstance(item, dict) and any(
            isinstance(item.get(key), (int, float)) and item.get(key) > 0
            for key in ("input", "output")) for item in cost) else "unknown"
    return "unknown"


def _normalize(metadata):
    ref = metadata.get("modelID") or metadata.get("id")
    provider = metadata.get("providerID")
    if not isinstance(ref, str) or not _REF.fullmatch(ref):
        if not isinstance(provider, str) or not isinstance(metadata.get("id"), str):
            return None
        ref = f"{provider}/{metadata['id']}"
    kind = classify_model(metadata)
    return {
        "model_ref": ref,
        "name": str(metadata.get("name") or ref.split("/", 1)[-1]).strip(),
        "provider_id": str(provider or ref.split("/", 1)[0]),
        "availability": kind,
        "free": kind == "free",
        "local": kind == "local",
        "cost": metadata.get("cost") if isinstance(metadata.get("cost"), list) else None,
        "source": "opencode",
    }


def read_catalog(opencode_bin=None, timeout=20):
    """Return the current OpenCode catalog, with a safe bare-ref fallback."""
    binary = opencode_bin or os.environ.get("BOT_OPENCODE_BIN") or "opencode"
    result = subprocess.run([binary, "api", "get", "/api/model"],
                            capture_output=True, text=True, timeout=timeout)
    if result.returncode == 0:
        try:
            payload = json.loads(result.stdout)
            data = payload.get("data", payload)
            if isinstance(data, list):
                rows = [item for item in (_normalize(x) for x in data if isinstance(x, dict)) if item]
                if rows:
                    return rows
        except (ValueError, TypeError):
            pass

    # Older OpenCode versions expose only `models`.  This is discovery, not
    # pricing evidence: all fallback rows remain unknown-cost.
    result = subprocess.run([binary, "models"], capture_output=True, text=True, timeout=timeout)
    if result.returncode != 0:
        raise RuntimeError((result.stderr or result.stdout or "OpenCode model discovery failed").strip()[:300])
    rows = []
    for ref in (line.strip() for line in result.stdout.splitlines()):
        if _REF.fullmatch(ref):
            provider = ref.split("/", 1)[0]
            kind = "local" if provider.lower() in _LOCAL_PROVIDERS else "unknown"
            rows.append({"model_ref": ref, "name": ref.split("/", 1)[-1],
                         "provider_id": provider, "availability": kind,
                         "free": False, "local": kind == "local", "cost": None,
                         "source": "opencode"})
    return rows
