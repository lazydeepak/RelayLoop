"""Machine-verifiable whole-pair coordinated-dispatch readiness gate.

Family coverage is necessary but not sufficient. The authoritative coordinator,
execution-boundary fencing, mixed-version safety, and isolated end-to-end
acceptance are deliberately separate release prerequisites. They remain false
until an independent deployment-readiness review establishes them.
"""

from activation_contract import activation_report


REQUIRED_FAMILIES = frozenset({
    "planner_to_worker_opencode",
    "worker_to_planner_chatgpt",
    "manual_dispatch",
    "worker_continuation",
    "model_failover",
})

# These families now have executor seams or fail-closed coordinated handling.
# The gate nevertheless remains closed until the independent system-level
# prerequisites below are established.
VERIFIED_FAMILIES = frozenset({
    "worker_to_planner_chatgpt",
    "planner_to_worker_opencode",
    "manual_dispatch",
    "worker_continuation",
    "model_failover",
})

READINESS_PREREQUISITES = {
    "authoritative_coordinator": False,
    "execution_boundary_fencing": False,
    "mixed_version_safety": False,
    "isolated_end_to_end_acceptance": False,
}


def readiness_report():
    """Return an auditable readiness result without enabling activation."""
    missing_families = sorted(REQUIRED_FAMILIES - VERIFIED_FAMILIES)
    missing_prerequisites = sorted(
        name for name, satisfied in READINESS_PREREQUISITES.items() if not satisfied
    )
    return {
        "ready": not missing_families and not missing_prerequisites,
        "verified_families": sorted(VERIFIED_FAMILIES),
        "missing_families": missing_families,
        "prerequisites": dict(READINESS_PREREQUISITES),
        "missing_prerequisites": missing_prerequisites,
        "activation_contract": activation_report(),
    }


def coordinated_dispatch_ready() -> bool:
    """Return true only after coverage and all independent gates are satisfied."""
    return readiness_report()["ready"]
