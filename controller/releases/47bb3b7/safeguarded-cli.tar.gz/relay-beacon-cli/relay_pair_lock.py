"""OS-backed single-owner lock for the legacy terminal relay.

The lock is deliberately separate from pairs.json: process death releases it
automatically, so a stale PID or stale JSON status cannot authorize a second
relay. It is only acquired by the running relay, never by inspection code.
"""
import os


class PairLock:
    def __init__(self, handle, path):
        self.handle = handle
        self.path = path

    def release(self):
        try:
            if os.name == "nt":
                import msvcrt
                self.handle.seek(0)
                msvcrt.locking(self.handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.handle.fileno(), fcntl.LOCK_UN)
        except (OSError, ImportError):
            pass
        try:
            self.handle.close()
        except OSError:
            pass


def acquire_pair_lock(pair_id, directory=None):
    directory = directory or os.environ.get("BOT_RUN_DIR") or os.path.join(
        os.path.dirname(os.path.abspath(__file__)), ".relay_runs")
    os.makedirs(directory, exist_ok=True)
    path = os.path.join(directory, "%s.owner.lock" % pair_id)
    handle = open(path, "a+b")
    try:
        if os.name == "nt":
            import msvcrt
            handle.seek(0)
            if os.path.getsize(path) == 0:
                handle.write(b"0")
                handle.flush()
            handle.seek(0)
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except (OSError, ImportError):
        try:
            handle.close()
        except OSError:
            pass
        return None
    return PairLock(handle, path)
