"""Durable, operation-scoped continuation authorization."""
import hashlib
import json
import os
import secrets
import tempfile
import time
from contextlib import contextmanager
from dataclasses import asdict, dataclass
from pathlib import Path

import fcntl

TOKEN_EXPIRY_SECONDS = 3600


class TokenValidationError(Exception):
    pass


@dataclass
class TokenRecord:
    token_hash: str
    session_id: str
    worker_turn_id: str
    pair_id: str
    expires_at: float
    created_at: float
    operator_id: str
    purpose: str
    status: str = "active"
    consumed_at: float = None
    admission_id: str = None
    revoked_at: float = None

    def matches(self, session_id, worker_turn_id, pair_id, operator_id, purpose):
        return (self.session_id == session_id
                and self.worker_turn_id == worker_turn_id
                and self.pair_id == pair_id
                and self.operator_id == operator_id
                and self.purpose == purpose)


class TokenRegistry:
    """JSON-backed registry with cross-process atomic state transitions."""

    def __init__(self, registry_file=None):
        configured = registry_file or os.environ.get("BOT_TOKEN_REGISTRY_FILE")
        self.registry_file = Path(configured or
                                  (Path.home() / ".config" / "bot" /
                                   "continuation_tokens.json"))
        self.lock_file = self.registry_file.with_name(self.registry_file.name + ".lock")
        self.registry_file.parent.mkdir(parents=True, exist_ok=True)

    @contextmanager
    def _lock(self, exclusive):
        self.lock_file.parent.mkdir(parents=True, exist_ok=True)
        with open(self.lock_file, "a+", encoding="utf-8") as handle:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH)
            try:
                yield
            finally:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)

    def _load_unlocked(self):
        try:
            with open(self.registry_file, encoding="utf-8") as handle:
                raw = json.load(handle)
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            return {}
        try:
            return {key: TokenRecord(**value) for key, value in raw.items()}
        except (AttributeError, TypeError, ValueError):
            # A malformed or legacy registry is not authorization evidence.
            # Fail closed rather than allowing an untrusted file to become a
            # denial-of-service or an exception-based admission path.
            return {}

    def _save_unlocked(self, records):
        fd, temporary = tempfile.mkstemp(prefix=".tokens-", dir=str(self.registry_file.parent))
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump({key: asdict(value) for key, value in records.items()},
                          handle, indent=2)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, self.registry_file)
        except OSError as exc:
            try:
                os.unlink(temporary)
            except OSError:
                pass
            raise TokenValidationError("failed to persist token registry: %s" % exc)

    @staticmethod
    def _hash(token):
        return hashlib.sha256((token or "").encode()).hexdigest()

    def create_token(self, session_id, worker_turn_id, pair_id, operator_id,
                     purpose, expiry_seconds=TOKEN_EXPIRY_SECONDS):
        token = secrets.token_urlsafe(32)
        record = TokenRecord(
            token_hash=self._hash(token), session_id=session_id,
            worker_turn_id=worker_turn_id, pair_id=pair_id,
            expires_at=time.time() + expiry_seconds, created_at=time.time(),
            operator_id=operator_id, purpose=purpose)
        with self._lock(True):
            records = self._load_unlocked()
            records[record.token_hash] = record
            self._save_unlocked(records)
        return token

    def validate_token(self, session_id, worker_turn_id, pair_id, operator_id,
                       purpose, token):
        with self._lock(False):
            record = self._load_unlocked().get(self._hash(token))
            return bool(record and record.status == "active"
                        and time.time() < record.expires_at
                        and record.matches(session_id, worker_turn_id, pair_id,
                                           operator_id, purpose))

    def consume_token(self, session_id, worker_turn_id, pair_id, operator_id,
                      purpose, token, admission_id):
        """Atomically admit exactly one use, or reject it."""
        with self._lock(True):
            records = self._load_unlocked()
            key = self._hash(token)
            record = records.get(key)
            if (record is None or record.status != "active"
                    or time.time() >= record.expires_at
                    or not record.matches(session_id, worker_turn_id, pair_id,
                                          operator_id, purpose)):
                return False
            record.status = "consumed"
            record.consumed_at = time.time()
            record.admission_id = admission_id
            self._save_unlocked(records)
            return True

    def revoke_token(self, session_id, worker_turn_id, pair_id, operator_id,
                     purpose, token):
        with self._lock(True):
            records = self._load_unlocked()
            record = records.get(self._hash(token))
            if (record is None or record.status != "active"
                    or not record.matches(session_id, worker_turn_id, pair_id,
                                          operator_id, purpose)):
                return False
            record.status = "revoked"
            record.revoked_at = time.time()
            self._save_unlocked(records)
            return True

    def cleanup_expired_tokens(self):
        removed = 0
        with self._lock(True):
            records = self._load_unlocked()
            for key in list(records):
                if records[key].status == "active" and time.time() >= records[key].expires_at:
                    records[key].status = "expired"
                    removed += 1
            if removed:
                self._save_unlocked(records)
        return removed


# Backward-compatible handle for packaged relay builds from the previous
# authorization API. New code should use the operation-specific functions
# below; keeping this symbol exported lets an older packaged relay load the
# matching registry module during an in-place upgrade.
_token_registry = TokenRegistry()


def create_authorization_token(session_id, worker_turn_id, pair_id, operator_id,
                                purpose, expiry_seconds=TOKEN_EXPIRY_SECONDS,
                                registry=None):
    return (registry or TokenRegistry()).create_token(
        session_id, worker_turn_id, pair_id, operator_id, purpose, expiry_seconds)


def validate_authorization_token(session_id, worker_turn_id, pair_id, operator_id,
                                 purpose, token, registry=None):
    return (registry or TokenRegistry()).validate_token(
        session_id, worker_turn_id, pair_id, operator_id, purpose, token)


def consume_authorization_token(session_id, worker_turn_id, pair_id, operator_id,
                                purpose, token, admission_id, registry=None):
    return (registry or TokenRegistry()).consume_token(
        session_id, worker_turn_id, pair_id, operator_id, purpose, token,
        admission_id)


def revoke_authorization_token(session_id, worker_turn_id, pair_id, operator_id,
                               purpose, token, registry=None):
    return (registry or TokenRegistry()).revoke_token(
        session_id, worker_turn_id, pair_id, operator_id, purpose, token)
