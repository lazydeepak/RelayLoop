import { chromium } from 'playwright';
import { waitForFunctionWithDiagnostics } from './chatgpt_tab_state.js';

export const COMPOSER_SELECTOR = [
  '#prompt-textarea[aria-label="Ask ChatGPT"]',
  '[contenteditable="true"][role="textbox"][aria-label="Ask ChatGPT"]',
  'textarea[tabindex="0"][aria-label="Ask ChatGPT"]',
].join(', ');
export const SEND_SELECTOR = [
  'button[data-testid*="send" i]',
  'button[aria-label*="Send" i]',
  'button[type="submit"]',
].join(', ');
export const USER_MESSAGE_SELECTOR = '[data-message-author-role="user"], .bg-user-message';

export function normalize(text) {
  return (text || '').replace(/\s+/g, ' ').trim();
}

export function buildBootstrap(title) {
  return String(title || '').trim();
}

export function normalizeProjectName(value) {
  return String(value || '').trim().normalize('NFKC').toLocaleLowerCase();
}

export function projectPathFromUrl(value) {
  try {
    const url = new URL(value);
    if (url.protocol !== 'https:' || !['chatgpt.com', 'www.chatgpt.com'].includes(url.hostname)
      || url.username || url.password || url.search || url.hash) return null;
    const match = url.pathname.match(/^\/(g\/g-p-[^/]+)\/?$/i);
    return match ? `https://chatgpt.com/${match[1]}` : null;
  } catch {
    return null;
  }
}

export function isConversationInProject(value, projectUrl) {
  const projectPath = projectPathFromUrl(projectUrl);
  if (!projectPath) return false;
  try {
    const url = new URL(value);
    const expected = new URL(projectPath);
    return isDurableConversationUrl(value)
      && url.origin === expected.origin
      && url.pathname.startsWith(`${expected.pathname}/c/`);
  } catch {
    return false;
  }
}

export function conversationIdFromUrl(value) {
  try {
    const url = new URL(value);
    if (url.hostname !== 'chatgpt.com' && !url.hostname.endsWith('.chatgpt.com')) return null;
    const match = url.pathname.match(/\/c\/([^/?#]+)/i);
    return match ? match[1] : null;
  } catch {
    return null;
  }
}

export function isConversationUrl(value) {
  return Boolean(conversationIdFromUrl(value));
}

export function isLocalPlaceholderConversationUrl(value) {
  const id = conversationIdFromUrl(value);
  if (!id) return false;
  try {
    return decodeURIComponent(id).toLowerCase().startsWith('local-chatgpt:');
  } catch {
    return false;
  }
}

export function isDurableConversationUrl(value) {
  return isConversationUrl(value) && !isLocalPlaceholderConversationUrl(value);
}

export function isNewChatUrl(value) {
  try {
    const url = new URL(value);
    return (url.hostname === 'chatgpt.com' || url.hostname.endsWith('.chatgpt.com'))
      && url.pathname === '/';
  } catch {
    return false;
  }
}

export function isDuplicateConversation(url, knownUrls = [], knownIds = []) {
  const id = conversationIdFromUrl(url);
  return knownUrls.includes(url) || (id !== null && knownIds.includes(id));
}

async function visibleEnabled(locators) {
  const result = [];
  for (const locator of locators) {
    if (await locator.isVisible().catch(() => false)
      && await locator.isEnabled().catch(() => false)) result.push(locator);
  }
  return result;
}

/** Locate only the real composer and its own form; never a historical editor. */
export async function findVerifiedComposer(page, { requireEnabledSend = true } = {}) {
  const candidates = page.locator(COMPOSER_SELECTOR);
  const visible = [];
  for (let index = 0; index < await candidates.count(); index += 1) {
    const locator = candidates.nth(index);
    if (await locator.isVisible().catch(() => false)
      && await locator.isEnabled().catch(() => false)) visible.push(locator);
  }
  if (visible.length !== 1) {
    throw new Error(`expected exactly one enabled Ask ChatGPT composer, found ${visible.length}`);
  }
  const composer = visible[0];
  const form = composer.locator('xpath=ancestor::form[1]');
  if (await form.count() !== 1) throw new Error('verified composer is not inside exactly one form');
  const sendLocator = form.locator(SEND_SELECTOR);
  if (requireEnabledSend) {
    const send = await visibleEnabled([sendLocator]);
    if (send.length !== 1) throw new Error(`expected exactly one enabled Send control in composer form, found ${send.length}`);
    return { composer, form, send: send[0] };
  }
  return { composer, form, send: null };
}

export async function assertNewChatState(page) {
  if (!isNewChatUrl(page.url())) throw new Error(`dedicated page is not a new-chat URL: ${page.url()}`);
  const historicalMessages = page.locator(USER_MESSAGE_SELECTOR);
  if (await historicalMessages.count() !== 0) throw new Error('dedicated page already contains user messages');
  return findVerifiedComposer(page, { requireEnabledSend: false });
}

export async function openDedicatedNewChatPage(context, projectUrl) {
  const projectPath = projectPathFromUrl(projectUrl);
  if (!projectPath) throw new Error('an exact ChatGPT Project URL is required');
  const page = await context.newPage();
  await page.goto(projectPath, { waitUntil: 'domcontentloaded', timeout: 30000 });
  if (new URL(page.url()).pathname.replace(/\/$/, '') !== new URL(projectPath).pathname) {
    throw new Error(`ChatGPT navigated outside the selected Project: ${page.url()}`);
  }
  const newChat = page.getByRole('button', { name: /new chat/i }).first();
  if (!await newChat.count() || !await newChat.isVisible().catch(() => false)) {
    throw new Error('Could not find a visible New chat button within the selected ChatGPT Project.');
  }
  await newChat.click();
  await page.waitForLoadState('domcontentloaded').catch(() => {});
  const currentPath = new URL(page.url()).pathname.replace(/\/$/, '');
  if (currentPath !== new URL(projectPath).pathname) {
    throw new Error(`New chat opened outside the selected ChatGPT Project: ${page.url()}`);
  }
  const historicalMessages = page.locator(USER_MESSAGE_SELECTOR);
  if (await historicalMessages.count() !== 0) throw new Error('dedicated Project conversation already contains user messages');
  return page;
}

export async function verifySubmittedBootstrap(page, bootstrap, beforeUserMessageCount = 0) {
  const messages = await page.locator(USER_MESSAGE_SELECTOR).allTextContents();
  const normalized = messages.map(normalize);
  const exactMatches = normalized.filter((text) => text === normalize(bootstrap));
  // ChatGPT's current Project surface does not always expose message-author
  // attributes. Fall back to the exact rendered message text, never a loose
  // substring or a composer value.
  if (messages.length === 0) {
    const body = normalize(await page.locator('body').innerText());
    const exact = normalize(bootstrap);
    const occurrences = exact ? body.split(exact).length - 1 : 0;
    if (occurrences === 1) return { messageCount: 1, bootstrapVerified: true, evidence: 'exact rendered message text' };
  }
  if (messages.length !== beforeUserMessageCount + 1 || exactMatches.length !== 1) {
    throw new Error(`expected exactly one new standalone bootstrap message; before=${beforeUserMessageCount} after=${messages.length} exact=${exactMatches.length}`);
  }
  return { messageCount: messages.length, bootstrapVerified: true };
}

export async function verifyIndependentConversation(context, url, bootstrap, projectUrl) {
  const page = await context.newPage();
  try {
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 });
    if (!isConversationInProject(page.url(), projectUrl) || page.url().split('?')[0] !== url.split('?')[0]) {
      throw new Error(`conversation did not reopen at the same durable URL: ${page.url()}`);
    }
    return verifySubmittedBootstrap(page, bootstrap, 0);
  } finally {
    await page.close().catch(() => {});
  }
}

export async function createConversationOnce({ browser, title, bootstrap, projectUrl, knownUrls = [], knownIds = [] }) {
  const context = browser.contexts()[0];
  if (!context) throw new Error('no browser context available');
  const page = await openDedicatedNewChatPage(context, projectUrl);
  try {
    const beforeCount = await page.locator(USER_MESSAGE_SELECTOR).count();
    const { composer } = await findVerifiedComposer(page, { requireEnabledSend: false });
    await composer.fill(bootstrap);
    const { send } = await findVerifiedComposer(page, { requireEnabledSend: true });
    // This function has exactly one send path and never retries an uncertain result.
    await send.click();
    try {
      await page.waitForURL((url) => isConversationUrl(url.toString()), { timeout: 30000 });
    } catch (error) {
      return { status: 'unknown', reason: `conversation navigation was not confirmed: ${error.message}`, url: page.url() };
    }
    const url = page.url();
    if (!isConversationInProject(url, projectUrl)) {
      return { status: 'unknown', reason: 'ChatGPT returned a conversation outside the selected Project', url };
    }
    if (isDuplicateConversation(url, knownUrls, knownIds)) {
      return { status: 'unknown', reason: 'new conversation identity matches a known conversation', url };
    }
    const identity = conversationIdFromUrl(url);
    try {
      const verified = await verifySubmittedBootstrap(page, bootstrap, beforeCount);
      const reopened = await verifyIndependentConversation(context, url, bootstrap, projectUrl);
      return { status: 'created', url, conversation_id: identity, ...verified, independentReopenVerified: true, ...reopened };
    } catch (error) {
      return { status: 'unknown', reason: `independent conversation verification failed: ${error.message}`, url };
    }
  } finally {
    await page.close().catch(() => {});
  }
}

async function openNamedProject(context, projectName, onProjectCreationAttempt = () => {}) {
  const page = await context.newPage();
  await page.goto('https://chatgpt.com/', { waitUntil: 'domcontentloaded', timeout: 30000 });
  const showSidebar = page.getByRole('button', { name: 'Show sidebar', exact: true }).first();
  if (await showSidebar.count() && await showSidebar.isVisible().catch(() => false)) await showSidebar.click();

  const wanted = normalizeProjectName(projectName);
  const findProjects = async () => {
    let names = [];
    for (let attempt = 0; attempt < 12; attempt += 1) {
      names = await page.locator('button[aria-label^="Project actions for "]').evaluateAll((buttons, expected) =>
        buttons.map((button) => button.getAttribute('aria-label')?.replace(/^Project actions for\s*/, '') || '')
          .filter((name) => name.trim().normalize('NFKC').toLocaleLowerCase() === expected), wanted);
      if (names.length || attempt === 11) break;
      const more = page.getByRole('button', { name: 'Show more', exact: true });
      if (!await more.count()) break;
      await more.last().click();
    }
    return names;
  };
  let matching = await findProjects();
  if (matching.length > 1) throw new Error(`More than one ChatGPT Project matches "${projectName}"; resolve the duplicate names before continuing.`);
  if (!matching.length) {
    // After a project-creation click, an interruption is treated as uncertain.
    // A fresh run first rediscovers the exact name before it could create one.
    const createButtons = page.getByRole('button', { name: /^(new project|create project)$/i });
    const createCandidates = [];
    for (let index = 0; index < await createButtons.count(); index += 1) {
      const candidate = createButtons.nth(index);
      if (await candidate.isVisible().catch(() => false) && await candidate.isEnabled().catch(() => false)) createCandidates.push(candidate);
    }
    if (createCandidates.length !== 1) throw new Error(`No ChatGPT Project named "${projectName}" exists, and the UI did not expose exactly one safe Create Project action.`);
    onProjectCreationAttempt();
    await createCandidates[0].click();
    const dialog = page.getByRole('dialog');
    await dialog.waitFor({ state: 'visible', timeout: 15000 });
    const nameField = dialog.getByRole('textbox', { name: /project name|name/i });
    if (await nameField.count() !== 1) throw new Error('ChatGPT Create Project dialog did not expose exactly one project-name field.');
    await nameField.fill(projectName);
    const submit = dialog.getByRole('button', { name: /^(create|create project)$/i });
    if (await submit.count() !== 1 || !await submit.isEnabled()) throw new Error('ChatGPT Create Project dialog did not expose one enabled Create action.');
    await submit.click();
    await dialog.waitFor({ state: 'hidden', timeout: 30000 });
    matching = await findProjects();
    if (matching.length !== 1) throw new Error(`ChatGPT did not verify exactly one newly created Project named "${projectName}".`);
  }
  const actualName = matching[0];
  const openProject = page.getByRole('button', { name: `New chat in ${actualName}`, exact: true });
  if (await openProject.count() !== 1) {
    await page.close().catch(() => {});
    throw new Error(`ChatGPT did not expose one unambiguous project entry for "${actualName}".`);
  }
  await openProject.click();
  await page.getByRole('textbox', { name: `New chat in ${actualName}`, exact: true }).waitFor({ state: 'visible', timeout: 30000 });
  const match = new URL(page.url()).pathname.match(/^\/(g\/g-p-[^/]+)\/project\/?$/i);
  if (!match) {
    await page.close().catch(() => {});
    throw new Error(`ChatGPT Project navigation did not resolve to a project page: ${page.url()}`);
  }
  return { page, actualName, projectUrl: `https://chatgpt.com/${match[1]}` };
}

async function renameChatInSidebar(page, conversationId, title) {
  const link = page.locator(`a[href*="/c/${conversationId}"]`).first();
  await link.waitFor({ state: 'visible', timeout: 30000 });
  const row = link.locator('xpath=ancestor::*[@role="group"][1]');
  const actions = row.getByRole('button', { name: 'Chat actions', exact: true });
  if (await actions.count() !== 1) throw new Error('Could not identify exactly one action menu for the new Planner conversation.');
  await actions.click();
  await page.getByRole('menuitem', { name: 'Rename', exact: true }).click();
  const dialog = page.getByRole('dialog', { name: 'Rename chat' });
  await dialog.getByRole('textbox', { name: 'Chat title' }).fill(title);
  await dialog.getByRole('button', { name: 'Save', exact: true }).click();
  await waitForFunctionWithDiagnostics(page, (expected) => document.title === expected, title, { timeout: 15000 }, 'renameChatInSidebar:document.title');
}

/** Ensure the same-named Project exists, then create exactly one Planner conversation in it. */
export async function createNamedProjectConversation({ browser, projectName, title, bootstrap = buildBootstrap(title) }) {
  const context = browser.contexts()[0];
  if (!context) throw new Error('no authenticated ChatGPT browser context is available');
  let page;
  let projectCreationAttempted = false;
  let submitAttempted = false;
  let conversationUrl = null;
  let projectUrl = null;
  try {
    const opened = await openNamedProject(context, projectName, () => { projectCreationAttempted = true; });
    page = opened.page;
    projectUrl = opened.projectUrl;
    console.log(`RELAY_PLANNER_PROJECT_JSON:${JSON.stringify({ project_name: opened.actualName, project_url: projectUrl })}`);
    const duplicate = await page.locator('a[href*="/c/"]').evaluateAll((links, expected) => links.some((link) => link.innerText.trim() === expected), title);
    if (duplicate) return { status: 'duplicate_title', reason: `A conversation named "${title}" already exists in ChatGPT Project "${opened.actualName}"; refusing to create another.`, project_url: projectUrl };

    const composer = page.getByRole('textbox', { name: `New chat in ${opened.actualName}`, exact: true });
    if (await composer.count() !== 1) throw new Error('Could not identify exactly one new-chat composer in the selected ChatGPT Project.');
    await composer.fill(bootstrap);
    const form = composer.locator('xpath=ancestor::form[1]');
    const candidates = form.locator(SEND_SELECTOR);
    const sends = await visibleEnabled(Array.from({ length: await candidates.count() }, (_, index) => candidates.nth(index)));
    if (sends.length !== 1) throw new Error(`Expected exactly one enabled Send control in the project composer, found ${sends.length}.`);

    // Crossing this click boundary makes all later failures uncertain. Never
    // retry this send automatically.
    submitAttempted = true;
    await sends[0].click();
    await page.waitForURL((url) => isConversationInProject(url.toString(), projectUrl), { timeout: 45000 });
    conversationUrl = page.url();
    const conversationId = conversationIdFromUrl(conversationUrl);
    console.log(`RELAY_PLANNER_CREATED_JSON:${JSON.stringify({ project_name: opened.actualName, project_url: projectUrl, conversation_url: conversationUrl, conversation_id: conversationId })}`);
    await verifySubmittedBootstrap(page, bootstrap, 0);
    await page.getByText('Response complete', { exact: true }).waitFor({ state: 'visible', timeout: 120000 });
    await renameChatInSidebar(page, conversationId, title);

    const verificationPage = await context.newPage();
    try {
      await verificationPage.goto(conversationUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
      if (!isConversationInProject(verificationPage.url(), projectUrl)) throw new Error('The new conversation did not reopen inside the selected ChatGPT Project.');
      await verifySubmittedBootstrap(verificationPage, bootstrap, 0);
      if (await verificationPage.title() !== title) throw new Error('The renamed Planner title did not persist after reopening the conversation.');
    } finally { await verificationPage.close().catch(() => {}); }
    return { status: 'created', project_name: opened.actualName, project_url: projectUrl, conversation_url: conversationUrl,
      conversation_id: conversationId, title, title_verified: true, bootstrap_verified: true, completion_observed: true, independent_reopen_verified: true };
  } catch (error) {
    return { status: submitAttempted || projectCreationAttempted ? 'uncertain' : 'failed_before_submit', reason: error instanceof Error ? error.message : String(error),
      project_url: projectUrl, conversation_url: conversationUrl };
  } finally {
    await page?.close().catch(() => {});
  }
}

function knownValuesFromEnvironment() {
  if (!process.env.CHATGPT_KNOWN_CONVERSATION_URLS) {
    throw new Error('CHATGPT_KNOWN_CONVERSATION_URLS is required for duplicate-safe creation');
  }
  try {
    const values = JSON.parse(process.env.CHATGPT_KNOWN_CONVERSATION_URLS || '[]');
    const urls = Array.isArray(values) ? values.filter((value) => typeof value === 'string') : [];
    return { urls, ids: urls.map(conversationIdFromUrl).filter(Boolean) };
  } catch {
    return { urls: [], ids: [] };
  }
}

async function main() {
  if (process.argv[2] === '--named-project') {
    const projectName = process.argv[3];
    const title = process.argv[4];
    if (!projectName || !title) throw new Error('Project name and Planner session title are required.');
    const browser = await chromium.connectOverCDP('http://localhost:9222/json/version');
    try {
      const result = await createNamedProjectConversation({ browser, projectName, title });
      console.log(JSON.stringify(result));
      if (result.status !== 'created') process.exitCode = result.status === 'failed_before_submit' ? 1 : 2;
    } finally { await browser.close().catch(() => {}); }
    return;
  }
  const title = process.argv[2];
  if (!title) throw new Error('A conversation title is required.');
  const projectUrl = process.argv[3];
  if (!projectPathFromUrl(projectUrl)) throw new Error('An exact ChatGPT Project URL is required.');
  const bootstrap = process.argv.slice(4).join(' ') || buildBootstrap(title);
  const browser = await chromium.connectOverCDP('http://localhost:9222/json/version');
  try {
    const known = knownValuesFromEnvironment();
    const result = await createConversationOnce({
      browser,
      title,
      bootstrap,
      projectUrl,
      knownUrls: known.urls,
      knownIds: known.ids,
    });
    console.log(JSON.stringify({ title, ...result }));
    if (result.status !== 'created') process.exitCode = 2;
  } finally {
    await browser.close().catch(() => {});
  }
}

if (process.argv[1] && import.meta.url === new URL(`file://${process.argv[1]}`).href) {
  main().catch((error) => { console.error(error.message || String(error)); process.exitCode = 1; });
}
