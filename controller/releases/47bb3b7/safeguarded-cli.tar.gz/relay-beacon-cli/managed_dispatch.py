"""Node-owned durable admission for managed relay transports.

No retries, provider credentials, or coordinator activation live here. The
existing relay still owns turn-taking and destination evidence verification.
"""
import hashlib
import json
import os
from dispatch_executor import PreExecutionRejection
from urllib.parse import urlparse
from urllib.request import Request, build_opener, ProxyHandler
from urllib.error import HTTPError, URLError


class ManagedDispatch:
    def __init__(self, relay, state):
        self.relay = relay
        self.state = state
        self.token = os.environ['BOT_RELAY_START_TOKEN']
        self.origin = os.environ['BOT_RELAY_API_ORIGIN']
        parsed = urlparse(self.origin)
        if parsed.scheme != 'http' or parsed.hostname != '127.0.0.1' or not parsed.port \
                or parsed.username or parsed.password or parsed.path not in ('', '/') or parsed.query or parsed.fragment:
            raise RuntimeError('Managed admission requires the explicit loopback Node origin')
        self.opener = build_opener(ProxyHandler({}))
        self.active = None

    def call(self, action, identity, extra=None):
        payload = {**identity, **(extra or {}), 'action': action, 'pid': os.getpid()}
        request = Request(self.origin.rstrip('/') + '/api/internal/relay-dispatch',
            data=json.dumps(payload).encode(), method='POST',
            headers={'Content-Type': 'application/json', 'Authorization': 'Bearer ' + self.token})
        with self.opener.open(request, timeout=5) as response:
            result = json.load(response)
        if result.get('ok') is not True:
            raise RuntimeError('Managed dispatch admission was not confirmed')
        return result

    def startup_records(self):
        """Read durable source outcomes before selecting a startup turn."""
        try:
            result = self.call('startup', {'pair_id': self.relay.PAIR_ID,
                                           'source_id': 'startup',
                                           'direction': 'chatgpt_to_opencode',
                                           'payload_sha256': '0' * 64,
                                           'payload_length': 1})
        except URLError:
            # The parent may not have opened its admission socket yet. The
            # readiness/go handshake still prevents execution; do not invent
            # durable history when the query is unavailable.
            return []
        return result.get('operations') or []

    def identity(self, text):
        pending = self.state.get('pending')
        if not pending or not pending.get('source_id') or text != pending.get('text'):
            if not pending or not pending.get('source_id') or text != pending.get('attempt_text'):
                raise RuntimeError('Managed dispatch requires the current pending source')
        # Retry envelopes are transport metadata. The durable operation keeps
        # the original logical payload hash and length across all attempts.
        raw = (pending.get('logical_text') or pending.get('text') or text).encode('utf-8')
        identity = {'pair_id': self.relay.PAIR_ID, 'source_id': pending['source_id'],
            'direction': pending['direction'], 'payload_sha256': hashlib.sha256(raw).hexdigest(),
            'payload_length': len(raw), 'supervisor_id': pending.get('supervisor_id'),
            'attempt': int(pending.get('attempts') or 1)}
        return identity

    def send(self, provider, text):
        identity = self.identity(text)
        try:
            admitted = self.call('begin', identity)
        except HTTPError as error:
            # Preserve the durable gate's actual rejection reason in the relay
            # log. In particular, an abandoned source must stay held; it must
            # not be treated as a fresh admission or blindly replayed.
            try:
                detail = error.read(1024).decode('utf-8', errors='replace').strip()
            except Exception:
                detail = ''
            reason = f"HTTP {error.code}"
            if detail:
                reason += f": {detail}"
            pending = self.state.get('pending')
            if pending is not None:
                pending['admission_error'] = reason[:1200]
            raise RuntimeError(f"Managed dispatch admission rejected ({reason})") from error
        self.active = identity
        if admitted.get('status') == 'abandoned' and admitted.get('quarantined') is True:
            pending = self.state.get('pending')
            if pending is not None:
                pending['quarantined'] = True
            return 'abandoned source quarantined; provider invocation suppressed'
        if admitted.get('status') == 'confirmed':
            return 'previously confirmed source; no provider invocation'
        if admitted.get('created') is not True or admitted.get('status') != 'executing':
            raise RuntimeError('Managed source is unresolved; automatic resend is forbidden')
        try:
            self.require_execution()
            return provider(text)
        except PreExecutionRejection:
            try:
                self.call('pre_submit_failed', identity)
            except Exception:
                # If the durable retryable state cannot be recorded, preserve
                # ambiguity rather than risking a second provider invocation.
                try:
                    self.call('uncertain', identity)
                except Exception:
                    pass
                raise RuntimeError('pre-submit failure could not be durably recorded')
            raise
        except Exception:
            try:
                self.call('uncertain', identity)
            except Exception:
                pass  # Durable admission remains unresolved; never invoke again.
            raise

    def require_execution(self):
        if not self.active or not self.state.get('pending'):
            raise RuntimeError('No active managed provider admission')
        result = self.call('validate', self.active)
        if result.get('status') != 'executing':
            raise RuntimeError('Managed provider authority is no longer executing')

    def confirm_submission(self, text):
        """Commit a provider submit after the single send action returned.

        This is intentionally separate from destination DOM read-back.  The
        durable admission already owns the source ID and prevents a second
        provider invocation; the browser verifier is only an optional
        diagnostic after this point.
        """
        identity = self.identity(text)
        result = self.call('confirm', identity)
        if result.get('status') != 'confirmed':
            raise RuntimeError('Managed submission confirmation was not accepted')
        return result

    def install_fences(self):
        originals = {}
        # Node owns managed queue transitions together with durable admission.
        # Python must not race a new UI queue write with a stale file snapshot.
        for name in ('update_supervisor_guidance', 'clear_supervisor_guidance'):
            original = getattr(self.relay, name, None)
            if callable(original):
                originals[name] = original
                setattr(self.relay, name, lambda *args, **kwargs: None)
        for name in ('_run_opencode_provider', '_switch_opencode_session_model'):
            original = getattr(self.relay, name, None)
            if not callable(original):
                continue
            originals[name] = original

            def guarded(*args, _provider=original, **kwargs):
                self.require_execution()
                return _provider(*args, **kwargs)

            setattr(self.relay, name, guarded)

        def restore():
            for name, original in originals.items():
                setattr(self.relay, name, original)
        return restore

    def verify(self, verifier, *args, evidence_verifier='chatgpt_cdp_dom_inspection'):
        if not self.active:
            pending = self.state.get('pending') or {}
            reason = pending.get('admission_error')
            if reason:
                return self.relay.INCONCLUSIVE, f'no durable managed admission; {reason}'
            return self.relay.INCONCLUSIVE, 'no durable managed admission'
        try:
            record = self.call('status', self.active)
            if record.get('status') == 'confirmed':
                return self.relay.CONFIRMED, 'durable managed confirmation'
            if record.get('status') not in ('executing', 'ambiguous'):
                return self.relay.INCONCLUSIVE, 'durable delivery is uncertain; explicit reconciliation required'
            verdict, evidence = verifier(*args)
            if verdict == self.relay.CONFIRMED:
                if record.get('status') == 'ambiguous':
                    if not isinstance(evidence, dict) or not evidence.get('destination_message_id'):
                        return self.relay.INCONCLUSIVE, 'exact destination evidence is incomplete'
                    self.call('confirm', self.active, {
                        'evidence': {
                            'kind': 'verified_provider_receipt',
                            'reference': evidence['destination_message_id'],
                            'verifier': evidence_verifier,
                            'source_id': evidence.get('source_id') or self.active.get('source_id'),
                            'payload_sha256': evidence.get('payload_sha256'),
                            'payload_length': evidence.get('payload_length'),
                            'destination_id': evidence.get('destination_id'),
                        },
                        'acknowledgment': 'automatic_exact_destination_verification',
                    })
                else:
                    self.call('confirm', self.active)
                return verdict, evidence
            if verdict == getattr(self.relay, 'ABSENT', 'absent'):
                # A complete, repeated destination read is safe retry evidence,
                # not confirmation. The relay still enforces the two-clean-read
                # gate and three-attempt maximum before calling begin again.
                return verdict, evidence
            self.call('uncertain', self.active)
            return self.relay.INCONCLUSIVE, 'durable delivery is uncertain; no automatic resend'
        except Exception:
            return self.relay.INCONCLUSIVE, 'managed authority unavailable; delivery held'

    def transports(self):
        relay = self.relay
        def verify_opencode(text, watermark):
            pending = self.state.get('pending') or {}
            return self.verify(
                lambda message, boundary: relay.verify_opencode_arrival_evidence(
                    message, boundary, pending.get('source_id'), relay.SESSION_ID),
                text, watermark, evidence_verifier='opencode_session_export')
        transports = {
            'send_opencode': lambda text: self.send(relay.send_opencode, text),
            'send_chatgpt': lambda text: self.send(relay.send_chatgpt, text),
            'confirm_submission': self.confirm_submission,
            'verify_opencode': verify_opencode,
            'verify_chatgpt': lambda *args: self.verify(relay.verify_chatgpt_arrival, *args),
        }
        capture = getattr(relay, 'capture_opencode_watermark_evidence', None)
        if callable(capture):
            transports['capture_opencode_watermark'] = capture
        return transports
