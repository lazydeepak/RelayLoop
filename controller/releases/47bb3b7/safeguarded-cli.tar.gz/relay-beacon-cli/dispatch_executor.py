"""Isolated provider execution seam for the M6 design.

The normal Worker -> Planner ChatGPT boundary imports this seam, while all
other provider families remain outside it until separately integrated. It
provides one small, testable boundary and does not implement turn taking,
delivery verification, continuation claims, or model failover.
"""
from dataclasses import dataclass
from typing import Callable, Optional, Protocol


LEGACY = "legacy"
COORDINATED = "coordinated"
NETWORK = "network"
STATUSES = ("confirmed", "ambiguous", "rejected")


@dataclass(frozen=True)
class DispatchRequest:
    pair_id: str
    host_id: Optional[str]
    ownership_epoch: Optional[int]
    operation_id: str
    session_id: str
    chatgpt_url: str
    direction: str
    text: str
    watermark: object = None
    continuation_admission: Optional[str] = None
    authority_id: Optional[str] = None
    authority_generation: Optional[int] = None


@dataclass(frozen=True)
class CoordinatorAdmission:
    pair_id: str
    host_id: str
    ownership_epoch: int
    operation_id: str
    reservation_id: str


@dataclass(frozen=True)
class ExecutionOutcome:
    status: str
    reason: str
    reservation_id: Optional[str] = None
    provider_result: object = None


class Coordinator(Protocol):
    def admit(self, request: DispatchRequest) -> Optional[CoordinatorAdmission]:
        """Persist intent/admission and return an authoritative capability."""

    def begin(self, admission: CoordinatorAdmission) -> bool:
        """Atomically perform the final ownership check before execution."""

    def record(self, admission: CoordinatorAdmission, status: str, evidence: str) -> None:
        """Persist confirmed, ambiguous, or rejected execution state."""


LegacyProvider = Callable[[DispatchRequest], object]
CoordinatedProvider = Callable[[DispatchRequest, CoordinatorAdmission], object]


class PreExecutionRejection(RuntimeError):
    """A provider boundary proved that no irreversible operation was started."""




def _matches(request: DispatchRequest, admission: CoordinatorAdmission) -> bool:
    return (
        request.pair_id == admission.pair_id
        and request.host_id == admission.host_id
        and request.ownership_epoch == admission.ownership_epoch
        and request.operation_id == admission.operation_id
    )


def dispatch_once(
    request: DispatchRequest,
    provider: Callable,
    *,
    policy: str = LEGACY,
    coordinator: Optional[Coordinator] = None,
) -> ExecutionOutcome:
    """Execute one provider operation under an explicit policy.

    Legacy mode delegates directly to the supplied existing provider callable;
    it does not acquire a coordinator and preserves single-host compatibility.
    Coordinated mode has no legacy fallback: admission, final begin, provider
    invocation, and durable outcome recording are mandatory.
    """
    if policy not in (LEGACY, COORDINATED, NETWORK):
        return ExecutionOutcome("rejected", "unknown dispatch policy")
    if not request.pair_id or not request.operation_id or not request.session_id:
        return ExecutionOutcome("rejected", "dispatch identity is incomplete")
    if not request.text:
        return ExecutionOutcome("rejected", "empty provider operation")

    if policy == LEGACY:
        try:
            result = provider(request)
            return ExecutionOutcome("confirmed", "legacy provider returned", provider_result=result)
        except PreExecutionRejection as exc:
            return ExecutionOutcome("rejected", str(exc)[:500])
        except Exception as exc:  # provider outcome may be unknown
            return ExecutionOutcome("ambiguous", str(exc)[:500])

    if policy == NETWORK:
        # The network client owns coordinator/gateway admission. This seam only
        # classifies its result and deliberately never falls back to a local
        # provider or retries a possibly transmitted request.
        try:
            result = provider(request)
            return ExecutionOutcome("confirmed", "network gateway returned", provider_result=result)
        except PreExecutionRejection as exc:
            return ExecutionOutcome("rejected", str(exc)[:500])
        except Exception as exc:  # transport status may be unknown
            return ExecutionOutcome("ambiguous", str(exc)[:500])

    if coordinator is None:
        return ExecutionOutcome("rejected", "coordinator unavailable; coordinated dispatch has no fallback")
    if request.host_id is None or request.ownership_epoch is None:
        return ExecutionOutcome("rejected", "coordinated dispatch requires host and ownership epoch")

    try:
        admission = coordinator.admit(request)
    except Exception as exc:
        return ExecutionOutcome("rejected", "coordinator admission failed: %s" % str(exc)[:400])
    if admission is None:
        return ExecutionOutcome("rejected", "coordinator rejected admission")
    if not _matches(request, admission):
        return ExecutionOutcome("rejected", "coordinator admission identity mismatch", admission.reservation_id)

    try:
        begun = coordinator.begin(admission)
    except Exception as exc:
        return ExecutionOutcome("rejected", "coordinator unavailable before provider execution: %s" % str(exc)[:400], admission.reservation_id)
    if not begun:
        return ExecutionOutcome("rejected", "execution reservation is stale, revoked, or transferred", admission.reservation_id)

    try:
        # The authoritative admission is an explicit capability argument. A
        # future provider adapter must require and validate it before reaching
        # its irreversible subprocess/browser action.
        result = provider(request, admission)
    except PreExecutionRejection as exc:
        evidence = str(exc)[:500]
        try:
            coordinator.record(admission, "rejected", evidence)
        except Exception:
            pass
        return ExecutionOutcome("rejected", evidence, admission.reservation_id)
    except Exception as exc:
        evidence = str(exc)[:500]
        try:
            coordinator.record(admission, "ambiguous", evidence)
        except Exception:
            # The durable reservation remains unresolved; never retry here.
            pass
        return ExecutionOutcome("ambiguous", evidence, admission.reservation_id)

    try:
        coordinator.record(admission, "confirmed", "provider returned")
    except Exception as exc:
        # Provider may have executed even though acknowledgment persistence did
        # not. Surface ambiguity rather than claiming success or retrying.
        return ExecutionOutcome("ambiguous", "provider returned but outcome record failed: %s" % str(exc)[:400], admission.reservation_id, result)
    return ExecutionOutcome("confirmed", "coordinated provider returned", admission.reservation_id, result)
